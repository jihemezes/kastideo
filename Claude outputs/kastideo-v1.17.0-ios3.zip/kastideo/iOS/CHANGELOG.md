# Kastideo pour iPhone et iPad — journal des versions

Versions envoyées à TestFlight avec les tags `vX.Y.Z-iosN` (le numéro X.Y.Z est celui de la version de référence).

## [1.17.0-ios3] - 2026-11-10

- Envoi à TestFlight : compilation avec Xcode 26 (SDK iOS 26), désormais exigé par Apple. Même contenu que 1.17.0-ios1.

## [1.17.0-ios2] - 2026-11-10

- Correction de compilation (document de configuration). Même contenu que 1.17.0-ios1.

## [1.17.0-ios1] - 2026-11-09

- **Première version iPhone et iPad (iOS 17 ou plus récent), via TestFlight.** Application native SwiftUI avec le même moteur de lecture VLC que le Mac : accueil (reprendre la lecture, favoris, récents), direct avec programme en cours, films et séries avec fiches, saisons et épisodes, lecteur plein écran (pistes audio, sous-titres, déplacement), mini-lecteur, son en arrière-plan, AirPlay, import et export de la configuration (même fichier que sur les autres versions), avertissement légal, journal de lecture partageable.
- Pas encore : enregistrement, guide en grille, thèmes, MultiVue, image dans l'image, YouTube, Cast. Apple TV viendra ensuite.
