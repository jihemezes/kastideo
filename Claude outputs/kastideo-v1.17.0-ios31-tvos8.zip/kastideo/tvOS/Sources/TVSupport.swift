import SwiftUI
import UIKit
import VLCKitSPM
import KastideoCore

// MARK: - Pont avec le code partagé (mêmes noms que sur Mac et iPhone)

/// Surface vidéo VLC conservée tant que l'app tourne.
@MainActor
enum TVVideoHost {
    private static var views: [ObjectIdentifier: UIView] = [:]

    @discardableResult
    static func attach(_ player: VLCMediaPlayer) -> UIView {
        let key = ObjectIdentifier(player)
        if let view = views[key] { return view }
        let view = UIView(frame: .zero)
        view.backgroundColor = .black
        views[key] = view
        player.drawable = view
        return view
    }
}

enum VideoContainerView {
    @MainActor
    static func ensureHosted(for player: VLCMediaPlayer) {
        TVVideoHost.attach(player)
    }
}

/// La diffusion vers un téléviseur n'a pas de sens sur Apple TV.
@MainActor
final class CastCenter {
    static let shared = CastCenter()
    func castEnded(by controller: PlaybackController) {}
}

struct VLCVideoRepresentable: UIViewRepresentable {
    let player: VLCMediaPlayer

    func makeUIView(context: Context) -> UIView {
        let host = UIView(frame: .zero)
        host.backgroundColor = .black
        let video = TVVideoHost.attach(player)
        video.removeFromSuperview()
        video.frame = host.bounds
        video.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        host.addSubview(video)
        return host
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}

extension MediaKind {
    var title: String {
        switch self {
        case .live: return String(localized: "Direct")
        case .movie: return String(localized: "Films")
        case .series: return String(localized: "Séries")
        case .episode: return String(localized: "Épisodes")
        }
    }
}

enum TVPalette {
    static let orange = Color(red: 1.0, green: 0.53, blue: 0.16)
    static let magenta = Color(red: 0.78, green: 0.2, blue: 0.62)
}

// MARK: - État de l'interface

@MainActor
@Observable
final class TVUI {
    /// Contenu en cours de lecture plein écran.
    var playing: MediaItem?
    /// Chaînes parmi lesquelles on change avec haut / bas.
    var zapList: [MediaItem] = []
    /// Fiche détaillée ouverte (film ou série).
    var detail: MediaItem?
    var showDisclaimer = LegalNotice.needsAcceptance
    /// Onglet affiché (0 Accueil, 1 Direct, 2 Films, 3 Séries, 4 Guide TV, 5 Réglages).
    var tab = 0
    /// Heure d'arrêt programmée (minuterie de veille).
    var sleepAt: Date?
    @ObservationIgnored private var sleepTask: Task<Void, Never>?

    func setSleep(minutes: Int?, playback: PlaybackController) {
        sleepTask?.cancel()
        guard let minutes else { sleepAt = nil; return }
        sleepAt = Date().addingTimeInterval(Double(minutes) * 60)
        sleepTask = Task { [weak self, weak playback] in
            try? await Task.sleep(for: .seconds(Double(minutes) * 60))
            guard !Task.isCancelled, let self, let playback else { return }
            self.sleepAt = nil
            self.stop(playback: playback)
        }
    }
    /// Chaîne regardée juste avant (« Dernière chaîne »).
    var previousChannel: MediaItem?
    /// Épisodes de la série en cours (épisode suivant automatique).
    var episodeContext: [MediaItem] = []

    func play(_ item: MediaItem, list: [MediaItem] = [], playback: PlaybackController) {
        if item.kind == .live, let current = playing ?? playback.current, current.kind == .live, current.id != item.id {
            previousChannel = current
        }
        if item.kind == .live { zapList = list.isEmpty ? zapList : list } else { zapList = [] }
        if item.kind != .episode { episodeContext = [] }
        playing = item
        playback.play(item)
    }

    func nextEpisode(after item: MediaItem) -> MediaItem? {
        guard let index = episodeContext.firstIndex(where: { $0.id == item.id }), index + 1 < episodeContext.count else { return nil }
        return episodeContext[index + 1]
    }

    /// Fin d'un épisode : lance le suivant.
    func playNext(after item: MediaItem, playback: PlaybackController) {
        guard let next = nextEpisode(after: item) else { return }
        play(next, playback: playback)
    }

    func stop(playback: PlaybackController) {
        sleepTask?.cancel()
        sleepAt = nil
        playback.stopByUser()
        playing = nil
    }
}

/// Pastille « vu » en haut à droite d'une affiche.
struct TVWatchedMark: View {
    let id: String
    @Environment(WatchProgressStore.self) private var watch

    var body: some View {
        if watch.isWatched(id) {
            Image(systemName: "checkmark.circle.fill")
                .font(.title3)
                .foregroundStyle(.white, TVBrand.orange)
                .padding(10)
        }
    }
}

// MARK: - Vignette

struct ArtworkView: View {
    let url: URL?
    let name: String
    var contentMode: ContentMode = .fit

    var body: some View {
        ZStack {
            Color.white.opacity(0.07)
            if let url {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().aspectRatio(contentMode: contentMode)
                    default:
                        initial
                    }
                }
            } else {
                initial
            }
        }
        .clipped()
    }

    private var initial: some View {
        Text(String(name.trimmingCharacters(in: .whitespaces).prefix(1)).uppercased())
            .font(.system(size: 54, weight: .bold, design: .rounded))
            .foregroundStyle(.secondary)
    }
}

/// Fond dégradé de l'accueil Kastideo.
/// Couleurs de l'application (comme sur iPad et Mac).
enum TVBrand {
    static let night = Color(red: 0.06, green: 0.02, blue: 0.14)
    static let indigo = Color(red: 0.17, green: 0.13, blue: 0.58)
    static let violet = Color(red: 0.34, green: 0.10, blue: 0.55)
    static let magenta = Color(red: 0.80, green: 0.16, blue: 0.52)
    static let orange = Color(red: 1.00, green: 0.60, blue: 0.20)
}

/// Fond en dégradé avec le grand logo flouté, comme l'accueil de l'iPad.
struct TVBackground: View {
    var body: some View {
        GeometryReader { geo in
            let side = geo.size.height * 0.95
            ZStack {
                LinearGradient(colors: [TVBrand.night, TVBrand.violet.opacity(0.9), TVBrand.night], startPoint: .topLeading, endPoint: .bottomTrailing)
                RadialGradient(colors: [TVBrand.magenta.opacity(0.45), .clear], center: .bottomTrailing, startRadius: 20, endRadius: 900)
                RadialGradient(colors: [TVBrand.orange.opacity(0.18), .clear], center: .topTrailing, startRadius: 10, endRadius: 600)
                Image("KastideoLogo")
                    .resizable()
                    .frame(width: side, height: side)
                    .opacity(0.25)
                    .blur(radius: 6)
                    .rotationEffect(.degrees(-8))
                    .position(x: geo.size.width - side * 0.18, y: geo.size.height * 0.55)
                    .allowsHitTesting(false)
            }
            .clipped()
        }
        .ignoresSafeArea()
    }
}

extension Programme {
    /// « 20:55 – 22:30 »
    func timeRange() -> String {
        "\(start.formatted(date: .omitted, time: .shortened)) – \(stop.formatted(date: .omitted, time: .shortened))"
    }
}

extension SourceKind {
    var title: String {
        switch self {
        case .m3uURL: return String(localized: "Playlist M3U (URL)")
        case .m3uFile: return String(localized: "Playlist M3U (fichier)")
        case .xtream: return String(localized: "Xtream Codes")
        case .folders: return String(localized: "Dossiers")
        case .mediaServer(let type, _, _): return type.label
        case .gallery: return String(localized: "Galerie")
        }
    }
}

// TVVLCKit n'a pas l'API de diffusion vers un téléviseur (Cast) : substituts inertes pour que le code partagé compile.
final class VLCRendererItem: NSObject {
    var name: String { "" }
}

extension VLCMediaPlayer {
    func setRendererItem(_ item: VLCRendererItem?) -> Bool { true }
}
