import 'package:flutter/material.dart';

import 'l10n.dart';
import 'theme.dart';
import 'core/alerts.dart';
import 'core/cast_controller.dart';
import 'core/downloads.dart';
import 'core/epg.dart';
import 'core/guide.dart';
import 'core/library.dart';
import 'core/media_info.dart';
import 'core/models.dart';
import 'core/multiview.dart';
import 'core/updater.dart';
import 'core/playback.dart';
import 'core/recording.dart';
import 'core/settings.dart';
import 'core/themes.dart';

/// Écran affiché.
enum Screen { home, live, movies, series, guide, recordings, multiview, library, youtube }

extension ScreenKind on Screen {
  MediaKind? get kind => switch (this) {
        Screen.live => MediaKind.live,
        Screen.movies => MediaKind.movie,
        Screen.series => MediaKind.series,
        Screen.home || Screen.guide || Screen.recordings || Screen.multiview || Screen.library || Screen.youtube => null,
      };
}

Screen screenFor(MediaKind kind) => switch (kind) {
      MediaKind.live => Screen.live,
      MediaKind.movie => Screen.movies,
      MediaKind.series || MediaKind.episode => Screen.series,
    };

/// Ce qui est sélectionné dans la barre latérale d'une section.
sealed class CatalogFilter {
  const CatalogFilter();
}

class AllItems extends CatalogFilter {
  const AllItems();
}

class FavoriteItems extends CatalogFilter {
  const FavoriteItems();
}

class RecentItems extends CatalogFilter {
  const RecentItems();
}

/// Vue « Thèmes » du direct (En ce moment, Ce soir, Chaînes).
class ThemesFilter extends CatalogFilter {
  const ThemesFilter();
}

/// Mode de la vue Thèmes.
enum ThemeView { now, tonight, channels }

class CategoryFilter extends CatalogFilter {
  const CategoryFilter(this.name);
  final String name;
}

/// Vues de la vidéothèque.
enum LibraryView { home, movies, series, videos, folders }

/// Tri de la vidéothèque.
enum LibrarySort { title, added, year, rating, runtime }

/// Qualité d'image d'une vidéo, d'après le nom du fichier.
enum LibraryQuality { uhd, hd, other }

/// Filtre d'état de visionnage.
enum LibraryStatus { all, unwatched, inProgress, watched, favorites }

/// Navigation (équivalent du NavigationModel de la version Mac).
class NavigationModel extends ChangeNotifier {
  Screen screen = Screen.home;
  final Map<MediaKind, CatalogFilter> _filters = {};
  bool theater = false;

  /// Film ou série affiché (fiche) — interface Classique : panneau de droite ; Cinéma : page entière.
  /// La vidéothèque a sa propre fiche ouverte.
  final Map<Object, MediaItem?> _selected = {};
  Object _key(MediaKind kind) => screen == Screen.library ? 'library' : kind;

  // MARK: Vidéothèque

  /// Source affichée (null : toutes), vue, dossier ouvert (navigation par dossiers), filtres et tri.
  String? librarySource;
  LibraryView libraryView = LibraryView.home;
  List<String> libraryFolder = const [];
  String? libraryGenre;
  int? libraryYear;
  String? libraryCountry;
  String? libraryLanguage;
  LibraryQuality? libraryQuality;
  LibraryStatus libraryStatus = LibraryStatus.all;
  LibrarySort librarySort = LibrarySort.title;

  /// Raccourci utilisé par « Films à voir » (page d'accueil de la vidéothèque).
  bool get libraryUnwatched => libraryStatus == LibraryStatus.unwatched;

  bool get hasLibraryFilters =>
      libraryGenre != null || libraryYear != null || libraryCountry != null || libraryLanguage != null || libraryQuality != null || libraryStatus != LibraryStatus.all;

  bool _libraryPrefsLoaded = false;

  /// Relit les filtres et le tri mémorisés (une seule fois, quand les réglages sont disponibles).
  void loadLibraryPrefs() {
    final s = settings;
    if (_libraryPrefsLoaded || s == null) return;
    _libraryPrefsLoaded = true;
    libraryGenre = s.libraryPref('genre');
    libraryYear = int.tryParse(s.libraryPref('year') ?? '');
    libraryCountry = s.libraryPref('country');
    libraryLanguage = s.libraryPref('language');
    libraryQuality = LibraryQuality.values.where((e) => e.name == s.libraryPref('quality')).firstOrNull;
    libraryStatus = LibraryStatus.values.where((e) => e.name == s.libraryPref('status')).firstOrNull ?? LibraryStatus.all;
    librarySort = LibrarySort.values.where((e) => e.name == s.libraryPref('sort')).firstOrNull ?? LibrarySort.title;
  }

  void _saveLibraryPrefs() {
    final s = settings;
    if (s == null) return;
    s.setLibraryPref('genre', libraryGenre);
    s.setLibraryPref('year', libraryYear?.toString());
    s.setLibraryPref('country', libraryCountry);
    s.setLibraryPref('language', libraryLanguage);
    s.setLibraryPref('quality', libraryQuality?.name);
    s.setLibraryPref('status', libraryStatus == LibraryStatus.all ? null : libraryStatus.name);
    s.setLibraryPref('sort', librarySort.name);
  }

  /// Remet à zéro tous les filtres (le tri est conservé).
  void resetLibraryFilters() {
    libraryGenre = libraryYear = libraryCountry = libraryLanguage = null;
    libraryQuality = null;
    libraryStatus = LibraryStatus.all;
    _saveLibraryPrefs();
    notifyListeners();
  }

  void setLibrary({
    Object? source = _keep,
    LibraryView? view,
    List<String>? folder,
    Object? genre = _keep,
    Object? year = _keep,
    Object? country = _keep,
    Object? language = _keep,
    Object? quality = _keep,
    bool? unwatched,
    LibraryStatus? status,
    LibrarySort? sort,
  }) {
    if (source != _keep) {
      librarySource = source as String?;
      libraryFolder = const [];
    }
    if (view != null) {
      libraryView = view;
      if (view != LibraryView.folders) libraryFolder = const [];
    }
    if (folder != null) libraryFolder = folder;
    if (genre != _keep) libraryGenre = genre as String?;
    if (year != _keep) libraryYear = year as int?;
    if (country != _keep) libraryCountry = country as String?;
    if (language != _keep) libraryLanguage = language as String?;
    if (quality != _keep) libraryQuality = quality as LibraryQuality?;
    if (unwatched != null) libraryStatus = unwatched ? LibraryStatus.unwatched : LibraryStatus.all;
    if (status != null) libraryStatus = status;
    if (sort != null) librarySort = sort;
    _saveLibraryPrefs();
    _selected['library'] = null;
    showPlayer = false;
    notifyListeners();
  }

  static const _keep = Object();

  /// Le lecteur est affiché (au lieu de la fiche) pour un film ou un épisode.
  bool showPlayer = false;

  /// Recherche dans la section affichée.
  String search = '';

  /// Mode « Modifier » des récents (cases à cocher, retirer, tout effacer).
  bool editingRecents = false;

  void setEditingRecents(bool value) {
    editingRecents = value;
    notifyListeners();
  }

  /// Vue Thèmes : mode, thème et discipline choisis.
  ThemeView themeMode = ThemeView.now;
  ContentTheme? themeSelection;
  SportKind? sportKind;

  void showThemes({ContentTheme? theme, ThemeView mode = ThemeView.now}) {
    themeSelection = theme;
    themeMode = mode;
    sportKind = null;
    show(MediaKind.live, const ThemesFilter());
  }

  void setThemeMode(ThemeView mode) {
    themeMode = mode;
    notifyListeners();
  }

  void setThemeSelection(ContentTheme? theme) {
    themeSelection = theme;
    if (theme != ContentTheme.sport) sportKind = null;
    notifyListeners();
  }

  void setSportKind(SportKind? kind) {
    sportKind = kind;
    notifyListeners();
  }

  CatalogFilter filter(MediaKind kind) => _filters[kind] ?? const AllItems();

  /// Retour à « toutes les chaînes / films / séries » (après un changement de source).
  void resetFilters() {
    _filters.clear();
    notifyListeners();
  }
  MediaItem? selected(MediaKind kind) => _selected[_key(kind)];

  /// Réglages et catégories affichées : pour la page de départ des sections (renseignés au démarrage).
  AppSettings? settings;
  List<String> Function(MediaKind kind)? categoryNames;

  /// Filtre de départ d'une section (null : tout afficher).
  CatalogFilter? _startFilter(MediaKind kind) {
    final s = settings;
    if (s == null) return null;
    var mode = s.startPage(kind);
    if (mode == 'last') mode = s.startLast(kind);
    if (mode == 'favorites') return const FavoriteItems();
    if (mode == 'recents') return const RecentItems();
    if (mode.startsWith('cat:')) {
      final name = mode.substring(4);
      if ((categoryNames?.call(kind) ?? const <String>[]).contains(name)) return CategoryFilter(name);
    }
    return null;
  }

  void go(Screen value) {
    // Entrer dans Direct, Films ou Séries depuis une autre section : page de départ choisie dans les Réglages.
    final kind = value.kind;
    if (kind != null && screen != value) {
      final start = _startFilter(kind);
      if (start == null) {
        _filters.remove(kind);
      } else {
        _filters[kind] = start;
      }
    }
    screen = value;
    editingRecents = false;
    if (value != Screen.live) theater = false;
    showPlayer = false;
    search = '';
    notifyListeners();
  }

  void show(MediaKind kind, CatalogFilter filter) {
    _filters[kind] = filter;
    // Dernière page consultée (option « Dernière consultée » de la page de départ).
    if (filter is! ThemesFilter) {
      settings?.rememberStart(
        kind,
        switch (filter) {
          CategoryFilter(:final name) => 'cat:$name',
          FavoriteItems() => 'favorites',
          RecentItems() => 'recents',
          _ => 'all',
        },
      );
    }
    editingRecents = false;
    screen = screenFor(kind);
    _selected[_key(kind)] = null;
    showPlayer = false;
    search = '';
    notifyListeners();
  }

  void select(MediaKind kind, MediaItem? item) {
    _selected[_key(kind)] = item;
    showPlayer = false;
    notifyListeners();
  }

  void setSearch(String value) {
    search = value;
    notifyListeners();
  }

  void openPlayer() {
    showPlayer = true;
    notifyListeners();
  }

  void closePlayer() {
    showPlayer = false;
    theater = false;
    notifyListeners();
  }

  void toggleTheater() {
    theater = !theater;
    notifyListeners();
  }

  void exitTheater() {
    if (!theater) return;
    theater = false;
    notifyListeners();
  }
}

/// Accès aux objets partagés depuis n'importe quel widget.
class AppScope extends InheritedWidget {
  const AppScope({
    super.key,
    required this.library,
    required this.playback,
    required this.navigation,
    required this.settings,
    required this.watch,
    required this.info,
    required this.guide,
    required this.recordings,
    required this.downloads,
    required this.alerts,
    required this.multiview,
    required this.updates,
    required this.cast,
    required super.child,
  });

  final LibraryStore library;
  final PlaybackController playback;
  final NavigationModel navigation;
  final AppSettings settings;
  final WatchProgressStore watch;
  final MediaInfoStore info;
  final GuideStore guide;
  final RecordingCenter recordings;
  final DownloadManager downloads;
  final AlertCenter alerts;
  final MultiViewController multiview;
  final UpdateService updates;
  final CastController cast;

  static AppScope of(BuildContext context) => context.dependOnInheritedWidgetOfExactType<AppScope>()!;

  @override
  bool updateShouldNotify(AppScope oldWidget) => false;
}

extension AppScopeContext on BuildContext {
  LibraryStore get library => AppScope.of(this).library;
  PlaybackController get playback => AppScope.of(this).playback;
  NavigationModel get navigation => AppScope.of(this).navigation;
  AppSettings get settings => AppScope.of(this).settings;
  WatchProgressStore get watch => AppScope.of(this).watch;
  MediaInfoStore get info => AppScope.of(this).info;
  GuideStore get guide => AppScope.of(this).guide;
  RecordingCenter get recordings => AppScope.of(this).recordings;
  DownloadManager get downloads => AppScope.of(this).downloads;
  AlertCenter get alerts => AppScope.of(this).alerts;
  MultiViewController get multiview => AppScope.of(this).multiview;
  UpdateService get updates => AppScope.of(this).updates;
  CastController get cast => AppScope.of(this).cast;
}

/// Une seule connexion : lancer [item] arrêterait l'enregistrement en cours ? On demande d'abord.
Future<bool> confirmConnection(BuildContext context, MediaItem item) async {
  final recordings = context.recordings;
  if (!recordings.conflictsWith(item)) return true;
  final active = recordings.active!;
  final channel = active.channel.displayName;
  if (item.kind == MediaKind.live && item.id == active.channel.id) {
    // Même chaîne, enregistrée en arrière-plan : elle passe dans le lecteur, l'enregistrement continue (nouveau fichier).
    await recordings.moveToPlayer();
    if (context.mounted) {
      context.library.noteRecent(item);
      if (context.navigation.screen != Screen.live) context.navigation.go(Screen.live);
      context.navigation.openPlayer();
    }
    return false;
  }
  final ok = await showKDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(tr('Enregistrement en cours')),
      content: Text('${tr('Kastideo enregistre')} $channel. ${tr('Votre abonnement n\'autorise qu\'une connexion : lancer ce contenu arrêtera l\'enregistrement.')}'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr('Continuer l\'enregistrement'))),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(tr('Arrêter et lancer'))),
      ],
    ),
  );
  if (ok != true) return false;
  await recordings.stop();
  return true;
}

/// Bouton Arrêt : arrête la lecture ; demande d'abord si l'enregistrement de la chaîne regardée en dépend.
Future<void> stopPlayback(BuildContext context) async {
  final playback = context.playback;
  final recordings = context.recordings;
  final item = playback.current;
  if (item == null) return;
  if (recordings.isRecording(item)) {
    final ok = await showKDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr('Enregistrement en cours')),
        content: Text('${tr('Arrêter la lecture arrêtera aussi l\'enregistrement de')} ${item.displayName}.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr('Annuler'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(tr('Tout arrêter'))),
        ],
      ),
    );
    if (ok != true) return;
    await recordings.stop();
  }
  await playback.stopByUser();
}

/// Ouvre un contenu : chaîne → lecture ; film ou série → fiche (comme sur Mac).
Future<void> openItem(BuildContext context, MediaItem item) async {
  final navigation = context.navigation;
  if (item.kind == MediaKind.live && !await confirmConnection(context, item)) return;
  if (!context.mounted) return;
  switch (item.kind) {
    case MediaKind.live:
      context.playback.play(item);
      context.library.noteRecent(item);
      if (navigation.screen != Screen.live) navigation.go(Screen.live);
      // Interface Cinéma : lecteur en plein cadre avec un bouton de retour.
      navigation.openPlayer();
    case MediaKind.movie:
    case MediaKind.series:
      final target = context.library.isLibraryItem(item) ? Screen.library : screenFor(item.kind);
      if (navigation.screen != target) navigation.go(target);
      navigation.select(item.kind, item);
    case MediaKind.episode:
      playItem(context, item);
  }
}

/// Revoit un programme depuis l'archive du fournisseur : lecture dans le lecteur de la section Direct.
Future<void> watchReplay(
  BuildContext context,
  MediaItem channel,
  Programme programme,
) async {
  final replay = context.library.makeReplay(channel, programme);
  if (replay == null) return;
  if (!await confirmConnection(context, replay)) return;
  if (!context.mounted) return;
  final navigation = context.navigation;
  context.playback.play(replay);
  if (navigation.screen != Screen.live) navigation.go(Screen.live);
  navigation.openPlayer();
}

/// Lance la lecture d'un film ou d'un épisode et affiche le lecteur (dans sa section, avec sa fiche derrière).
Future<void> playItem(BuildContext context, MediaItem item) async {
  if (!await confirmConnection(context, item)) return;
  if (!context.mounted) return;
  final navigation = context.navigation;
  final library = context.library;
  final kind = item.kind == MediaKind.episode ? MediaKind.series : item.kind;
  final target = library.isLibraryItem(item) ? Screen.library : screenFor(kind);
  if (navigation.screen != target) navigation.go(target);
  final selected = navigation.selected(kind);
  if (item.kind == MediaKind.episode) {
    if (selected == null || selected.name != item.group) {
      final series = library.seriesOf(item);
      if (series != null) navigation.select(kind, series);
    }
  } else if (selected?.id != item.id) {
    navigation.select(kind, item);
  }
  context.playback.play(item);
  library.noteRecent(item);
  navigation.openPlayer();
}
