# Getting started

## Welcome {#bienvenue}

Kastideo brings together your **live channels, IPTV movies and series**, your **personal videos** (disk, USB drive, NAS, Jellyfin, Emby, Plex) and **YouTube** in a single interface. Kastideo provides **no content** of its own: you add your own sources.

<!--mac-->
![The Home screen](img:home)

1. Back to Home, from anywhere.
2. One search for channels, movies and series.
3. The **?** button: help, opened on the page that matches the screen you are on.
<!--/mac-->
<!--pc-->
![The Home screen](img:homepc)

1. The **?** button: help, opened on the page that matches the screen you are on.
2. **Playback log**: the diagnostic tool.
3. **Settings**: sources, appearance, recordings…
4. One search for channels, movies and series, then the tiles and shortcuts ([Home screen details](help:accueil)).
<!--/pc-->

### Quick start

<!--mac-->
1. On first launch, click **Add a source** (or **Settings ⌘,** > **Sources** > **Add**).
<!--/mac-->
<!--pc-->
1. Open **Settings** (the gear on Home, or **Ctrl+,**) > **Sources** > **Add a source**.
<!--/pc-->
2. Choose the source type: [Xtream Codes](help:xtream), [M3U playlist](help:m3u), [Folders](help:dossiers), or a [Jellyfin, Emby or Plex](help:serveurs) server.
3. Fill in the requested details and click **Add**: Kastideo loads the channels, movies, series and the [TV guide](help:guide).
4. Go back to **Home** and open **Live**, **Movies** or **Series**.

### Getting help

<!--mac-->
- The **?** button in the toolbar opens help on the page that matches the current screen.
- **Help > Kastideo Help** menu or **⌘?**.
<!--/mac-->
<!--pc-->
- The **?** button on Home and on the main screens opens help.
<!--/pc-->
- The **Search** field at the top of help searches every page.
- Something wrong? See the [FAQ](help:faq) and then [Troubleshooting](help:depannage).

> Want to watch YouTube? See [YouTube](help:youtube). Importing your subscriptions: [step by step](help:youtube-import).

## FAQ {#faq}

### Where do I find channels to add?
Kastideo provides neither channels nor a subscription. Your IPTV provider gives you either a server, a username and a password ([Xtream Codes](help:xtream)), or a playlist address ([M3U](help:m3u)). You can also play your own files ([Folders](help:dossiers)).

### How do I change Kastideo's language?
Kastideo is available in **French, English, Spanish, German, Italian and Portuguese** (Portugal and Brazil). By default it follows your device's language; if that language is not supported, the interface is shown in English. To change it: **Settings > General > Language** (on iPhone, iPad and Apple TV, Kastideo follows the system language: set it in the device Settings). The change applies the next time Kastideo starts.

### A channel does not start or stutters
<!--mac-->See [If a channel does not start](help:chaine-ne-demarre-pas) and [Troubleshooting](help:depannage).<!--/mac--><!--pc-->See [Troubleshooting](help:depannage).<!--/pc--> Very often the cause is a **second simultaneous connection** on the same subscription: see [One connection at a time](help:connexion-unique).

### The TV guide is empty or incomplete
Settings > Sources > **Reload TV guide**, then read [TV guide](help:guide) and the [backup guide](help:guide-secours).

### How can I watch YouTube without ads?
Kastideo plays videos with the official player in **privacy-enhanced mode**: no tracking cookie, so usually no personalised ads. It is **not** an ad blocker: see [Ads, account and privacy](help:youtube-confidentialite).

### How do I import my YouTube subscriptions?
YouTube does not let you connect an account to a third-party app: you use a file that Google generates for you. Follow the [step-by-step guide](help:youtube-import).

### YouTube search asks for a key
Search uses **your own** free Google API key. The [step-by-step guide](help:youtube-cle) explains it in a few minutes. Without a key you can still follow channels and play pasted links.

### How do I record a programme?
See [Recording live TV](help:enregistrer) and [Scheduling a recording](help:programmer).

### How do I watch a programme that already aired?
If your provider offers an archive: see [Replay](help:replay).

### How do I get my settings on another computer?
See [Backup and transfer](help:sauvegarde).

# Sources

## Xtream Codes {#xtream}

<!--mac-->
This is the most common format among IPTV providers. You need three pieces of information: the **server** address (for example `http://example.com:8080`), your **username** and your **password**.

- The **Test Connection** button checks your credentials and shows the account status, its expiration date and the number of simultaneous connections allowed.
- The password is stored in the **macOS keychain**, never in clear text on disk.
- The server's TV guide is used automatically.
- Series open on a page with their seasons and episodes.
<!--/mac-->

<!--pc-->
Server address (e.g. http://example.com:8080), username and password. The password is stored in the system vault: Credential Manager on Windows, GNOME Keyring or KWallet on Linux.
<!--/pc-->

## M3U / M3U8 playlist {#m3u}

<!--mac-->
- **By URL**: paste the playlist address supplied by your provider.
- If the address looks like `get.php?username=…&password=…` (the most common case with subscription providers), Kastideo recognizes it and saves it as **Xtream Codes**: loading is much faster, the TV guide is included and the password is kept in the keychain. Sources of this kind that were already saved are converted automatically.
- **By file**: choose an `.m3u` or `.m3u8` file on your Mac. Kastideo keeps the permission to access it so that it can refresh it.
- Categories come from the `group-title` attribute, logos from `tvg-logo` and the link to the TV guide from `tvg-id`.
- Kastideo automatically sorts entries into Live, Movies or Series based on their address.
<!--/mac-->

<!--pc-->
Playlist address or file on disk (**Choose a file…**). A "get.php?username=…&password=…" address is recognized and turned into an Xtream source, much faster and more complete (details, episodes, latest additions).
<!--/pc-->

## Folders (disk, USB drive, NAS) {#dossiers}

<!--mac-->
To watch videos stored on the Mac, an external disk, a USB drive or a NAS:

1. Settings > Sources > **Add** > type **Folders (disk, USB, NAS)**.
2. **Add a folder…**: choose one or more folders (for example “Movies” and “Series”). For a **NAS**, first mount the share in the Finder (**Go > Connect to Server…**, for example `smb://nas.local/Videos`), then choose it among the volumes.
3. **Add**: Kastideo scans the folders and their subfolders.

Videos are recognized from their names:

- **Movies**: “Inception (2010).mkv”, “The.Matrix.1999.1080p.BluRay.mkv”, or a folder “Amélie (2001)” containing the movie. They appear in **Movies**, category “Movies · folder name”.
- **Series**: “Breaking.Bad.S01E02.mkv”, “Friends 1x05.mp4”, or a folder “Kaamelott/Season 3/12 - Le Tourment.avi”. Episodes are grouped into one series, with its seasons, in **Series**.
- **Other videos** (holidays, camera…): category **Videos · folder name**, in Movies.

Folders are scanned at each launch and then every 20 minutes: a new video shows up by itself. If the disk is unplugged or the share disconnected, a message says so under the source and the previous list is kept. **Subtitles** placed next to a video (“Inception (2010).srt”, “Inception (2010).en.srt”) are loaded on playback.

With a **TMDB key** (Settings > General), movies and series automatically get a **poster and summary**. If the file name misleads the search, right-click the poster (or the link at the bottom of the details page) > **Fix details…**: search for the right title and pick it; the choice is remembered.
<!--/mac-->

<!--pc-->
Settings > Sources > **Add a source** > **Folders**, then **Add a folder…** (internal disk, USB disk or stick) or type a **network path** and click **+**: `\\NAS\Videos` or a network drive (`Z:\`) on Windows, a mounted share (`/mnt/nas/videos`, `/media/…`) on Linux. Several folders can make up one source. On **Android TV** (and Android), an **SMB** path is also accepted: `smb://NAS/Videos` (or `\\NAS\Videos`); enter the share's user and password, or leave them empty for guest access. SMB 2.1 or older only.

- **Movies** recognized from their names: “Inception (2010).mkv”, “The.Matrix.1999.1080p.BluRay.mkv”, folder “Amélie (2001)”. Category “Movies · folder name”.
- **Series**: “Breaking.Bad.S01E02.mkv”, “Friends 1x05.mp4”, folders “Show/Season 1/…”. Episodes are grouped by series and season in **Series**.
- **Other videos**: category **Videos · folder name** in Movies.
- Scanned at each launch and then every 20 minutes. Disk unplugged: a message says so and the previous list is kept. Unreadable subfolders (“System Volume Information”…) are skipped.
- **Subtitles** placed next to a video (“Movie.srt”, “Movie.en.srt”) are loaded on playback.
- With a **TMDB key**, **posters and summaries** are added automatically; right-click > **Fix details…** to pick the right title when the file name misleads the search.
<!--/pc-->

## Jellyfin, Emby and Plex {#serveurs}

<!--mac-->
### Jellyfin and Emby

1. Settings > Sources > **Add** > **Jellyfin** or **Emby**.
2. **Search the network** finds the servers at home; click yours to fill in the address. Otherwise type it (for example `192.168.1.10`: port 8096 is added).
3. Your Jellyfin / Emby **username** and **password** — **optional**: leave it empty if the account has none (an **API key** from the dashboard can also replace it). **Test Connection** checks the address. An address copied from the browser (“…:8096/web/index.html#!/home”) is reduced to the server's.
4. **Add**: the username is checked, then the server's movie, series and video libraries appear in **Movies** and **Series** (categories “library name · server name”), with the server's posters and details.

Playback is **direct**, without transcoding by the server. The password and session are stored in the keychain.

### Plex

1. Settings > Sources > **Add** > **Plex**.
2. **Sign in with Plex** opens plex.tv in the browser: sign in and authorize Kastideo. Back in Kastideo, choose the server from your account.
3. You can also type the server address (port 32400) and its **token** (X-Plex-Token). The token is **optional** if the server allows the local network without authentication (Plex > Settings > Network > “List of IP addresses and networks that are allowed without auth”).
4. **Add**: the movie and series libraries appear in **Movies** and **Series**.
<!--/mac-->

<!--pc-->
Settings > Sources > **Add a source** > **Jellyfin**, **Emby** or **Plex**. **Search the network** finds the servers at home: click yours to fill in the form (otherwise type the address; without a port, 8096 or 32400 is added).

- **Jellyfin / Emby**: username and password — **optional** if the account has none (or an **API key** from the dashboard). **Test** checks the address; on failure, the exact server response is shown.
- **Plex**: **Sign in with Plex** opens plex.tv in the browser; authorize Kastideo, then choose the server from your account. Or type the address and the **token** (X-Plex-Token), optional if the server allows the local network without authentication.
- Libraries appear in **Movies** and **Series** (“library name · server name”), with the server's posters, details, seasons and episodes. Direct playback, no transcoding.
- **Resume and “watched” shared both ways**: the position is sent to the server while you watch, and the one from your other devices is picked up. Right-click > **Mark as watched / unwatched**; **Watched** badge on posters.

> Windows firewall: on the first search, allow Kastideo on private networks so that servers can answer.
<!--/pc-->

## Resume and “watched” shared with servers {#reprise-serveurs}

<!--mac-->
With Jellyfin, Emby and Plex, the playback position is sent to the server while you watch: a movie started in Kastideo can be resumed on the TV, and the other way round. A movie watched to the end is marked **watched** on the server. Right-click a movie or an episode > **Mark as watched / unwatched** (also for files from folders). A **Watched** badge appears on posters, and a check mark in the episode list.

> Network search: the first time, macOS asks for permission to access the **local network**; accept it (otherwise System Settings > Privacy & Security > Local Network).
<!--/mac-->

## TV guide (XMLTV) {#guide}

<!--mac-->
Each source can have a TV guide address in XMLTV format (`.xml` or `.xml.gz`). If you leave it empty, Kastideo uses the one from the Xtream server or the one announced in the playlist (`url-tvg`). The guide is kept from 6 hours back to 48 hours ahead.
<!--/mac-->

<!--pc-->
The guide provided by your provider loads in the background and is kept on disk. The optional **TV guide (XMLTV)** field of a source lets you use another guide (.xml or .xml.gz).
<!--/pc-->

## Backup TV guide (xmltvfr.fr) {#guide-secours}

<!--mac-->
Your provider's guide can be incomplete or temporarily empty. Kastideo completes it with a free **backup guide** from **xmltvfr.fr** (“Complete” guide by default: about 785 French and foreign channels, 5 days, updated daily):

- only channels **without programs** from your provider are completed; the provider's guide keeps priority;
- channels are matched **by name**: “|FR| TF1 FHD” → TF1, “|FR| FRANCE 2 UHD” → France 2, “|FR| TF1 4K” → TF1 4K;
- the backup guide is reloaded every 12 hours. If the provider sends an empty or unreadable guide, programs already known are kept and a message appears under the source.

**Finding out where the guide comes from.** Under each source, Settings > Sources shows how many programs the provider sent. The **Reload the TV guide** button (calendar icon) restarts the download of the provider's guide and the backup guide. Provider lines that are only **category separators** (“♣♦♣---|FR| FRANCE FHD |FR|---♣♦♣”) are ignored; a 4K or FHD version without its own programme reuses the HD version's; channels without a programme show “Program not available”. The **Log**, topic **TV Guide**, details every attempt: address requested, server response (code, size, time), number of channels and programs received, period covered, how many of your channels are linked to the provider's guide, the backup guide or neither, and — if the guide holds nothing usable — the beginning of the server's answer.

Settings > General > **Backup TV Guide**: turn it on or off, pick another xmltvfr.fr guide (France ~400 channels, DTT) or enter any XMLTV address, **Refresh Now**, and see how many channels were linked to yours.
<!--/mac-->

<!--pc-->
Settings > General > **TV guide**: a fallback guide fills in channels without programmes in your provider's guide, matching them by name. Pick an xmltvfr.fr guide or type an address; **Reload the guide** downloads everything again. The **TV guide log** button opens the Log on the *TV Guide* topic: address requested, provider response (code, size, time), channels and programmes received, period covered, how many of your channels are linked to the provider, the backup or no guide, and — if the guide is unusable — the beginning of the server's answer. The provider's programmes are filtered on your channels' identifiers: if the guide holds programmes but none for your channels, the log shows the identifiers on both sides.
<!--/pc-->

## Managing sources {#gerer-sources}

<!--mac-->
Open **Kastideo > Settings… (⌘,)**, **Sources** tab, or click the **Sources** button in the toolbar.

- The switch enables or disables a source without deleting it.
- The buttons let you refresh, edit or delete a source.
- If there is an error, the message appears in red under the source and an orange triangle appears in the sidebar.
<!--/mac-->

<!--pc-->
Settings > **Sources**: **edit** a source (pencil button: name, server, username, password, playlist address, TV guide — favorites, recents and channel fixes are kept), refresh it, delete it, see the state of its TV guide. The **eye** button shows the password (or the TMDB key) so you can check it. Sources refresh at startup when their last update is more than 6 hours old (adjustable). If a refresh returns an empty section, the previous one is kept.
<!--/pc-->

While the channels, movies and series of a subscription are being checked or downloaded (and when the lists are recalculated after a category change), an **Updating the catalog** banner appears at the top of the screen. The app may seem frozen for a few seconds, or up to a minute on a large catalog: this is normal, and the banner disappears by itself.

# Navigating

## The Home screen {#accueil}

<!--mac-->
![The Home screen](img:home)

Kastideo opens on the **Home** screen, from top to bottom:

- the **search field**, which searches channels, movies and series at once; clicking a result opens it;
- the large **Live**, **Movies** and **Series** tiles, and **My videos** as soon as a [Folders, Jellyfin, Emby or Plex](help:mes-videos) source exists; each tile shows the number of channels, movies, series or videos;
- the **Favorites**, **Recents**, **TV Guide**, **YouTube** and **Recordings** buttons (a badge shows the number of items, or pending recordings and downloads);
- the **On TV now** row: chips by theme (Sport, News, Movies…) and **Tonight**, which open [live by theme](help:direct-theme);
- the **Continue watching** row: movies and episodes you started, one click resumes where you stopped;
- if something is playing, a **Now playing** banner lets you **go back** to it or **stop** it.

To return Home at any time: the **Home** (house) button at the top left of the toolbar, **⌘0**, the **Home** row of the sidebar, or the **H** key in the TV interface.

The **version number** is shown discreetly at the bottom right, next to the **?** and **Buy me a coffee** buttons; clicking the version opens what's new.
<!--/mac-->
<!--pc-->
![The Home screen](img:homepc)

Kastideo opens on the **Home** screen, from top to bottom:

- the **header**: logo, name and, on the right, three buttons: **Help** (**F1**), **Playback log** and **Settings** (**Ctrl+,**); a small spinner turns while sources refresh;
- the **search field**, which searches channels, movies and series at once; clicking a result opens it;
- the large **Live**, **Movies** and **Series** tiles, and **My videos** as soon as a [Folders, Jellyfin, Emby or Plex](help:mes-videos) source exists; each tile shows the number of channels, movies, series or videos;
- the **Favorites**, **Recents**, **TV Guide**, **MultiView**, **YouTube** and **Recordings** buttons (a badge shows the number of items, of channels in MultiView, or pending recordings and downloads);
- the **Continue watching** row: movies and episodes you started, one click resumes where you stopped;
- if something is playing, a **Now playing** banner lets you **go back** to it or **stop** it;
- if no source has been added, a **No source** card offers **Add a source**.

At the bottom right: the **Buy me a coffee** button (can be hidden in Settings > About) and the version number.

To return Home at any time: the **Home** row of the sidebar, **Ctrl+0**, or the **H** key in the TV interface.

**On Android phones and tablets**, Home adapts to the screen width: below about 720 px (phone, or tablet in portrait), the four tiles go to **two columns** and the header shrinks. **On Android TV**, buttons are chosen with the remote (visible outline) and **OK** opens.
<!--/pc-->

## My videos {#mes-videos}

<!--mac-->
As soon as a **Folders**, **Jellyfin**, **Emby** or **Plex** source exists, a **My videos** tile appears on the home screen (and a row in the sidebar, **⌘8**). It gathers your videos, apart from IPTV:

- **Featured**: **Resume playback** (started movies and episodes), **Recently added**, **Movies to watch**, then a Movies, Series and Videos row;
- **Movies**, **Series**, **Videos**: grids with search, filters (**genre**, **year**, **unwatched**) and sorting (title, recently added, year);
- **Folders**: browse your folders and subfolders as in the Finder (breadcrumb to go back up), and the servers' libraries;
- **Sources**: all, or just one (NAS, Emby, Plex…). An orange triangle flags an error: right-click > **Error details…** shows the request and the **exact server response** (**Copy** button), then **Retry**.

In **Movies** and **Series**, the **All / IPTV / My videos** selector (sidebar, above the categories) chooses what is shown: IPTV only (default), your videos only, or both mixed. The categories of your videos are never hidden by the countries setting.
<!--/mac-->

<!--pc-->
As soon as a **Folders**, **Jellyfin**, **Emby** or **Plex** source exists, a **My videos** tile appears on the home screen (shortcut **Ctrl+8**). It gathers your videos, apart from IPTV:

- **Featured**: **Resume playback** (started movies and episodes), **Recently added**, **Movies to watch**, then a Movies, Series and Videos row;
- **Movies**, **Series**, **Videos**: grids with search, filters (**genre**, **year**, **unwatched**) and sorting (title, recently added, year);
- **Folders**: browse your folders and subfolders as in the file explorer (breadcrumb to go back up), and the servers' libraries;
- **Sources**: all, or just one (NAS, Emby, Plex…). An orange triangle flags an error: right-click > **Error details…** shows the request and the **exact server response**, then **Retry**.

In **Movies** and **Series**, the **All / IPTV / My videos** selector (sidebar, above the categories) chooses what is shown: IPTV only (default), your videos only, or both mixed. The categories of your videos are never hidden by the countries setting.
<!--/pc-->

## Remove an item from “Continue watching” {#retirer-reprise}

<!--mac-->
Right-click a thumbnail in **Continue watching** (home, Cinema interface, My videos; long press on Android) to get:

- **Remove from “Continue watching”**: the thumbnail disappears from the row, but the **position is kept**: when you play the film again later, it resumes where you left off.
- **Clear “Continue watching”**: removes every thumbnail from the row.

An **Undo** banner stays visible for a few seconds. A removed item **comes back** to the row as soon as you watch it again; meanwhile it appears in “Recently watched”.
<!--/mac-->

## Sort and filter My videos {#filtres-videos}

<!--pc-->
On **Windows, Linux and Android**, the **arrow** button reverses the sort order and **Group by** arranges posters in **sections** (source, category / folder / album, type, year, month added; several criteria at once). Everything is remembered.
<!--/pc-->

In **My videos**, the **Movies**, **Series** and **Videos** views have a filter bar. Your choices are **remembered** and restored at the next launch. **Reset** clears every filter (the sort order is kept).

- **Source**: when several sources are added (local folder, Emby, Jellyfin, Plex…), show only one of them. In the "all sources" view, a **badge** on each poster shows where the movie comes from.
- **Genre**, **Year**.
- **Country** and **Language**: from the TMDB details (or from the Emby, Jellyfin or Plex server).
- **Quality**: **4K** (2160p, UHD), **HD** (1080p, 720p, Blu-ray, WEB-DL…) or other, from the file name.
- **Status**: **Unwatched**, **In progress**, **Watched** or **Favorites**.
- **Sort**: title, recently added, year, **TMDB rating** or **duration**.

Ratings, durations, countries and languages of the files in your folders come from TMDB (a [TMDB key](help:tmdb) is required): they appear as the details are looked up, which takes a few minutes the first time. A movie with no rating comes last when sorting by rating.

## Window layout and sidebar {#colonnes}

![Window layout and sidebar](img:layout)

<!--mac-->
In the Classic interface, the window has three columns:

- **Sidebar**: Home, Live, Movies, Series, Favorites, Recents, TV Guide, then the categories of the chosen section and the status of your sources.
- **List**: the items of the section or category, with the current program for channels. The **Search** field filters the list regardless of case and accents.
- **Player**: the video, with the current program, its progress and the upcoming programs below it.

Right-clicking an item lets you add it to favorites or copy the stream address.
<!--/mac-->

<!--pc-->
Live / Movies / Series picker, then: all channels or movies, **Favorites**, **Recents**, and for live TV **Themes**, **TV Guide** and **MultiView**; **Recordings**; the **categories**. At the bottom: the current recording and download (progress, time left) and **Settings**.
<!--/pc-->

## Three interfaces to choose from {#interfaces}

<!--mac-->
Kastideo offers three presentations, which you choose **separately for live, movies, series, and favorites / recents**:

- **Classic**: the three columns described in [Window layout and sidebar](help:colonnes).
- **TV** (live only): see [The TV interface](help:interface-tv).
- **Cinema**: a large scrolling **“featured” banner** (see [The “featured” banner](help:bandeau)), then **horizontal rows**: continue watching, favorites and one row per category. Movies and series appear as posters, channels as thumbnails with the current program. A click on a channel opens the player full frame. A click on a **movie** or **series** poster first opens its **details page**: backdrop, poster, year, runtime, genres, rating, synopsis, director, cast (with photos), a **Back to Movies** (or Series) button at the top left, **Play** / **Resume**, **View Episodes**, **Trailer**, **Download** and favorite buttons. Information comes from your IPTV provider; add a free **TMDB** key (Settings > General > Movie and Series Details) for richer pages. **Back** (or Esc) returns to the catalog. At the top of the window, the **Live / Movies / Series / Guide / Favorites / Recents / Recordings** tabs replace the sidebar; search works as in Classic. “See All” opens a complete category as a grid.

To change the interface:

- the **Interface** button in the toolbar (it applies to the type of content displayed),
- the **View** menu: **⌥⌘1** Classic, **⌥⌘2** Cinema, **⌥⌘3** TV (live),
- or **Settings > Appearance**.

For example: TV for live and Cinema for movies and series. The **Recordings** section is always shown in the Classic interface. The default is Classic everywhere.
<!--/mac-->

<!--pc-->
Settings > Appearance > **Interface per content type**:

- **Classic**: three columns (sidebar, list with the current programme, player or details on the right).
- **Cinema**: featured banner, posters or thumbnails in horizontal rows, full-page details. For live TV: "Sport right now", "Live news", "Tonight" rows per theme, favorites, recents, categories; a click opens the channel full frame, **Back** (or Esc) stops it.
- **TV** (live only): the channel full frame, like a television (see [The TV interface](help:interface-tv)).
<!--/pc-->

## The “featured” banner (Cinema) {#bandeau}

<!--mac-->
At the top of Movies and Series, a **full-width carousel** scrolls through a selection: backdrop, poster, title, year, runtime, genres, rating, synopsis and **Play** (or **Resume** / **View Episodes**), **More Info** (the details page) and **Trailer** buttons. It mixes:

- this week's **TMDB trends** found in your catalog (TMDB key required);
- your provider's **latest additions**;
- a **selection from a category** of your choice (for example “New releases” or “Netflix”), or from the whole catalog at random.

Scrolling pauses while the mouse is over the banner; arrows and dots let you navigate. In **Live**, the banner shows **what's on now** on your favorite and recent channels, with progress, the next program and **Watch**.

Settings > Appearance > **“Featured” Banner**: show or hide, height (compact, normal, large), scrolling speed, carousel sources and movie and series categories.
<!--/mac-->

<!--pc-->
It cycles through movies or series (this week's TMDB trends available to you, latest additions, a category selection) or, for live TV, the current programme of your channels. Arrows on hover, pauses while the mouse is over it. Settings > Appearance > **Featured banner**: show or hide, height, speed, sources.
<!--/pc-->

## Countries and languages (Cinema) {#pays}

<!--mac-->
Providers often mix several countries (categories “FR| …”, “|PT| …”, “ITALIA”…). Settings > Appearance > **Countries and languages (Cinema interface)** lists the countries found in your category names, with the number of items: tick the ones you want to see. **Latest additions**, **trends**, the **featured banner** and **category rows** of the Cinema interface then only show those countries. **Keep categories without a country** keeps categories such as “Action” or “New”. **All countries** goes back to the full display. Classic lists and search stay complete.
<!--/mac-->

<!--pc-->
Providers often mix several countries (categories “FR| …”, “|PT| …”, “ITALIA”…). Settings > Appearance > **Countries and languages (Cinema interface)** lists the countries found in your category names, with the number of items: choose the ones to show. **Latest additions**, **trends**, the **featured banner** and **category rows** of the Cinema interface then only show those countries. **Keep categories without a country** keeps categories such as “Action” or “New”. **All** goes back to the full display. Lists and search stay complete.
<!--/pc-->

## The TV interface (live) {#interface-tv}

<!--mac-->
The channel fills the whole frame, like on a television. The first time it appears, Kastideo resumes the last channel you watched.

- **Channel panel**: **←** key, **Return**, or move the mouse to the left edge. It lists channels with number, logo, current program and progress. The menu at the top filters by **All / Favorites / Recents / category**, and the **Search** field filters by name. It closes by itself after a few seconds (**→** or **Esc** to close it right away).
- **Zapping**: **↑ / ↓** previous / next channel in the displayed list, **B** back to the previous channel.
- **Channel number**: type the digits (for example **1** then **2**); the channel opens after 1.6 s or with **Return**. If your provider does not number its channels, the number refers to the position in the displayed list.
- **Information banner**: shown for five seconds at each channel change (logo, number, current program, times, next program, time). **I** or **→** shows or hides it.
- Other keys: **F** favorite, **M** mute, **Space** pause (live timeshift).
- Double-click the picture or **⌘↩**: full screen; the toolbar is hidden.
- Keyboard keys do not work while typing in the search field. The tabs at the top of the window let you switch to Movies, Series, etc.
<!--/mac-->

<!--pc-->
- **↑ / ↓**: previous / next channel; **type a number** (up to 4 digits).
- **←** or left edge: **channel panel** (filter, search, current programme).
- **→** or **I**: **info banner** (current and next programme).
- **B**: previous channel — **F**: favorite — **M**: sound — **Space**: pause — **G**: TV guide — **H**: home.
<!--/pc-->

## The TV Guide grid {#guide-grille}

<!--pc-->
Settings > General > Start page > **When opening the guide**: **Now** (current time) or **Last position** (the time and category of your last visit). On a series page, **Watched / unwatched** marks a season or the whole series.
<!--/pc-->

<!--mac-->
The **TV Guide** section (sidebar, **TV Guide** tab of the Cinema and TV interfaces, **⌘7**, or the **G** key in the TV interface). Channels are in rows, hours in columns; the red line marks the current time.

- **‹ ›** shift the grid, **Now** goes back to the current time, the date menu jumps to another day (7 p.m. for the following days).
- Choose the time span shown (**2 h / 3 h / 6 h**), filter by **favorites**, **recents** or **category**, or search for a channel.
- Click a program: description, **Watch** button, **Record** (current program) or **Schedule Recording** (upcoming program). A red dot marks a scheduled recording.
- Past days (date menu, **Watch again** section) and programmes marked ↺ allow **replay** (see [Replay](help:replay)).
- Click a channel name to watch it. Only channels that have programs are listed: if the grid is empty, check the guide address in the source settings.
<!--/mac-->

<!--pc-->
Home, live sidebar, **Ctrl+7** or the G key in the TV interface. Channels in rows, hours in columns, a red line at the current time; **‹ Now ›**, day picker, 2 h / 3 h / 6 h span, filter (all, favorites, recents, theme, category) and search. A click on a programme opens its details: **Watch**, **Record**, **Schedule recording** (red dot in the grid) or **Alert me when it starts** (bell). On a past programme of a channel with replay (↺): **Watch again** or **Save this replay**; past days are in the date menu.
<!--/pc-->

## Live TV by theme {#direct-theme}

<!--mac-->
The **Themes** section of the sidebar (under Live) sorts live TV by **theme** — Sports, Auto & Moto (motorsport), Movies, Series, News, Documentaries, Nature / Hunting & Fishing, Kids, Entertainment, Food & Home, Music, General, Regional (France 3 regions, local TV), International (foreign channels), Religion, Radio — without the categories you hid. Three modes:

- **On now**: what is airing now, sorted by the **program's genre** in the TV guide (a movie on a general channel shows up in “Movies”), with progress. Channels **with no guide data** are still listed when their **name is enough to classify them** (beIN Sports → Sport…): they show their name, without progress.
- **Tonight**: programs starting between **8 and 11 pm**. Right-click an upcoming program > **Alert Me When It Starts**.
- **Channels**: channels sorted by specialty. The theme is deduced automatically from the channel name (beIN, Eurosport → Sports; BFM, LCI → News…) then from its usual programs; right-click > **Channel Theme** to correct it.

Each channel appears **only once**, even if your provider offers it in several versions (4K, FHD, HD, SD): Kastideo picks the version suited to **your connection** (**Automatic** setting in Settings > General > Playback > Channel version) — it steps down after unstable playback and back up after three smooth ones. Right-click > **Version** to choose another.

Themes are also offered elsewhere: “Sports On Now”, “Movies On Now”… rows at the top of Live in the **Cinema** interface, a **Themes** filter in the **TV** interface's channel panel and the **TV Guide**, and “On TV Now” (and “Tonight”) chips on the **Home** screen.

In **Sports**, a second row filters by **discipline**: Football, Rugby, Tennis, Basketball, Combat sports, Golf, Cycling, Handball, Motorsport, Winter sports, Horse racing, Athletics & swimming (from program titles, genres and descriptions).

**Adult content**: channels and content whose name contains “|XX|” (or in an adult category) are **hidden everywhere** by default. To show them, and the **Adult** theme: Settings > General > Playback > **Show adult content**. An optional 4-digit **PIN code** protects this setting: once set (Settings > Adult content > PIN code, on all Android, Windows and Linux versions), it is asked to show or hide adult content, and to change or remove it. It is included in the configuration export. On Android TV, the code can be entered with the remote's **number keys**, or with ▲ ▼ ◀ ▶.

**Program alerts** (🔔 button of the Themes view): Kastideo alerts you two minutes before a program starts whose title contains a chosen word (“PSG”, “Formula 1”…), of a theme on your favorite channels, or a specific program. A notification and a **Watch** banner appear.
<!--/mac-->

<!--pc-->
Sidebar > **Themes**: **Right now**, **Tonight** (8–11 pm) or **Channels**, filtered by theme (Sport, News, Movies, Kids, Documentaries…) and, for sport, by discipline. One version per channel (FHD, HD or SD depending on your connection). Right-click: channel version, **channel theme** (to fix the classification), favorites, edit the channel.
<!--/pc-->

# Playback

## The essentials {#lecture}

<!--pc-->
On **Windows, Linux and Android**, the **⋯** menu in the player bar offers **speed** (movies, episodes), **audio tracks**, **subtitles** and **picture format** (fit, fill the screen, 16:9, 4:3). In live TV, **◀◀ / ▶▶** switch to the previous or next channel of the category, and the bar shows the **current programme** with its progress and the next one. For an episode, **Next** and **Episodes…** appear, and the next episode starts by itself at the end (can be turned off in Settings > General > Playback).
<!--/pc-->

<!--mac-->
Kastideo plays all content with the **VLC** engine: live MPEG-TS (.ts), HLS (.m3u8), MP4, MKV, AVI…

- Playback starts as soon as you select a channel, a movie or an episode.
- While opening, the channel logo and name are shown. The **“Ready in x s”** badge then shows the start-up time (can be turned off in settings).
- Controls appear when you hover over the video: play / pause, back 10 s and forward 30 s for movies and episodes, progress bar, volume (up to 200%) and theater mode.
- A click on the video pauses it; a **double-click** turns on **theater mode**: the window goes full screen and only the **video** remains visible (no columns or toolbar; the green window button and **⌃⌘F** do the same during playback). **Esc** or **⌘↩** to leave it.
- **Resume playback**: for movies and episodes, Kastideo remembers your position. When you reopen one, playback resumes where you stopped, with a message offering to **start over**. Progress bars appear in lists, posters and episodes. This can be turned off, and positions can be erased, in settings.
- For Xtream sources, live is played in MPEG-TS (.ts) format, like the Xtream reference player; if the stream fails, Kastideo automatically tries the .m3u8 variant (and vice versa).
<!--/mac-->

<!--pc-->
The player (mpv engine) has a control bar that hides by itself, a stream health dot, volume, cinema mode (double-click or Ctrl+Enter) and full screen (F11). For movies and episodes: mini timeline, −10 s / +30 s, **resume** where you left off, **Back to details**.
<!--/pc-->

## Control bar, timeline and information panel {#barre-controle}

<!--mac-->
- **Auto-hiding bar**: it appears on the slightest mouse movement and hides, along with the pointer, after 3 seconds of inactivity (it stays while the mouse is over it, while paused or when the panel is open).
- **Stop** (■ button next to play / pause, or **⌘.**): stops the stream. The video area shows “Nothing playing” with a **Restart** button; the position of a movie or episode is remembered for resuming. While casting, stopping also ends the cast and the TV returns to its programme. If the channel is being recorded, Kastideo asks for confirmation (the recording stops with playback).
- **Mini-timeline** (movies and episodes): a thin line above the buttons that thickens on hover and shows the target time; click or drag to move.
- **Stream health**: a **green** (Excellent), **orange** (Fair) or **red** (Unstable) dot shows reception quality, with the definition (SD, HD, 4K). On hover: exact resolution, bitrate, frames per second, dropped pictures and interruptions in the last minute.
- **Information panel** (ⓘ button or **⌘I**, Esc to close): it slides in from the right over the video and shows the channel with its current and upcoming programs, or a movie's synopsis and cast; the **audio track** (language, audio description…) and **subtitles** choice; detailed reception quality.
<!--/mac-->

## MultiView (several channels at once) {#multivue}

<!--mac-->
**MultiView** shows up to **4 live channels** in one window (1 full frame, 2 side by side, 3 or 4 in a grid). **Sound follows the active tile** (orange border): click a tile or use keys **1 to 4**.

- Open it: **Playback > MultiView…** (**⌥⌘M**), or right-click a channel > **Add to MultiView**.
- In the window: **+** adds a channel (favorites, recents or search); hovering a tile, ⟳ changes the channel and ✕ removes it; **Stop All** stops every stream. Closing the window stops MultiView.
- Each stream uses **one connection** to your provider, so MultiView is **off by default**: enter your subscription's number of simultaneous connections in **Settings > General > Playback** (2 to 4) to enable it. An Xtream source's **Test Connection** button shows this number. When opened, main playback stops to free its connection (unless recording); a recording or download also uses a connection.
<!--/mac-->

<!--pc-->
**MultiView** shows up to **4 live channels** on one screen. **Sound follows the active tile** (orange border).

- **Enabling**: each channel uses a connection to your provider, so MultiView stays off until you set the number of **simultaneous connections** of your subscription: Settings > General > Playback (2 to 4). **Detect** asks your Xtream sources.
- **Opening**: home > **MultiView**, live sidebar > **MultiView**, **Ctrl+Alt+M**, or right-click a channel > **Add to MultiView**. The channel you were watching becomes the first tile; if it is being recorded, it keeps recording in the background, muted.
- **Adding**: **+** button (or **A** key): favorites, recents, all channels or search. An empty cell of the grid also offers "Add a channel".
- **Layouts** (top right): **Automatic** (1 full frame, 2 side by side, 3 or 4 in a grid), **2 × 2 grid**, **One large** and the others small, **Side by side**. The layout is remembered.
- **Large view ↔ tile**: **double-click** a tile (or press **G**) to make it large with sound; double-click the large view again to go back to the grid.
- **When hovering a tile**: enlarge, change channel, remove. The channel name and current programme show at the bottom.
- **Saved groups** (bookmark icon): **Save this group…** stores the channels and the layout under a name (e.g. "Football multiplex"); click a group to reopen it, the cross deletes it.
- **Keyboard**: **1 to 4** sound on that tile, **G** enlarge, **A** add, **M** mute, **Del** remove the active tile, **F** or **F11** full screen, **Esc** leave full screen then MultiView.
- **Stop all** (or Back) stops every stream and returns to the previous screen.

> A recording or a download also uses a connection: an ⓘ icon reminds you in the MultiView bar. If a tile says "The channel is not responding", the provider is probably refusing an extra connection: remove a channel or lower the number of connections.
<!--/pc-->

## Several live sources: MultiView and picture in picture {#multivue-sources}

If you have **several live sources** (two IPTV subscriptions, or a subscription and a list of public channels), [MultiView](help:multivue) **mixes** them. There are three steps.

**1. Connections of each subscription.** In **Settings > General > Playback**, one line per subscription (name + account ID, to tell two accounts from the same provider apart) sets the number of simultaneous streams it allows: 1 for most subscriptions, 4 for a public list. On Windows, Linux and Android, **Detect** queries Xtream accounts.

**2. Number of screens.** In the MultiView window, set the number of **screens** (1 to 4, at most the sum of your sources' connections).

**3. Source of each screen.** Each screen is **reserved for one source**: the badge at the top of the screen lets you change it. The channel picker of that screen only offers channels from its source, and a source cannot reserve more screens than it has connections.

**Layout**: side by side, stacked, grid, or **one large + thumbnails (PIP)** (MultiView layout menu). In the latter, one channel fills the frame and the others float as **small 16:9 thumbnails**: **drag** a thumbnail to move it (it snaps to the nearest corner), **double-click** it to swap it with the large one (the sound follows), and set their **size** (small, medium, large) in the MultiView bar. A single click gives a thumbnail the sound.

**Choosing a channel.** The picker mirrors the Classic interface: on the left **Favorites**, **Recents** and the **categories of the screen's source** (in your order, with hidden or renamed categories from "Manage categories"), on the right the channels with their current programme. A **click** plays the channel on the screen and keeps the picker open for zapping; a **double-click** plays it and closes. A channel already shown on another screen is greyed out. Search covers all categories of the source.

**Where to find MultiView?** On Mac: the **MultiView** entry in the sidebar, the toolbar button, the **MultiView** button on the Home screen (next to Favorites and Recordings), the player bar button (opens MultiView with the channel you are watching), the Playback menu and ⌥⌘M. On Windows, Linux and Android: Home, the Live sidebar, the player bar button and Ctrl+Alt+M.

**Picture in picture (PIP).** While a live channel plays, the **picture in picture** button (top right of the player) opens a **second channel in a small window** in a corner, muted. **Click the small window** to swap it with the main channel, or the cross to close it. The second channel must come from a source with a free connection: with a single subscription limited to one connection, pick a channel from the public list (or a second subscription). The small window closes when you leave the player.

## If a channel does not start {#chaine-ne-demarre-pas}

<!--mac-->
If no picture arrives after **20 seconds**, Kastideo automatically tries the other stream format (.ts or .m3u8), then shows an error message with the details returned by the VLC engine.

The **Log** (menu **Playback > Playback Log…**, **⌥⌘L**, or the button in the error message) is Kastideo's diagnostic tool. User names and passwords are **hidden** in it: you can copy it to share it if you have a problem.

- **Topics**: messages are sorted into *TV Guide*, *Playback and relay*, *Sources and catalogues*, *Recordings*, *TMDB details*, *Updates* and *Display and other*. Click one or more topics to see only those (the number of lines for each topic is shown).
- **Search** a word in the log, or show only **errors and warnings**.
- **Copy what is shown** copies only what is displayed (topics, search), with the filter noted at the top.
- **Level of detail** (per topic): *Normal* (the essentials), *Detailed* (default for the TV Guide) or *Debug* (everything). The setting applies to lines written from then on; errors and warnings are always kept.
- **Current session / Previous session**: the log is kept on disk, so you can read what happened at startup in the previous session. **Show the log folder** reveals the file in the Finder.
<!--/mac-->

## Live timeshift {#differe}

<!--mac-->
**Pause** a live channel: the VLC engine keeps receiving the stream and stores it. When you resume, you are watching in **timeshift** (yellow “TIMESHIFT −2:34” indicator in the controls). If a stream cannot be paused, the button is greyed out.

In timeshift, the controls offer:

- a **timeline**: the pause point on the left, **live** on the right. **Drag the cursor to the right** to move forward: Kastideo speeds up playback until the chosen point (yellow marker), then returns to normal speed;
- **+30 s** (or ⌘]): move forward 30 seconds the same way;
- the **speed** (×1, ×1.25, ×1.5, ×2): speed up to reduce the delay; playback returns to ×1 by itself when it catches up with live;
- **Catch up**: speeds up until live, without skipping anything;
- **Back to live**: returns to live immediately. As the VLC engine usually cannot jump inside the timeshift buffer, the stream is reopened and the buffer cleared. If the stream allows seeking, the buffer is kept and −10 s / +30 s jump directly.

**Where is the timeshift stored?** In Kastideo's temporary folder (`~/Library/Containers/fr.jmezes.kastideo/Data/tmp/`, `vlc-timeshift-…` files), cleared when you change channel; allow 1 to 4 GB per hour depending on quality. Settings > General > Playback: **Maximum timeshift duration** (30 min to 3 h, or unlimited; once reached, playback resumes by itself), **Catch-up speed**, and a **Show** button to open the folder.
<!--/mac-->

<!--pc-->
Pause a channel (or go back with ← or the bar): it keeps being buffered (up to 1 h by default, adjustable). Without any action from you, the channel stays “LIVE”. The timeshift bar shows the delay, a slider to go back or catch up faster, the speed, **Catch up** and **Back to live**. ← / →: −10 s / +30 s.
<!--/pc-->

## Replay: watching a programme that already aired {#replay}

<!--mac-->
Some IPTV subscriptions keep channels for up to **14 days** (depending on the provider and the channel). Kastideo detects this by itself: channels with replay show a **↺** icon in lists and in the TV Guide.

- **In the TV Guide**: click a **past** programme (marked ↺), then **Watch again**. On the **current** programme, **Watch from the start** replays it from the beginning. **Save this replay** downloads the programme from the provider's archive (recordings folder).
- **Previous days**: the date menu of the TV Guide offers **Watch again (replay)** with the past days.
- **From a channel**: right-click the channel > **Watch again (replay)** (recent programmes of that channel). The Cinema interface also has a **To watch again** row (your favourite channels with replay).
- **During a replay**, the player bar lets you pause and move within the programme. At the end, Kastideo **returns to the channel's live stream** (can be turned off).
- **Settings > General > Replay**: turn replay on or off, number of **days of past programmes kept in the guide** (more days = more memory), **time offset** (if the replayed programme is shifted by a few minutes or an hour, fix it here; the server's time zone is read automatically), return to live.
- A replay counts as **one connection**: it closes the current channel, like switching channels.
- If a replay does not start, open the **Log** (topic “Playback and relay”): the archive address built and the offset used are listed there. The provider's guide must contain past programmes: reload it after increasing the number of days kept.
<!--/mac-->

<!--pc-->
Some IPTV subscriptions keep channels for up to **14 days** (depending on the provider and the channel). Kastideo detects this by itself: channels with replay show a **↺** icon in lists and in the TV Guide.

- **In the TV Guide**: click a **past** programme (marked ↺), then **Watch again**. On the **current** programme, **Watch from the start** replays it from the beginning. **Save this replay** downloads the programme from the provider's archive (recordings folder).
- **Previous days**: the date menu of the TV Guide offers **Watch again (replay)** with the past days.
- **From a channel**: right-click the channel > **Watch again (replay)…** (recent programmes of that channel). The Cinema interface also has a **To watch again** row (your favourite channels with replay).
- **During a replay**, the player bar lets you pause and move within the programme. At the end, Kastideo **returns to the channel's live stream** (can be turned off).
- **Settings > General > Replay**: turn replay on or off, number of **days of past programmes kept in the guide** (more days = more memory), **time offset** (if the replayed programme is shifted by a few minutes or an hour, fix it here; the server's time zone is read automatically), return to live.
- A replay counts as **one connection**: it closes the current channel, like switching channels.
- If a replay does not start, open the **Log** (button Log, topic “Playback and relay”): the archive address built and the offset used are listed there. The provider's guide must contain past programmes: reload it after increasing the number of days kept.
<!--/pc-->

## One connection at a time {#connexion-unique}

<!--mac-->
Most IPTV subscriptions allow only **one simultaneous stream**. Kastideo always closes the current stream before opening the next one: you can zap without risk of exceeding your limit. If playback fails, check that no other device (TV, phone, Piboard…) is watching with the same subscription.
<!--/mac-->

<!--pc-->
Most subscriptions allow a single connection. Kastideo closes the previous channel before opening the next (**stream relay**, Settings > General > Playback) and asks before interrupting a recording.
<!--/pc-->

## Cast to a TV {#cast}

Send what you are watching — **a live channel, movie, series, local video or YouTube** — to a TV on the same network, without leaving Kastideo. The playback bar stays your remote control.

### What is possible

- **Chromecast, Google TV, Android TV** (and many TVs with built-in Chromecast): the whole playback goes to the TV.
- **Apple TV (AirPlay)**: Kastideo cannot send the video directly. Use macOS **screen mirroring** (see below).
- **YouTube**: the video opens in the TV's YouTube app, or in the browser (your choice in Settings).

### Cast something

1. Start a channel, movie, series or video.
2. In the playback bar, click the **TV** button.
3. Pick the device from the list. If nothing shows, click **Search again**: the TV must be on and on the same network.
4. The picture goes to the TV. On the computer a screen says “Casting to…”.

Playback **resumes where you were**. Pause, play, 10 / 30 s skip, position, volume and mute in the bar act on the TV. Starting another item while casting sends it to the TV as well.

To come back, choose **Stop casting** (or **Resume on the computer**): playback resumes on the computer at the same position.

<!--pc-->
### ffmpeg: converting the video

On Windows and Linux, Kastideo prepares the video with **ffmpeg** before sending it to the TV. It ships with the Windows version and the Linux AppImage. With the .deb package, install it: `sudo apt install ffmpeg`. If Kastideo cannot find it, give its path in **Settings > General > Cast**.

- **Video preparation**: *Automatic* copies the video when it is already H.264 (light on the computer) and converts it otherwise; *Always convert* is the most compatible.
- **Maximum resolution**: 720p or 1080p.
- **Add a TV by its IP address**: useful if automatic search cannot see it (guest Wi-Fi, VLAN…).

Windows Firewall may ask to allow Kastideo: accept on **private** networks, otherwise the TV cannot read the stream.
<!--/pc-->
<!--mac-->
### Apple TV and AirPlay

VLC, Kastideo's playback engine, does not send video over AirPlay. For an Apple TV: **Control Center > Screen Mirroring** (or **System Settings > Displays**), pick the Apple TV, then play Kastideo full screen. The TV button in the bar offers a shortcut to the display settings.

### Network permission

On first use, macOS asks whether Kastideo may **find devices on the local network**: accept, otherwise no TV will appear (System Settings > Privacy & Security > Local Network > Kastideo). The TV button's menu has a shortcut to this setting. If it is already allowed, choose **Search again** and check that the Mac and the TV are on the same network (no guest Wi-Fi, no VPN).
<!--/mac-->

### YouTube on the TV

In **Settings > General > Cast**, choose:

- **The TV's YouTube app**: Kastideo asks the TV to open YouTube on the chosen video (right-click a video > **Play on a TV**). The YouTube app must be installed on the TV.
- **Browser (Chrome's Cast button)**: the video opens in your browser; use Chrome's **Cast** button to send it to the TV.

### Limits to know

- One connection to your provider: while casting, the computer no longer plays the channel (see [One connection at a time](help:connexion-unique)).
- **Live** cannot be skipped through while casting; the computer's **time-shift** is cut.
- Channel **recording** and **MultiView** do not combine with casting.
- There are a few seconds of delay, more than with local playback.
- A TV that does not answer the search: check that it is on and on the same Wi-Fi or Ethernet network as the computer.

## Frozen picture: software decoding {#image-figee}

Some channels show a picture and then stay **frozen** while the stream keeps arriving. The usual cause is the computer's **hardware decoder** (graphics card or video chip) failing on that stream. **Software decoding** uses the processor instead: heavier, but more tolerant.

### Automatic fallback

By default, when the picture stays frozen for more than 6 seconds (or the hardware decoder reports repeated errors), Kastideo **reopens the channel with software decoding** and remembers it: later plays of that channel use software straight away. An explanatory line is added to the **Playback log** ("Décodage : … réouverture en décodage logiciel").

<!--pc-->
On Windows and Linux, detection relies on the number of pictures shown by the engine and on its hardware-decoder error messages. If a channel freezes without being detected, turn software decoding on by hand (below) and let us know.
<!--/pc-->

### By hand

- **For one channel**: right-click the channel > **Software decoding (frozen picture)**. The channel reopens immediately; repeat to go back to the hardware decoder.
- **For everything**: <!--mac-->**Settings (⌘,) > General > Playback**<!--/mac--><!--pc-->**Settings (Ctrl+,) > General > Playback**<!--/pc--> > **Always decode in software**. Uses more power and processor, especially in 4K.
- **Turn off the automatic fallback**: same place, **Automatic software decoding when the picture freezes**.
- **Forget everything**: the "Reset" button (Mac) or "Forget channels set to software decoding" (Windows/Linux) clears the remembered list.

### If that is not enough

A channel that stays frozen even in software usually has a faulty stream at the provider: check the **Playback log** and try another version of the channel (HD, SD…).

## Buffer {#tampon}

<!--mac-->
In **Settings > General > Playback**, choose the trade-off between speed and stability:

- **Fast** (default): 0.4 s of reserve, the shortest zapping.
- **Balanced**: 1 s.
- **Stable**: 3 s, for unreliable connections or servers (fewer interruptions, slower start).
<!--/mac-->

## The Log (diagnostics) {#journal}

<!--pc-->
The **Log** (**Ctrl+Alt+L**, or the button on the home screen and in error messages) is Kastideo's diagnostic tool. User names and passwords are **hidden** in it: you can copy it to share it.

- **Topics**: *TV Guide*, *Playback and relay*, *Sources and catalogues*, *Recordings*, *TMDB details*, *Updates*, *Display and other*. Click one or more topics to see only those (the number of lines per topic is shown).
- **Search** a word, or show only **errors and warnings**.
- **Copy what is shown** copies only what is displayed, with the filter at the top.
- **Level of detail** (per topic): *Normal*, *Detailed* (default for the TV Guide) or *Debug* (everything). The setting applies to lines written afterwards; errors and warnings are always kept.
- **Current session / Previous session**: the log is kept on disk (the folder path is shown at the bottom of the window), so you can read what happened at startup in the previous session.
<!--/pc-->

# Recordings and downloads

## Overview {#enregistrements}

<!--mac-->
Everything is in the **Recordings** section of the sidebar (**⌘6**): current recording, conversions, downloads, schedules and recorded files (click to watch them, right-click to show them in Finder or delete them).

Files are stored in **~/Movies/Kastideo** (can be changed in **Settings > Recordings**) and named automatically, for example “TF1 – Le goût du détail – 2026-10-18 20h50”.

**Recording duration.** Recording **starts immediately**, with no question asked. A “Recording started” banner then lets you pick when to stop: in 15 min, 30 min, 1 h, 2 h…, **at a specific time**, or **no limit**. If you choose nothing, recording stops at the **end of the programme** (TV guide, margin included) or, when the guide does not know it, after the **default duration** set in **Settings > Recordings** (2 h to begin with; “No limit” is possible). You can change the stop at any time with the **Duration** button on the “Recording in progress” row, which also shows the time left.
<!--/mac-->

## Recording live {#enregistrer}

<!--mac-->
- While a channel is playing, click **●** in the controls, **Record** under the video, or use **⇧⌘R**. The **REC** badge shows the duration.
- Recording stops automatically at the end of the current program (according to the TV guide, plus the margin after), or when you click **■**.
- It uses **the same connection** as playback: nothing more is consumed from your subscription.
- Right-click a channel > **Record Now**: if you are watching another channel, Kastideo asks whether to stop playback, then records in the background.
- A **banner** at the bottom of the window confirms when a recording starts and ends and shows **the folder** where the file is (**Show** button). If the folder chosen in settings is no longer accessible, the file is placed in ~/Movies/Kastideo and the banner says so. Detailed steps are in the **Playback Log**.
- **While recording**, the file is visible and growing in the **In progress** subfolder of the recordings folder (a folder named after the program). When stopped, it is moved to the recordings folder and the subfolder is removed. If the VLC engine does not create the file within 10 seconds, Kastideo automatically retries in a temporary folder (the file then appears only when stopped); “Recording impossible” is shown only after both attempts, with details in the Playback Log (⌥⌘L). Length is limited only by disk space: count about 1 to 3 GB per hour depending on the channel (a warning appears below 3 GB free).
- At the end, the recording is **converted to MP4** with no quality loss (playable in QuickTime, on iPhone and iPad). The .ts file appears first, then is replaced by the .mp4 when conversion is done (a few minutes for 2 hours; shown in the Recordings section). The picture is copied with no loss; **audio is converted to AAC** (some channels broadcast MP2 or AC-3 audio that QuickTime plays silently). DVB subtitles and teletext, which MP4 cannot hold, are dropped; if conversion fails, a second attempt keeps only the picture and main audio, and as a last resort the .ts is kept. This can be turned off in settings.
<!--/mac-->

<!--pc-->
Red round button in the player bar, **R** key, or right-click a channel > **Record now**: the channel is recorded until the end of the current programme (plus the margin) or until you stop it, in **Videos/Kastideo/Enregistrements**.

- The stream bytes are copied as is to a **.ts** file, losslessly: the watched channel is copied from the relay (no second connection to the provider); another channel is downloaded directly, reconnecting if the stream drops.
- At the end, the .ts is converted losslessly to **MKV** (default format, Settings > Recordings); if conversion fails, the .ts is kept — it plays everywhere.
- HLS streams (.m3u8) and playback without the relay still go through the video engine.
<!--/pc-->

## Scheduling a recording {#programmer}

<!--mac-->
- In the TV guide under the video, **double-click** an upcoming program, or right-click > **Schedule Recording**. A red dot marks scheduled programs.
- Right-click a channel > **Schedule a Recording…** (or the calendar icon under the video): choose a program from the guide or custom times.
- **Margins** before and after (2 and 5 minutes by default, adjustable) avoid missing the beginning or the end.
- At the scheduled time, recording starts in the background. If you are watching another channel, Kastideo asks whether to stop playback; without a reply, recording starts after 60 seconds.
<!--/mac-->

<!--pc-->
- **Right-click a live channel > Schedule a recording…**, or the **Schedule…** button of the Recordings screen (then choose the channel: favorites, recents or search).
  - **Guide programmes**: the channel's next programmes, with **Schedule** (or **Record** for the current one). A check mark shows those already scheduled.
  - **Time slot**: day, start and end time, optional title — for a channel without TV guide or a specific show. An end earlier than the start finishes the next day.
  - **Repetition** (list at the top right): **once**, **every day**, **Monday to Friday** or **every week**. The next occurrence is added automatically; the ⟲ button of a repeated recording in the list stops repeating.
- From the details of an upcoming programme (TV guide, themes): **Schedule recording**.
- Margins before and after (Settings > Recordings) are added. Kastideo must be open at the scheduled time: turn on **Start Kastideo when I sign in** if needed (Settings > General).
<!--/pc-->

## Downloading a movie or episodes without watching {#telecharger}

<!--mac-->
- Right-click a movie or an episode > **Download** or **Download Tonight**, or the **Download** button under the video.
- For a series: the **Download** button on its page > the displayed season or the whole series.
- Downloads run **one after the other** (queue). “Tonight” starts at 2 a.m. by default (adjustable).
- You can pause, resume or cancel each download in the Recordings section.
- **Permanent indicator**: as long as a download is active, a progress ring stays visible in the toolbar. A click opens the details: progress of the current movie or episode, “episode X of N”, progress of the series or batch, speed and **estimated time remaining** (refined as the download goes on).
<!--/mac-->

<!--pc-->
**Download** button on a movie's details (now or **tonight**), **Download the season** or each episode's icon for a series, right-click > Download. One download at a time, resumed after an interruption, paused during playback (adjustable). Files go to **Videos/Kastideo/Films** and **Séries/<series>**.
<!--/pc-->

## Single connection: who has priority? {#priorite}

<!--mac-->
Your subscription allows only one connection. Kastideo therefore does only one thing at a time and **always asks you** before interrupting something:

- You change channel during a recording: Kastideo asks whether to **stop the recording**.
- You start playback during a download: the download is **paused** and resumes by itself when playback stops.
- Files that are already recorded can be watched at any time, even during a background recording.
<!--/mac-->

## Recordings screen {#ecran-enregistrements}

<!--pc-->
Current recording (stop), downloads (pause, resume, cancel), scheduled recordings and history, files in the folder: a click plays them, right-click to show them in the folder or delete them.
<!--/pc-->

## Details in your language {#fiches-langue}

<!--pc-->
With a **TMDB key** (Settings > General), titles, summaries, genres and episodes come from TMDB, in the interface language. When the only summary available is the provider's in another language (Portuguese, Spanish…), it is folded: **Show the summary (Portuguese)** shows it anyway. It doesn't appear in the banner or the episode list.
<!--/pc-->

## Good to know {#bon-a-savoir}

<!--mac-->
- Kastideo must **stay open** and the Mac **on** for scheduled recordings and overnight downloads. Kastideo prevents automatic sleep during activity and in the hour before, but not manual shutdown or sleep.
- A **macOS notification** signals the start and end of recordings and downloads (can be turned off).
- **Automatic cleanup** (optional): recordings older than the chosen number of days are moved to the Trash.
- An alert warns you when disk space gets low.
- Copying rights depend on your provider's conditions: Kastideo records for your private use what your subscription already gives you.
<!--/mac-->

## Cleaning up the recordings list {#nettoyer-liste}

<!--mac-->
In the **Recordings** section you can **remove finished recordings from the list** (schedules, downloads and the recording in progress are never touched).

- **One recording**: the row's trash button, or right-click > **Remove from list…**.
- **Several**: the **Select** button, tick the rows (or **Select all**), then **Remove selection**.
- **Everything**: the **Clear list…** button.

A dialog then opens. By default **only the list is cleaned**: the file stays in the recordings folder and will not reappear in the list. Tick **Also delete the file(s) from storage** to erase it too (Trash on Mac); the space freed is then shown. **Remember this choice** keeps your answer for next time.

After a simple removal from the list, an **Undo** banner stays visible for about ten seconds.

If a file no longer exists in storage, or cannot be deleted, the removal carries on anyway: a notification warns you, and with several warnings a window lists them.
<!--/mac-->

# Organize and customize

## Fixing a channel {#corriger}

<!--mac-->
Some channels are badly referenced by the provider (wrong name, wrong programs, missing logo). Right-click the channel > **Edit Channel…**:

- **Name** and **number** (used for number zapping in the TV interface);
- **Logo**: an image address, or **Choose a File…** (the image is copied into Kastideo);
- **TV guide programs**: if the programs shown are wrong or missing, search the right channel in the list (provider guide and backup guide); the program on now helps recognize it.

The fix only applies to **this version** of the channel (FHD, HD, SD… are fixed separately) and survives source refreshes. **Restore Original** undoes it.
<!--/mac-->

<!--pc-->
Right-click a channel > **Edit channel…**: name, number, logo (image address or a file copied into Kastideo) and **TV guide** channel (search among the provider and fallback guides). The fix applies to this version of the channel (HD, FHD…) and survives every refresh. **Restore** goes back to the original.
<!--/pc-->

## Organizing categories {#categories}

<!--mac-->
You don't have to put up with your provider's category list and order. Open **View > Manage Categories…** (**⌥⌘C**), the button next to the “Categories” title in the sidebar, or right-click a category. Choose the section (**Live**, **Movies** or **Series**), then:

- **Reorder**: drag categories in the list, or use the **…** menu > **Move to Top / Bottom**. **Sort A → Z** sorts everything alphabetically.
- **Select / deselect all**: the box above the list ticks or unticks all listed categories at once. With a search (for example “PT”), it only affects the categories found: handy to hide a whole country in one go, then show only the ones you want.
- **Hide**: uncheck a category (or right-click > **Hide This Category** in the sidebar). A hidden category disappears **everywhere**: sidebar, Live / Movies / Series lists, search, TV Guide, Cinema and TV interfaces, featured banner. Your favorites and recents stay available.
- **Hide by keyword**: type for example “PAKISTAN” or “ARABIC”: every category whose name contains it is hidden, including ones the provider adds later. Click a keyword's cross to undo it.
- **Rename**: the pencil gives a more readable name (“FRANCE FHD | OTT” → “France HD”); **Original Name** undoes it.
- **Show All** shows hidden categories again; **Reset…** goes back entirely to the provider's layout.

New categories added by the provider appear next to their original neighbor.
<!--/mac-->

<!--pc-->
- **Right-click a category** in the sidebar: **Rename…**, **Move to top**, **Move up**, **Move down**, **Move to bottom**, **Hide this category**, **Manage categories…**.
- **Settings > Categories** (or the icon next to "Categories"): for live TV, movies or series — drag to reorder, untick to hide everywhere, double-click to rename, **keywords** to hide every category containing them at once (e.g. "PAKISTAN"), **Sort A to Z**, **Restore**.
- **Select / deselect all**: the box above the list ticks or unticks all listed categories at once. With the **search** (e.g. "PT"), it only affects the categories found: hide a whole country in two clicks, then tick only the ones you want.

A hidden category is hidden everywhere: lists, search, home, rows.
<!--/pc-->

## Fix the details of a movie or series {#corriger-fiche}

When the poster, title or summary of a movie or series is wrong (two movies share the same title, for example), you can **link it to the right TMDB entry** or **enter the details yourself**. It works for **My videos** (folders, Jellyfin, Emby, Plex) as well as for movies and series of the **IPTV subscription**, on Mac, Windows, Linux and Android.

### Open the window

Right-click (or long-press) the movie or series, then **Fix details…**; the link is also at the bottom of the details page.

### Link to a TMDB code

1. On **themoviedb.org**, find the right movie. The **number** is in the page address: `themoviedb.org/movie/12345-hero` → **12345** (for a series: `…/tv/1399-…`).
2. In Kastideo, enter that number, or **paste the full address**, then **Check**.
3. A preview (poster, title, year, summary) appears: if it is the right one, **Use this entry**.

A [TMDB key](help:tmdb) is required. If the address is a series while you are fixing a movie (or the reverse), Kastideo tells you.

### Search by title

Below the code, the title and year search offers a list of entries: tap the right one. The TMDB number is shown next to each result.

### Customise by hand

**Customise the entry by hand** lets you enter a **title**, a **year**, a **poster address** (https://…) and a **summary**. These fields replace those from the provider and TMDB; fields left empty change nothing. They combine with a TMDB code.

### Remove a correction

In the window, **Remove the correction** goes back to automatic lookup. **Settings > General > Movie and series details** also lists every corrected entry (**Entries corrected by hand**) with a **Remove** button for each.

### Backup

Corrections are part of the **configuration backup** (Settings > Backup): they follow your exports and imports from one device to another.

### Good to know

- For IPTV subscription movies, the correction applies to the **details page**; the list thumbnail keeps the provider's image.
- For My videos, the list poster is updated too.

## Arrange the order of channels and categories {#arranger}

**Arrange** mode lets you put **the channels, movies or series of a category** in the order you want, and also reorder **the categories** themselves. It is available on **Windows, Linux and Android** (not on Mac yet). It works with a finger as well as a mouse: the list scrolls normally, and only the **⋮⋮ handle** on the left moves a row.

### Reorder the items of a category

1. Open a category in the sidebar (for example "SPORT").
2. Tap the **Arrange** button (↑↓ arrows) to the right of the list title.
3. **Press and hold the ⋮⋮ handle** of a row, then **drag it** to its new place. To scroll the list, touch anywhere other than the handle.
4. Tap **Done** when you are happy with the order. It is saved automatically.

The three dots on the right of a row offer:

- **Move to top** and **Move to bottom** (handy in a long list);
- **Move to another category…**: pick a category or type the name of a **new personal list** (for example "My picks") to gather channels from several categories;
- **Put back in its original category**.

At the top of Arrange mode:

- **A → Z** sorts by name; **By number** sorts channels by number;
- **Provider order** cancels your order for this category.

Arranging is not available during a search, nor in Favorites and Recents (they have their own order).

### Reorder the categories

Open **Settings > Categories** (or the button to the right of the "Categories" title in the sidebar). Press and hold the large ⋮⋮ handle on the left of a category and drag it. **Reset** also clears channel orders and moves.

### Backup

Your order, personal lists and moves are part of the **configuration backup** (Settings > Backup): they follow your exports and imports.

## Start page for Live, Movies and Series {#page-depart}

By default, opening **Live**, **Movies** or **Series** shows all channels or all content, starting with the provider's first category. You can choose what is shown first instead.

### Choose the start page

<!--mac-->
1. Open **Settings (⌘,) > General > Start page**.
<!--/mac-->
<!--pc-->
1. Open **Settings (Ctrl+,) > General > Start page**.
<!--/pc-->
2. For **Live**, **Movies** and **Series**, choose separately:
   - **All**: the full list (default);
   - **Favorites** or **Recents**;
   - **Last viewed**: the category you were in last time;
   - or **a specific category** from the provider.

### From the sidebar

**Right-click** a category, then **Set as start category**. The same menu lets you **stop using** it as the start category.

### When does it apply?

Every time you open Live, Movies or Series from another section (home, TV guide…), including at launch. Once in the section you browse freely: clicking **Live**, **Movies** or **Series** in the sidebar when you are already there shows the full list.

If the chosen category is hidden, renamed or no longer exists at the provider, Kastideo shows the full list. Choose it again in Settings.

## Several accounts: active source, duplicates and diagnostic {#sources-multiples}

When you have **two or more IPTV accounts**, Kastideo lets you choose the one that is displayed, **without disabling** the others in the settings.

### Choose the active source

- On **Mac**, a **Source** menu appears in the sidebar. On **Windows, Linux and Android**, the **Source** menu is in the sidebar (on a phone: in the menu drawer).
- Choose **All sources** or a specific account. Next to each name, three numbers: **channels · movies · series** returned by the provider.
- The choice filters **Live, Movies, Series, search and the TV guide**, and is **remembered** between launches.
- [My videos](help:mes-videos) folders and servers always stay visible.

### Merge duplicates

With **All sources**, a movie or series provided by several accounts (same title, same year) is listed only **once**. Untick **Merge duplicates** to see everything. Favorites and recents already saved keep working.

### Why do two accounts of the same level have different movies?

**Channels** are often identical, but **movie and series catalogues** depend on the account: many providers give each account different video-on-demand bouquets. If the numbers differ, it is most often **on the provider's side**.

### The Diagnostic button

In **Settings > Sources**, an account's **Diagnostic** button (stethoscope) shows:

- the account status (status, expiry, connections);
- for channels, movies and series: the number **returned by the provider**, the number of categories, and the number **actually shown**;
- what Kastideo **hides**: hidden categories, adult content, merged duplicates.

If "returned by the provider" differs between your two accounts, the difference comes from the provider. The **Copy** button lets you attach the result to a message to your provider.

## Favorites and recents {#favoris}

<!--mac-->
- Add a favorite with the star in the information panel, right-click or **⌘D**.
- The **Recents** section keeps the last 60 items you watched.
- **Removing from recents**: right-click an item > **Remove from Recents** (or the **⌫** key on the selected item in the Classic interface). For several items, click **Edit**, tick the items, then **Delete**; **Select All** ticks the whole list and **Clear All** empties the history.
- After a deletion, an **Undo** banner stays visible for a few seconds to restore everything.
- Recents can also be cleared in settings, **General** tab.
<!--/mac-->

<!--pc-->
Star in the player bar, **F** key or right-click > Add to favorites. Recents keep the last 60 items opened.

- **Edit** (next to the "Recents" title): tick items then **Remove selection**, or a row's cross to remove it alone; **Select all** and **Clear all** (for the section shown). **Done** goes back to the list.
- Right-click an item > **Remove from recents**.
- Settings > **History** > **Recents** > **Clear** clears them all, every section.
<!--/pc-->

## Alerts and notifications {#alertes}

<!--pc-->
- **Alert me when it starts** on an upcoming programme's details (bell in the guide).
- **Keywords** (Settings > Recordings): a programme whose title contains a keyword triggers an alert, on your favorite channels or on all of them.
- The alert shows at the top right of Kastideo with **Watch**, and the window comes back if it was minimized.
- **System notifications** (Settings > General > Notifications, on by default): alerts, recording start and end, download finished or failed also appear in the Windows or Linux notification center, even when Kastideo is behind another window. Clicking the notification brings Kastideo back.
<!--/pc-->

## Appearance {#apparence}

<!--pc-->
Settings > **Appearance**:

- **Theme**: **Dark** (default), **Light** or **Same as system** (follows Windows or Linux). The player, TV interface, MultiView, home screen, details pages and the featured banner stay dark, as on Mac.
- **Accent color**: default (Kastideo blue), blue, purple, pink, red, orange, green or teal — used for selections, buttons, switches.
- **List density** (Classic interface): compact, standard or spacious.
- **Thumbnail size** (Cinema interface): small, medium or large.
- **Interface** per content type and **featured banner** (see [Three interfaces](help:interfaces)).

Changes apply immediately, without restarting.
<!--/pc-->

# YouTube

## YouTube: browse and play {#youtube}

The **YouTube** section (sidebar, Home button,
<!--mac-->**⌘9**<!--/mac--><!--pc-->**Ctrl+9**<!--/pc-->) works in two steps: a **browser** first, then the **player** as soon as you pick a video.

![From browser to player](img:youtube)

### The browser

- **My channels**: paste a channel link or its @handle in the field at the top to follow it. Its latest videos appear in a row, with no key and no account. To bring in all your subscriptions at once: [Import my subscriptions](help:youtube-import).
- **Search**: type your search in the same field (thumbnail results, sorted by relevance, date or views, more pages). It needs a **free Google API key**: [the step-by-step guide](help:youtube-cle).
- **Pasted links**: a video plays, a playlist becomes the play queue, a channel is followed.
- **Favorites and history**: right-click a thumbnail; the history keeps the last 80 videos (with a button to clear it).
- **Watch later**: right-click a thumbnail to set a video aside. A video you started **resumes where you left off** (a red bar shows progress); it leaves the list once watched to the end.

### The player

<!--mac-->
Clicking a video replaces the browser with the player; the list you came from becomes the queue. Previous / Next buttons, **Autoplay next**, **Loop**, **Mute** and **Open on YouTube** sit in a bar that hides itself; **Esc** or **YouTube browser** takes you back to the list.
<!--/mac-->
<!--pc-->
Clicking a video opens the player in **its own window** (Edge or Chrome on Windows, Chrome or Chromium on Linux in “app” mode; otherwise your default browser); the list you came from becomes the queue. Previous / Next buttons, **Autoplay next**, **Loop**, **Mute** and **Open on YouTube** sit in a bar that hides itself. A banner in Kastideo reminds you of the current video, with **Reopen window**.
<!--/pc-->

IPTV playback stops while YouTube plays (unless a recording is in progress).

> About ads and your Google account: see [Ads, account and privacy](help:youtube-confidentialite).

## Import my YouTube subscriptions {#youtube-import}

YouTube does not let an app like Kastideo sign in to your account. Google does let you **export your data**, though: you ask only for your list of subscriptions, a small `subscriptions.csv` file that Kastideo reads **on your computer**.

![The import steps](img:takeout)

### Step 1: ask Google for the export

1. Open [Google Takeout](https://takeout.google.com/) while signed in to the **Google account** whose subscriptions you want.
2. Click **Deselect all** (at the top of the list).
3. Scroll down to **YouTube and YouTube Music** and tick the box.
4. Click **All YouTube data included**, click **Deselect all**, tick only **subscriptions**, then **OK**.
5. At the very bottom, click **Next step**. Keep **Send download link via email**, **Export once** and the **.zip** format, then click **Create export**.
6. Google prepares the archive (a few minutes, sometimes more) and sends you an e-mail. Click **Download your files** in the e-mail and save the `.zip`.

### Step 2: find the file

1. Open the `.zip`: <!--mac-->double-click it in the Finder<!--/mac--><!--pc-->right-click > **Extract all** (Windows) or double-click (Linux)<!--/pc-->.
2. Open **Takeout** > **YouTube and YouTube Music** > **subscriptions**.
3. The file is called **subscriptions.csv** (or **abonnements.csv** if your account is in French).

### Step 3: import it in Kastideo

1. Open **YouTube** > **My channels**.
2. Click **Import my subscriptions…** and choose the file.
3. Kastideo adds the channels and loads their latest videos (with many subscriptions, the first refresh can take a minute).

> Channels you already follow are not added twice. The file is read only by Kastideo, on your machine: nothing is sent to Google or anywhere else, and Kastideo never accesses your account.

### If it does not work

- **“No new channel found in this file”**: it is not the right file (for example the watch history), or the channels are already followed. Go back to step 2.
- **No e-mail from Google**: check your junk folder, or go back to [Google Takeout](https://takeout.google.com/): the “Manage exports” section lets you download the archive again.
- **No “subscriptions” folder**: in step 1.4, check that the **subscriptions** box was ticked.
- Without a file, you can follow one channel at a time by pasting its link or @handle: see [YouTube](help:youtube).

## Getting a Google API key (search) {#youtube-cle}

YouTube **search** uses Google's official interface (“YouTube Data API v3”) with **your own key**. It is **free** and enough for about **100 searches a day**. Without a key everything else works: following channels, playing pasted links, favorites, history.

### Create the key (5 minutes, once)

1. Open the [Google Cloud console](https://console.cloud.google.com/) and sign in with a Google account.
2. At the top, click the project selector > **New project**. Give it a name (for example “Kastideo”), click **Create**, then select it.
3. Open [the YouTube Data API v3 page](https://console.cloud.google.com/apis/library/youtube.googleapis.com) and click **Enable**.
4. Menu **APIs & Services > Credentials** > **Create credentials** > **API key**.
5. Copy the key shown (about forty characters starting with “AIza”).
6. Optional but recommended: **Edit key** > **API restrictions** > **Restrict key** > tick **YouTube Data API v3**.

### Give it to Kastideo

1. Open **Settings > General > YouTube**.
2. Paste the key in **Google API key** and confirm.
3. Go back to **YouTube**: search now works.

<!--mac-->
The key is stored in the **macOS keychain**, never in clear on disk, and is never published.
<!--/mac-->
<!--pc-->
The key is stored in the **system vault** and is never published.
<!--/pc-->

> Quota: each search uses 100 of the 10,000 free daily units. If you reach the limit, Kastideo shows “YouTube API error”; search comes back the next day. Following channels and playing videos does not use this quota.

### When something goes wrong

- **“API key missing”**: nothing is saved in Settings.
- **“API key not valid” / “YouTube API error”**: the key was copied incorrectly, or step 3 (enabling the API) was not done for **this** project.
- **Restriction error**: if you restricted the key, check that **YouTube Data API v3** is ticked.

## Ads, account and privacy {#youtube-confidentialite}

### Ads

Kastideo uses the **official YouTube player in “privacy-enhanced mode”** (youtube-nocookie.com), the one Google gives websites to embed videos: it sets no tracking cookie and so shows no personalised ads, usually none at all.

**This is not an ad blocker**: nothing is intercepted or bypassed, and YouTube remains free to show ads, which fund creators.
<!--pc-->
If your browser has its own ad blocker, it applies in the player window.
<!--/pc-->

### Why can't I sign in to my account?

The privacy-enhanced player does not recognise your account: no personalised recommendations, no automatically synced subscriptions, no YouTube Premium (which removes ads on youtube.com, not in an embedded player). That is the price of tracking-free playback. To get your subscriptions back, use the [step-by-step import](help:youtube-import).

### What Kastideo keeps

Your followed channels, favorites, history (80 videos), “watch later” list and resume points are stored **on your computer only**. Any API key stays in the system vault. Nothing is sent to Kastideo or to anyone other than YouTube / Google when you search or play a video.

# Settings and maintenance

## Keyboard shortcuts {#raccourcis}

<!--mac-->
- **⌘0**: Home
- **⌘1 to ⌘7**: Live, Movies, Series, Favorites, Recents, Recordings, TV Guide
- **⌥⌘1 / ⌥⌘2 / ⌥⌘3**: Classic / Cinema / TV interface (for the type of content displayed)
- TV interface: **↑ ↓** zapping, **←** channel panel, digits = channel number, **I** banner, **B** previous channel, **G** TV guide, **H** home, **F** favorite, **M** mute
- **⌘↑ / ⌘↓**: previous / next item (zapping)
- **⌘K**: play / pause
- **⌘[ / ⌘]**: back 10 s / forward 30 s (movies and episodes)
- **⌘↩** or double-click the video: theater mode (Esc to leave)
- **⌘.**: stop playback
- **⇧⌘R**: record the channel being watched / stop recording
- **⌥⌘L**: log
- **⌘D**: add or remove from favorites
- **⌘R**: refresh all sources
- **⌘,**: settings and sources
- **⌘?**: this help (opens on the page for the current screen)
- **⌘8**: My videos, **⌘9**: YouTube
<!--/mac-->

<!--pc-->
- **Ctrl+0**: home — **Ctrl+1**: live — **Ctrl+2**: movies — **Ctrl+3**: series — **Ctrl+7**: TV guide — **Ctrl+Alt+M**: MultiView — **Ctrl+,**: settings
- **Space**: play / pause — **M**: sound — **F**: favorite — **R**: record / stop — **← / →**: −10 s / +30 s — **Ctrl+.**: stop playback
- **Ctrl+Enter** or double-click the picture: cinema mode — **F11**: full screen — **Esc**: leave cinema mode, back to details or rows
- TV interface: **↑ / ↓** zapping, **digits** channel number, **←** panel, **→ / I** banner, **B** previous channel, **G** guide, **H** home
- MultiView: **1 to 4** sound, **G** enlarge, **A** add, **Del** remove, **F** full screen, **Esc** leave
- **Ctrl+Alt+L**: log
- **Ctrl+8**: My videos, **Ctrl+9**: YouTube
- **F1**: this help (opens on the page for the current screen)
<!--/pc-->

## General settings {#reglages}

<!--mac-->
- **Language** (**General** tab): Kastideo is available in **French, English, Spanish, German, Italian and Portuguese**. The language is chosen at first launch, then can be changed in **Settings > General > Language** (or “System” to follow the Mac's language). The change applies after the app restarts, which Kastideo offers to do for you. Help and menus follow the chosen language; release notes remain in French.
- **Appearance** (**Appearance** tab): dark theme (default), light or same as system; **accent color** (System, blue, purple, pink, red, orange, green, teal); **interface** Classic or Cinema for each type of content; **list density** (compact, standard, spacious) for the Classic interface; **thumbnail size** (small, medium, large) for the Cinema interface.
- **Movie and Series Details** (**General** tab): optional **TMDB** API key (free at themoviedb.org > Settings > API; v3 key or v4 read token), stored in the keychain. **Save and Verify** checks it. Without a key, details come from your IPTV provider.
- **Refresh at launch**: reloads sources whose last refresh is more than 6 hours old.
- **Cache**: Kastideo keeps a local copy of lists and the TV guide to start instantly. **Clear and Reload** erases this copy and restarts loading.
<!--/mac-->

<!--pc-->
- **General**: language (on next launch), resume playback, stream relay, refresh at startup, clear recents, **simultaneous connections** (MultiView), **system notifications**, TV guide and fallback guide, adult content (hidden by default), TMDB key, **startup and .m3u files**, **updates**.
- **Appearance**: theme, accent color, list density, thumbnail size, interfaces, featured banner.
- **Sources**: add, refresh, delete, guide state.
- **Categories**: order, hiding, names, keywords.
- **Recordings**: folder, format, margins, downloads, timeshift, alerts.
- **Backup**: export or import the configuration.
<!--/pc-->

## Getting a TMDB key (free) {#tmdb}

<!--mac-->
TMDB (The Movie Database) is a community movie and TV database. Its key is **free** for personal use; it lets Kastideo show cast photos, HD posters and backdrops, the trailer and a translated synopsis.

1. Create an account on **themoviedb.org** (“Join TMDB”), then confirm it with the link sent by e-mail.
2. Signed in, open **themoviedb.org/settings/api** (avatar > Settings > API), or click **Get a Free Key** in Kastideo's settings.
3. Click **Create**, choose **Developer** and accept the terms of use.
4. Fill in the form: usage type **Personal**, application name **Kastideo**, URL **https://github.com/jihemezes/kastideo**, a short summary (“Personal IPTV player, shows movie details”), then your contact details.
5. Submit: the page shows an **API Key** (32 characters) and an **API Read Access Token** (long, starts with “eyJ”). Kastideo accepts either; the API key is easier to copy.
6. In Kastideo: **Settings (⌘,) > General > Movie and Series Details**, paste the key and click **Save and Verify**. “Valid key ✓” confirms it.
7. Reopen a details page (or click **Refresh** at its bottom): it is now completed by TMDB.

The key is stored in the Mac keychain. **Remove Key** goes back to IPTV provider information only.
<!--/mac-->

<!--pc-->
Create an account on themoviedb.org, then **Settings > API** and request a key (personal use). Paste the "API key" (v3) or the "read access token" (v4) into Settings > General, then **Save**. Details become richer (posters, cast, trailers, summaries and episodes in your language).
<!--/pc-->

## Posters and summaries for your personal videos {#tmdb-perso}

For the movies and series in your **folders**, Kastideo can look up the poster and summary on **TMDB** (a [TMDB key](help:tmdb) is required).

Because a file name has no year or tag, the search is **cautious**: a match is accepted only if its **title (or original title) is exactly the file's name**. Names glued with inner capitals (**TearsOfSteel**) are split (Tears Of Steel). Names entirely in glued lowercase ("bigbuckbunny") are not recognised.

- Setting: in **Settings**, section **Movie and series details**: **Also look up personal videos**. On by default; turn it off to avoid any lookup.
- If a match is missing or wrong (two movies share the same title, for example), use [Fix details](help:corriger-fiche): you can link the movie to the right **TMDB code**.

## Startup and .m3u files {#demarrage}

<!--pc-->
Settings > General > **Startup and files**:

- **Start Kastideo when I sign in** (Windows and Linux), and **Start minimized** in the taskbar: scheduled recordings and alerts only happen while Kastideo is open.
- **Open .m3u and .m3u8 files with Kastideo** (optional): double-clicking a playlist offers to add it as a source (Settings > Sources); if Kastideo is already open, the existing window receives it. If Windows keeps opening another program, right-click the file > Open with > Choose another app > Kastideo. On Linux, the association is saved in your profile (file `~/.config/mimeapps.list`); if an error message appears under the switch, it gives the cause.

Both options are also offered by the Windows installer (unticked by default).
<!--/pc-->

## Backup and transfer {#sauvegarde}

<!--mac-->
Settings > General > **Backup and transfer**:

- **Export configuration…** saves a `Kastideo-configuration.json` file: sources (Xtream and M3U playlists by address), favorites, recents, custom categories (order, hidden, names, keywords), chosen interfaces and TMDB key. Tick **Include passwords** so nothing has to be typed again; keep the file somewhere safe.
- **Import configuration…** adds the content of a file: on a new Mac, or from Kastideo for Windows and Linux (same format). Sources already present are recognised and nothing is deleted.

Jellyfin, Emby and Plex servers are exported (with their password or token if you tick **Include passwords**). M3U playlists added as local files and folders are not imported on another Mac (the files do not exist there or must be chosen again).
<!--/mac-->

<!--pc-->
Settings > **Backup**: **Export configuration…** (sources and their guide, passwords if you wish, favorites, recents, categories, interfaces, appearance, number of connections, adult content, banner, TMDB key) and **Import configuration…**. The file is the same as Kastideo for Mac: you can move from one computer to the other in both directions. Nothing is deleted on import. Jellyfin, Emby and Plex servers are included (password or token too, if requested); folders as well, with their paths (to fix if they differ on this computer).
<!--/pc-->

## Updates {#mises-a-jour}

<!--mac-->
Kastideo updates itself thanks to **Sparkle**, the reference tool for Mac apps distributed outside the App Store.

- **At launch** (a few seconds after starting), then once a day if Kastideo stays open, Kastideo discreetly checks whether a new version is available on GitHub.
- If so, a **banner** at the top of the window announces it — **never while watching or recording** (it waits for playback to end). The update is **optional**: **Update…** opens the release notes window then **Install Update** (Kastideo quits, installs and relaunches); **Later** hides the banner until the next launch; **Skip This Version** stops offering it (the next one will be offered).
- You can check at any time with **Kastideo > Check for Updates…**.
- Every update is signed: Kastideo refuses to install a file that does not come from its publisher.

In **Settings > Updates**:

- **Check for updates at launch**: turns the launch and daily check on or off.
- **Receive test versions (beta)**: also offers beta versions, which bring new features earlier but may be less stable. Turn the option off to return to stable versions at the next update.

> Versions 0.1.0 and earlier cannot update themselves: install 0.2.0 by hand once, and the following ones will arrive on their own.
<!--/mac-->

<!--pc-->
Kastideo checks GitHub for new versions at launch and then every 12 hours (Windows / Linux pre-releases, while these versions are in preview).

- A new version is announced by a **banner at the bottom right**, only when you are not watching anything. **View** opens the update window with its release notes; the cross postpones it.
- **Install and restart** downloads the file matching your installation, then:
  - **Windows, installed**: runs the new installer silently, then restarts Kastideo;
  - **Windows, portable**: replaces the folder's files after closing, then restarts Kastideo;
  - **AppImage**: saves the new AppImage next to the old one, deletes the old one and launches it;
  - **.deb package**: installs it with apt (your password is asked), then restarts Kastideo.
- A recording in progress is finished cleanly before closing.
- **Skip this version**: it won't be offered again (a manual check offers it again).
- Settings > General > **Updates**: installed version and installation type, **Check now**, automatic checks, **What's new in recent versions**, releases page on GitHub.
- On the first launch after an update, the **What's new** window sums up the changes.
<!--/pc-->

## Installation {#installation}

<!--pc-->
- **Windows (recommended)**: run **Kastideo-…-windows-x64-setup.exe**. By default Kastideo installs for you only, without administrator rights (in your AppData folder); the installer also offers to install for all users, a desktop icon, opening .m3u files and starting at sign-in. Uninstall: Windows Settings > Apps > Kastideo.
- **Windows, portable**: unzip the "windows-x64.zip" archive anywhere and run **kastideo.exe** (nothing is installed; updates replace the folder's files).
- The app is not signed: if SmartScreen says "Windows protected your PC", click **More info** then **Run anyway**.
- **Zorin OS 17 / Ubuntu 22.04**: "ubuntu22.04_amd64.deb" package (double-click or `sudo apt install ./kastideo_…deb`).
- **Zorin OS 18 / Ubuntu 24.04**: "ubuntu24.04_amd64.deb" package.
- **Any distribution, and Raspberry Pi (64-bit)**: AppImage file; make it executable (right-click > Properties > Allow executing, or `chmod +x`) and run it.
<!--/pc-->

## Kastideo on Android and Android TV {#android}

Kastideo is also available for **Android phones and tablets** and for **Android TV** (Google TV, Chromecast with Google TV, Nvidia Shield, Philips, Sony, TCL TVs…). It is the same app, with the same sources, categories, favorites, guide, replay, recordings, MultiView and YouTube, adapted to touch and to the remote. A single **APK** file works on phones and on TVs.

### Choose the right file

On the GitHub releases page, look for the `Kastideo-…-android-….apk` files:

- **arm64-v8a**: almost all recent phones, tablets and TV boxes (the right choice when in doubt);
- **armeabi-v7a**: older devices and some 32-bit TV boxes;
- **x86_64**: emulators and a few Intel tablets;
- **universal**: every processor, but larger.

### Install without turning security off

Android does **not** require you to turn its protections off: it asks for a permission for **one app only** (the one that opens the APK: browser, file manager or Downloader).

1. Download the APK, then open it.
2. If Android says "For your security, installing unknown apps is blocked", tap **Settings** and turn on **Allow from this source** for the app you are using (Chrome, for example). Other apps stay blocked.
3. Go back and tap **Install**.
4. If **Play Protect** flags an app from an unknown developer, tap **More details** then **Install anyway**: Kastideo is not published on Google Play, and it is signed by its developer, not by a publisher listed with Google.

All Kastideo APKs are signed with the same key: Android therefore accepts updates over the existing installation, without losing your settings.

### Install on Android TV

A TV often has no browser or file manager. Three methods:

- **Downloader** (free app from the TV's Play Store): type the download address of the GitHub APK, then allow Downloader to install apps;
- **USB stick**: copy the APK to the stick, plug it into the TV and open it with a file manager (Solid Explorer, File Commander…);
- **From your phone**: send the APK with "Send Files to TV", or install it with `adb install` if network debugging is on.

Kastideo then appears in the TV's app list with its banner.

### Using touch (phone, tablet)

- **☰ menu** at the top left: the sections (Live, Movies, Series, Favorites, categories…) open in a drawer.
- **Long press** on a channel, a movie or an episode: the menu (favorite, record, replay, software decoding…), like a right-click on a computer.
- **In the player**: one tap shows or hides the bar; **double tap** left = −10 s, right = +30 s, centre = pause; **swipe vertically** on the right = volume, on the left = brightness; **swipe horizontally** = skip forward or back in a movie.
- **Back** (Android gesture or button): closes the player, then returns to the home screen.
- Turn the device to **landscape**: the current channel goes full screen.

### Using the remote (Android TV)

On Android TV, Kastideo shows screens designed for the remote: the selected item is **outlined in orange, enlarged and glowing**, as on Apple TV.

On Android TV, **Settings** open in panels: the menu takes the left 2/5 and its content unfolds in the right 3/5; one more level slides left and partly covers the parent menu (◀ to go back). The **Start page** setting chooses the category shown when entering Live, Movies or Series. Home shows the logo next to the name and as a watermark.
- **Arrows** move the selection; **OK** confirms; **Back** goes back (player → episodes → details → list → home).
- **Home**: tiles Live, Movies, Series (and My videos), then **Continue watching** (posters of started movies and episodes, **OK** opens the page), then the buttons Search, Favorites, Recents, TV Guide, Recordings, MultiView (if your sources allow two connections), Help and Settings.
- **Search, Favorites, Recents, Help**: in Search, **OK** on the field opens the TV keyboard; confirm, then **▼** to browse results (channels, movies, series, my videos). Favorites and Recents: poster grid, **OK** opens the item. Help: this help, readable with the remote (**▲ ▼** scroll).
- **Movies and series**: categories on top (**←/→**), posters below. **OK** opens the details; for a series, **Episodes** shows the seasons (**←/→**) and episodes (**↑/↓**).
- **Live**: **↑ / ↓** or **Channel +/−** change channel, **digits** enter a number, **←** opens the channel list, **→** shows the info banner. In the list, **↑ / ↓** browse the channels **without changing channel** and **OK** plays the highlighted one; **←** moves to the **categories** column (**↑ / ↓** change category), **→** or **OK** goes back to the channels; **Menu** adds to favourites.
- **While playing**: **OK** = pause, **←/→** = −10 s / +30 s, **↑ / ↓** = volume; Play/Pause and Fast-forward/Rewind keys are supported.
- **Add a source without a keyboard**: Settings > **Add a source with my phone**. The TV shows a **QR code** and a 4-digit code; on your phone (same Wi-Fi), open the address, enter the code, then the source details (Xtream or M3U list). **Remove a source** is in the same place.
- **Phone setup** (same page as adding a source): besides **Xtream** and **M3U** subscriptions, the phone sends a **Jellyfin**, **Emby** or **Plex** server, **folders** the TV can read (USB drive, network share already mounted) and the **TMDB key**. These additions appear in **My videos**.
- **Phone setup** (same page as adding a source): besides **Xtream** and **M3U** subscriptions, the phone sends a **Jellyfin**, **Emby** or **Plex** server, **folders** the TV can read (USB drive, network share already mounted) and the **TMDB key**. These additions appear in **My videos**.
- **Log**: the Log button on the home screen, or the remote's **Menu**, **Info** or **red** key from any screen. **↑ / ↓** scroll, **OK** shows errors only.
- **TV Guide** (Home button): channels × time grid. **◀ ▶** move programme by programme, **▲ ▼** channel by channel; **OK** watches the current programme (or opens its options if it is past or upcoming); **Menu** opens the options: **Watch**, **Replay**, **Record**, **Alert me**, **Schedule recording**. **▲** from the first channel reaches **Now**, the **day** (including replay days) and the **filter** (favorites, recents, themes, categories). **Replay**: the **Replay** button in the header (▲ from the first channel) jumps to yesterday; past programmes of channels with an archive show the ↺ icon (**OK** to watch). **Replay**: the **Replay** button in the header (▲ from the first channel) jumps to yesterday; past programmes of channels with an archive show the ↺ icon (**OK** to watch).
- **Player options**: during playback, the **Menu** key opens the options list: **audio**, **subtitles**, **speed** (movies and episodes), **picture format**, **next episode**, **episode list**, **auto-play next**, and in Live **favorite** and **previous channel**. **OK** applies the choice.
- **Direct video rendering**: on a TV, video is decoded straight to the screen (smooth even in 4K on an older TV). Settings > **Direct video rendering** turns it off (applied at next launch); in this mode subtitles are not displayed.
- **Settings** (Home button): **Sources** (enable, disable, refresh, move up, move down, remove), **Categories** for Live, Movies and Series (show, hide, move, sort A to Z), **Language**, **Playback** (automatic next episode, direct rendering, replay, software decoding, relay), **TV Guide** (opening position, backup guide, reload), **TMDB key** (typed with the TV keyboard), **Help** and **Log**.
- **Display style** (Settings > **Display style**): per content type. **Live**: *TV* (full-screen channel), *Classic* (channel grid by category, default) or *Cinema* (banner and channel rows); **Movies** and **Series**: *Classic* (grid) or *Cinema* (default; banner of the selected item, then rows Continue watching, Favorites, Recents and categories; **◀ ▶** inside a row, **▲ ▼** between rows, **OK** opens the page or plays the channel).


**Movie / series page on Android TV**: the button row now scrolls with the selection (▶ reaches every button) and the page shows the backdrop, tagline, runtime, rating, country, director and cast. This information comes from TMDB: without a key (Settings > TMDB key) the page stays limited and a message says so.

**“App not installed” when installing an APK by hand**: Android refuses an APK whose version number is lower than the installed one. Up to android28, 64-bit APKs (arm64-v8a) had a higher number than 32-bit ones (armeabi-v7a): installing a v7a over an arm64 failed. From android29 on, all APKs share the same number and install over one another. If the message still appears, uninstall Kastideo (Android Settings > Apps) then install the APK; an installed app now updates with the right file for its architecture (32 or 64 bit).

**Updates, subtitles and download on Android TV**: a new version opens on its own page (Install and restart, Later, Ignore this version) that the remote reaches directly. During a movie or episode, **OK** opens the options bar: subtitles (choose a language or **None**), audio, speed, format and **Download** (the file goes to the Films / Series folder and is followed in **Recordings**). Subtitles are **off at start** by default; Settings > Playback > Subtitles > **At start** lets you choose None, the interface language or Automatic. The glow around the selected item has been removed and Cinema mode no longer has a banner: the rounded Kastideo logo appears as a watermark behind the posters. **Series**: the episode list now scrolls under the selection (never off screen); ▲ from the first episode reaches the header (◀ ▶ change season, OK downloads the whole season); ▶ on an episode reaches its download icon, OK adds it to the queue.

**Categories on Android TV**: Settings > Categories lets you show, hide, move up or down categories without waiting: your choices are saved immediately, but the lists are only recalculated when you **leave the Categories menu** (◀ or Back), which avoids long waits on a large catalogue.

**History**: Settings > **History** (Android TV: Settings > History) clears, after confirmation, **Recents**, **Watched and resume points** (“watched” marks and positions) and the **YouTube history**, one by one or with **Clear all**. Favourites, sources and settings are not affected. With iCloud sync of playback progress, or a Jellyfin / Emby / Plex server, positions can come back from another device: clear them there too.

**Cinema on Android TV: “See all”**: each Cinema row (Resume, Favourites, Recents, categories) starts and ends with a **See all (N)** tile; **OK** opens every title of the row in a grid. In that grid, ▲ from the first line reaches **Sort** (◀ ▶: provider order, A to Z, recently added, year); **Back** returns to the row. Beyond 25 categories, the last row **All categories** lists the others. The Android TV History menu no longer offers YouTube history (no YouTube player on TV).

**No sound on Android TV?** Open Settings > Playback > **Audio diagnostics** (after starting a channel): it shows the volume, audio track, codec, stream format and the format sent to the TV. **Audio output** chooses Stereo (default, safest over HDMI), Automatic (multichannel) or Dolby / DTS passthrough (amplifier or soundbar). If these values look right but nothing comes out, check the HDMI cable, the TV volume (its speakers can be weak) and the box's audio output in Android settings.

**Recording, subtitles, MultiView and watched / unwatched on Android TV**

- **OK during playback** (movie, episode, recording, channel) opens the options bar at the bottom of the screen: pause, −10 s / +30 s, audio, subtitles, subtitle settings (size, colour, position, delay), speed, picture format, next episode, record, MultiView. ▲ ▼ or Back closes it.
- **Subtitles**: “Direct video rendering” (smooth in 4K) cannot show them; choosing “Subtitles” offers to switch to classic rendering (Kastideo closes: reopen it).
- **Recording**: Menu > Record this channel, or TV Guide > Schedule recording (Kastideo must be open and the TV on). Settings > Recordings: storage device (internal storage, USB key or SD card detected: Kastideo creates its folder there), default duration, format, automatic deletion of old recordings (by age or maximum space). Home > Recordings: play, delete, cancel a scheduled recording.
- **MultiView**: Home > MultiView, or Menu > MultiView during live TV. It appears if your sources allow at least two connections in total (Settings > Sources > the source > Simultaneous connections). OK on a tile: listen, change channel, make large, full screen, remove.
- **Watched / unwatched**: Menu key on an episode in the list, or the “Mark as watched” button on a movie or series page.
- **Maximum quality** (Settings > Playback): for channels offered in several versions (SD, HD, Full HD, 4K), picks the highest version not above the limit. “No limit” keeps the usual behaviour (Full HD).

### Differences from the computer

- **Local videos (gallery)**: Settings > Sources > **Add the gallery videos** (or Add a source > **Gallery** to **choose albums**: Camera, Screenshots…). Phone videos appear in **My videos** with their thumbnail, sorted by date; a properly named movie (exact title) gets its TMDB poster and summary. Android asks for access to videos: from Android 14 you can allow only a **selection** (button “Choose more videos…”). Nothing is copied or sent elsewhere.
- **Cast**: on Android, casting to a Chromecast or a TV uses **direct mode**: the stream address is sent as-is to the TV (channels switch to HLS ".m3u8"). Local files (My videos) cannot be cast. The ffmpeg conversion available on computers is not available.
- **Recordings and downloads** are stored in the app's folder (`Android/data/fr.jmezes.kastideo/files/Movies`, visible from the file manager). Android may stop an app running in the background: keep Kastideo open and the device plugged in during a recording. A scheduled recording only starts if Kastideo is running at the planned time.
- **No launch at sign-in** and no .m3u file association: add your playlists in Settings > Sources.
- **YouTube** opens in the device's browser.

### Updates

Kastideo looks for new Android versions on GitHub. When one is offered, **Install** downloads the APK and Android asks you to confirm. The first time, Android also asks you to allow Kastideo to install apps (the setting opens by itself). Once the update is installed, **reopen Kastideo**: Android closes the app during the installation.

### If something goes wrong

- **"App not installed"**: another copy of Kastideo signed with a different key is already installed; uninstall it first.
- **"Parse error" or "App not compatible"**: wrong file for your processor; try the **universal** APK.
- **Frozen picture**: see the page "Frozen picture: software decoding".
- **The Playback log** (Settings) keeps the details of playback errors.

## Kastideo Compat: older Macs (macOS 12 and 13) {#mac-compat}

The **Mac** version of Kastideo requires **macOS 14 Sonoma** or later. For older Macs, **Kastideo Compat** is the “Windows / Linux” version rebuilt for Mac: **macOS 12 Monterey and later**, Intel or Apple Silicon.

**Installation.** Download `Kastideo-Compat-…-macos.dmg` from the [Releases](https://github.com/jihemezes/kastideo/releases) page (pre-releases whose number ends with `-desktopN`), open it and drag **Kastideo Compat** into **Applications**. The app is signed and notarized by Apple. It can be installed **alongside** the native version.

**What differs from the native Mac version.**

- The interface and features are those of the Windows and Linux version (mpv playback engine): live, TV guide, themes, MultiView, recording, movies and series, YouTube…
- Shortcuts use the **Command** key (⌘) instead of Ctrl: ⌘1, ⌘2, ⌘3… for sections, ⌘, for settings, ⌘K for pause.
- **No automatic update**: the new-version banner opens the download page.
- **Casting to a TV** needs **ffmpeg** (for example `brew install ffmpeg` with Homebrew). Without ffmpeg, everything else works normally.
- Recordings are stored in **Movies > Kastideo**.
- Launch at login and .m3u file association are not offered.

Settings and sources can be moved between versions with **Backup and transfer**.

## Kastideo on iPhone and iPad {#ios}

**Kastideo for iPhone and iPad** (iOS 17 or later) is distributed through **TestFlight**, Apple's service for testing apps before release. There is no file to install by hand: you receive an invitation, install the **TestFlight** app from the App Store, then **Kastideo** from TestFlight. Updates arrive through TestFlight.

**First launch.** Read and accept the disclaimer. On the home screen, tap **Add a source** (Xtream Codes or M3U list), or go to **Settings > Import configuration…** to bring over your sources, favorites and categories from Mac, Windows, Linux or Android (see “Backup and transfer”). Tip: save the configuration file in **iCloud Drive** to find it on all your devices. To try it without a subscription, tap **Try the demo**: Kastideo adds a few royalty-free videos.

**What the app offers.**

- **Home**: on a gradient background with the logo, the big tiles **Live, Movies, Series, YouTube** and **My videos** (if you have a gallery, folder or server), with their item counts; below, the buttons **Resume, Recents, Favorites, TV Guide** and **Recordings**, and a search field on top. **Resume / Recents / Favorites** open a grid page: long-press an item or tap **Select** to remove several, **Clear all** in the ⋯ menu, and **Undo** right after a removal.
- **Bottom bar**: **Home** (returns to the home screen from any screen), **Content** (sources, gallery, categories, TMDB detail pages, YouTube, iCloud, backup), **App** (playback, MultiView, recordings, replay, Cinema, appearance, about) and **Help**. The “Settings > …” mentions on this page are in one of these two families.
- **MultiView in portrait**: when the screen is held upright, MultiView screens are **stacked** (one above the other, full width) instead of side by side; in landscape your chosen layout is kept.
- **Apple TV** (beta): receives your configuration from the iPhone (Settings > Backup > Send to Apple TV), “watched” badges; guide that reopens at the last position (setting); the same app exists for Apple TV (tvOS 17) — Classic, Cinema and TV (Live) views, chosen per content type (“View” button or Settings > View); Tile-based Home (like on iPad), My videos (Emby, Jellyfin, Plex), Live, Movies, Series, a time-grid TV Guide (3 h window, programme replay) and a remote-controlled player (↑ / ↓ change channel; click = audio tracks, subtitles, speed, last channel, channel number; automatic next episode). Search tab, favourites (long press), sleep timer. Settings: editable sources, start page, categories, zapping (with confirmation or direct). Add sources from a phone (QR code + 4-digit code, Settings > Add from a phone; the form adapts to the source type and accepts the TMDB key) or with the keyboard; iCloud Drive sync is not available on Apple TV.
- **Watched and guide**: badge on watched posters, “Mark as watched” (detail, long-press an episode, season); “When opening the guide” setting (Settings > Replay).
- **Categories (Live, Movies, Series)**: in List or Grid view, the **bar at the top** (All, Favorites, Recents, then each category) switches category in one tap; the ▦ button on the left opens the **full list** with search and item counts.
- **Live**: the button at the top left changes the display — **List** (channels with current programme, search, categories, favorites; swipe a channel to the left), **Cinema** (a “featured” banner, “on now” rows by theme, “Watch again”, recents, favorites, one row per category), **Themes** (Sport, News, Movies…: on now, tonight, all channels; long-press to change a channel's theme) and **TV Guide**.
- **TV Guide**: a **grid** like on Mac — the day as a horizontal timeline, one row per channel, **channel column** and **hours always visible**, red “now” marker, current programme in orange. Drag in both directions, **pinch to zoom** the time scale (or Menu > Time scale). Pick the day (up to 14 past days depending on Settings > Replay, and 3 ahead) and tap an hour to jump to it. Tap a programme for its page (**Watch live**, **Replay**, **Remind me**, favorite); long-press = the same actions. The menu filters by **favorites, recents, theme or category**, and switches back to the **Slots** view (one row per channel at the chosen time).
- **Replay**: on channels marked ↺, **Watch again** a programme from the provider's archive (programme details, or long-press a channel > Watch again). In the player, **Back to live**; when a replay ends you return to live automatically (adjustable). Settings > Replay: past days, time correction if a replay starts at the wrong time.
- **Movies** and **Series**: **Cinema** display (scrolling “featured” banner, resume, recents, favorites, one row per category — the **start category** (Settings > Organisation) first —, country filter as on Mac) or **Grid** (whole catalogue); search, detail page with summary, resume where you left off, seasons and episodes. Settings > Cinema display: banner content and speed.
- **Player**: tap to show the controls. **Gestures**: double-tap on the left = −10 s, on the right = +30 s, in the middle = pause; **swipe vertically** on the right = volume, on the left = brightness; **swipe horizontally** = seek in a movie (time preview), or **change channel** when live. The speaker at the bottom sets the **volume** and **mutes / unmutes**; the badge at the top right (reception color, HD / 4K) opens the **stream info**: resolution, bitrate, frames per second, dropped frames, stalls. For a movie or episode the bar shows elapsed time, **time left** and **end time**. When live, the **current programme** (progress bar) and the next one are shown under the channel name, and the |◀ ▶| buttons go to the previous / next channel of the category. The ⋯ button offers the **playback speed** (0.5× to 2×), the **picture format** (fit, fill the screen, 16:9, 4:3), the **last channel** watched and, for a series, the **episode list**; the **Next** button starts the next episode, and episodes **play one after another** (Settings > App > Playback).
- **My videos**: the button at the top right **sorts** (name A→Z / Z→A, date, size, duration), **groups** (Group by menu: source, category / folder / album, type, year or month added — **several criteria at once**, e.g. Source then Category, with collapsible sections; the sort applies inside each section) and **filters** (type, viewing: unwatched / in progress / watched / favorites, source). Sorting by size measures the files the first time; videos with unknown size (servers) come last. Your choices are remembered.
- **Categories**: Settings > Manage categories — **Deselect all / Select all** at the top of the list (handy to keep only a few categories), order (drag), hide, rename, hide by keyword (e.g. PAKISTAN), sort A→Z, reset; Countries and languages for the Cinema display. To reorder the **channels** of a category: Live in list view, pick the category, top-right menu > “Reorder channels…”.
- **Edit a channel** (long-press): name, number, logo (web address or photo), theme, associated TV guide channel when the guide is wrong.
- **Appearance**: theme, accent colour, poster size, list density, default display for Live, Movies and Series.
- **Start**: tab shown at launch, and start page of Live, Movies and Series (all, favorites, recents, last viewed or a category).
- **Edit a source**: Settings > Sources, tap a source (or swipe it > Edit) to change its name, address, credentials (empty password or token = kept), TV guide or folders, and test an Xtream account's connection.
- **iCloud sync**: Settings > **iCloud**. Find sources, favorites, playback resume… on your iPhone, iPad and Mac through an iCloud Drive folder. See the page [Sync with iCloud](#icloud).
- **Local videos (gallery)**: Settings > **Add the gallery videos** (or Add a source > iPhone gallery to **choose albums**: Camera, Screenshots…). Videos appear in Movies, under **My videos**, with their thumbnail, sorted by date taken; a properly named movie (exact title) gets its TMDB poster and summary. iOS asks for access to your photos: if you only allow a **selection**, only those videos appear (Settings > Local videos > Choose more videos…). A video stored only in iCloud is downloaded before playing. Nothing is copied or sent elsewhere. Setting: refresh when the app opens.
- **TMDB pages**: with a free TMDB key (Settings > Movie and Series Details), a movie or series page shows the HD poster, translated summary, genres, rating, cast with photos and the trailer, and the featured banner offers **this week's trends** found in your catalog. A page is wrong? On the page, **Fix details…**: paste the number or address of the themoviedb.org page, search by title, or type the title, year, poster and summary by hand. **Remove the correction** returns to the automatic page; the list of corrections is in Settings.
- **Several subscriptions**: Settings > Subscriptions to show a single source without disabling the other, merge duplicates across accounts, and **Diagnostics** of a source (swipe it to the left).
- **Record live TV**: during a live channel, the red round button in the player records it (automatic stop adjustable). The .ts files are in the **Files app > On My iPhone > Kastideo > Enregistrements**; play them in Kastideo or VLC, share or delete them (swipe). Scheduled recording is not possible on iPhone (the app cannot wake itself up): use alerts or the Mac.
- **Download** a movie or episode: the ↓ button on its page (or “Download the season”). Downloads continue with the app closed; pause, resume and delete in **Recordings** (tray icon at the top right, or Settings). Files go to Files > Kastideo > Téléchargements. Downloads run **one at a time** (a season goes episode after episode, the others show “Waiting”). Many providers allow only one connection: a download can interrupt the playback in progress.
- **Time-shifted live**: pause the live channel, it keeps being stored. Go back 10 s, forward 30 s, drag the timeline, speed up (×1.25 to ×2) and tap **Back to live**. Maximum length and speed: Settings > Time-shifted live.
- **Programme alerts** (Settings): by keyword, by theme on your favourite channels, or “Notify me at the start” on a programme page. They are iPhone notifications, received even with the app closed; tap one to open the channel. Allow notifications when iOS asks.
- **My videos**: Settings > Add a source > **Jellyfin, Emby, Plex** or **Video folders** (iPhone, iCloud Drive, USB drive, NAS added in Files). In Movies and Series, the top-right button picks **All / IPTV / My videos**.
- **YouTube** (YouTube tab, or the Home tile): follow channels (paste their link or @handle in the search field, no key or account), paste a video or playlist link to play it, **search** with your own free Google API key (Settings > YouTube, steps included), set videos **aside** (long press), add favourites, find your **history** and resume position (red bar on the thumbnail). Import your subscriptions from a **Google Takeout** export (subscriptions.csv). Playback uses YouTube's official player in “privacy-enhanced mode”; it is not an ad blocker. Starting a video stops IPTV playback.
- **MultiView**: several channels at the same time (2 to 4 screens), as on Mac. It is only offered if your sources allow at least two simultaneous streams: set each subscription's number of connections in **Settings > MultiView** (1 for most; a public list allows 4). Open it with the ▦ button in **Live** or in the player (the current channel is added). Each screen is reserved to a source; pick the channels, the layout (side by side, stacked, grid, **one big + draggable thumbnails**) and the number of screens from the top menu. Tap a screen to give it the sound, double-tap a thumbnail to make it big, long-press to change channel, source or remove the screen. Opening MultiView stops the main playback (unless a recording is running).
- **Full-screen player**: tap the picture to show the controls, drag the bar to seek, pick the audio track and subtitles. Close it with the arrow: playback continues, with a **mini player** above the tab bar. Sound continues with the screen locked. Going back to **Home** (the Home button of the tab bar) **stops playback**: no more sound in the background.
- **AirPlay**: the player button sends the sound to an Apple TV or HomePod; for video, use iOS screen mirroring.
- Same playback engine (VLC) and buffering settings as on Mac; stream relay for providers that refuse direct connections.

**Not yet on iPhone / iPad**: picture in picture (not available with the current playback engine). An **Apple TV** version is planned for later.

If playback fails: **Settings > About > Share the playback log**.

## Sync with iCloud (iPhone, iPad, Mac) {#icloud}

Kastideo can keep **your Apple devices identical**: iPhone, iPad and Mac share your sources, favorites, history, categories, display settings, **playback resume**, corrected detail pages and — optionally — **passwords**. Sync goes through **a folder in your iCloud Drive**: Kastideo drops small files there.

**Setup (on each device).**

1. In iCloud Drive, create a folder, for example **Kastideo** (once). Make sure iCloud Drive is on for every device.
2. Open Kastideo > Settings > **iCloud** and turn on **Sync with iCloud Drive**.
3. Tap **Sync folder** and pick **the same folder**.
4. Choose what to sync.
5. If you sync passwords or the TMDB key, enter the **passphrase** — the same on all devices — then **Save passphrase**.

**Good to know.**

- The most recent change wins. On first sync, the lists (sources, favorites, history) are merged.
- Passwords are **encrypted** with your passphrase before being stored: without it, nobody can read them. Write it down: it cannot be recovered.
- Video folders, M3U files and the gallery stay specific to each device. Display settings specific to Mac and iPhone are kept separately.
- Sync runs every 30 seconds, when returning to the app and when it goes to the background; **Sync now** forces it. On Mac, a small cloud icon at the bottom of the sidebar shows the status.
- “Erase sync files” deletes the files in the folder for all your devices (your local data is kept).
- Windows, Linux and Android are not covered: use configuration export / import.

## What's new {#nouveautes}

After each update, the **What's New** window summarises the changes in the installed version.

<!--mac-->
You can reopen it with **Help > What's New in This Version** or by clicking the version number at the bottom right of Home, and browse earlier versions there.
<!--/mac-->
<!--pc-->
You can reopen it by clicking the version number at the bottom right of Home, and browse earlier versions there.
<!--/pc-->

The full history is also published on the [GitHub Releases](https://github.com/jihemezes/kastideo/releases) page.

# Troubleshooting

## Troubleshooting {#depannage}

<!--mac-->
- **A channel has no sound**: Kastideo detects it within a few seconds and repairs it on its own: if the stream clock is shifted (sound is dropped, “buffer too late” in the log), the channel is reopened synced on sound and picture, and Kastideo remembers it; otherwise it restarts the audio track or tries the next one. If an orange 🔇 icon stays next to the health pill, the provider is sending a stream without sound or an unreadable track: try another version of the channel (HD, SD…) or pick another audio track in the information panel (⌘I). The playback log (“Son :” lines) shows the format received.

- **“The provider refuses this channel (HTTP 403)”**: the provider itself blocks this channel (out of service or not in your subscription). Kastideo does not insist; try another version (HD, SD…) or later.
- **Frozen picture, “Faulty stream at the provider”**: the stream clock is inconsistent. Kastideo reopens the channel once, synced on sound and picture; if that is not enough, it switches to **picture only** (no sound) so the picture no longer freezes, and remembers it. Right-click the channel > **Image seule (sans le son)** / picture only to turn it on or off manually. Settings > General > Playback > **Reset** cancels these remembered repairs. **The automatic switch to picture only lasts for the current session only**: the next time you launch the app, the channel reopens with sound. A **Restore sound** banner appears under the playback bar while a channel has no sound. Remembered repairs (clock, software decoding, picture only chosen by hand) **expire after 7 days**.
- **Stream relay** (Settings > General > Playback, on by default): Kastideo opens the connection to the provider itself and passes it to the VLC engine, like Piboard, so there are never two at once. The playback log then shows “Relais :” lines with the provider's exact answer (e.g. “HTTP 200 en 0,35 s”).
- **Slow or refused channel switch (“HTTP 404”, “403”, “401” or “520” in the playback log)**: with a one-connection subscription, the provider takes a moment to release the previous channel. Kastideo waits 1.5 s before opening the new channel and retries once if it is refused (“Attente…” and “nouvel essai” in the log). If refusals persist, wait a minute and try again.

Kastideo identifies itself to servers as the **VLC** player: many IPTV providers only answer players they recognize.

- **“The server did not respond in time”**: the server is overloaded or unavailable. Try again later; if your address looks like `get.php?username=…`, check that it was converted to Xtream Codes (type shown in the sources settings).

- **“Username or password refused”**: check your credentials with **Test Connection**.
- **“Account not active”**: the subscription has expired or is suspended at your provider.
- **No program in the guide**: the channel has no TV guide identifier, or your source's guide does not contain any for it.
- **“App Transport Security”**: this message appeared in versions 0.1.0 and 0.2.0 with http:// sources. It has been fixed since version 0.2.1.
- **Cannot play**: the server did not provide the stream. Check that no other device is using your subscription (only one connection allowed), then click **Try Again**. Also try the **Stable** buffer.
<!--/mac-->

<!--pc-->
- **A channel won't start**: open the **Log** (Ctrl+Alt+L, topic *Playback and relay*). "Relais :" lines give the provider's exact answer (e.g. "HTTP 200 en 0,35 s" or "HTTP 403").
- **The update doesn't install**: the playback log (Ctrl+Alt+L) gives the reason. .deb package: if the password window doesn't appear, the command to type in a terminal is shown in the update window. You can always download the new version from the GitHub releases page.
- **MultiView: a tile stays black**: the provider refuses an extra connection. Check your subscription's number of connections (Settings > General > Playback > Detect).
- **No notification**: check Settings > General > Notifications, then the notification settings of Windows (Settings > System > Notifications) or of your Linux desktop. On Linux, the libnotify package is required (installed by the .deb, included in the AppImage).
- **Empty recording**: the provider sent nothing (channel refused, connection already used by another device). "Enregistrement" lines in the log give the provider's answer (e.g. "HTTP 403") and say if no data arrived after 30 s.
- **Timeshift doesn't go back further**: its depth depends on temporary disk space; without a disk cache (some libmpv versions on Linux), it is limited to 512 MB in memory.
- **Details in another language**: some providers only have one language. With a **TMDB key**, summaries, genres and episodes come from TMDB in your language.
- **Single window**: launched while already running, Kastideo just brings the existing window to the front.
- **No picture on Linux**: make sure the **libmpv** package is installed (the .deb installs it; the AppImage bundles it).
- **VPN**: an active VPN may prevent the provider from serving streams.
- **No programmes in the guide**: Settings > Sources shows each source's guide state; the fallback guide fills in common French channels.
- **Passwords on Linux**: without a keyring (GNOME Keyring or KWallet), Kastideo keeps passwords in its preferences and says so in the log.
<!--/pc-->

## The window is off screen (Windows and Linux) {#fenetre-hors-ecran}

With several screens, a window could open half off screen with no reachable title bar. Since version 1.12.1, Kastideo **remembers its window position** and, at startup, checks that its title bar is visible on a screen. If not (screen unplugged, resolution or scaling changed), the window is **re-centred on the main screen**.

If a window is still out of reach: on Windows, press **Alt + Space** then **M** (Move), then the arrow keys; or close Kastideo and start it again.

# About

## Disclaimer {#avertissement}

Thank you for using Kastideo. Kastideo is a media player: it plays playlists (M3U), IPTV accounts (Xtream Codes), your own servers (Jellyfin, Emby, Plex), the videos on your drives and YouTube.

- **No content provided.** Kastideo does not provide, host or sell any channel, movie, playlist or subscription.
- **No affiliation.** Kastideo is not affiliated with any content or IPTV subscription provider, nor with YouTube, Google, TMDB, Plex, Jellyfin, Emby, Apple or Microsoft. Trademarks mentioned belong to their respective owners. This product uses the TMDB API but is not endorsed or certified by TMDB.
- **Your own content.** You must supply your own sources and content. You are solely responsible for checking that they are legal and that you have all the rights needed to watch, record, download and stream them.
- **Copyright.** Kastideo does not encourage the streaming of copyright-protected material without the permission of the copyright holder. Recordings, downloads and casting to a TV are for private use only, within the limits of the law in your country.
- **Liability.** The author of Kastideo is not responsible for how you use the software, nor for the content, availability or legality of the third-party services you connect it to. Kastideo is provided free of charge, “as is”, without warranty.
- **Your data.** Your credentials are kept on your device and are only sent to the services you configure.

By clicking “I understand and accept”, you confirm that you have read and accept these terms. Otherwise, please quit the application.

This notice appears on first launch and after every update. You can read it again at any time in <!--mac-->**Settings (⌘,) > About**<!--/mac--><!--pc-->**Settings (Ctrl+,) > About**<!--/pc-->.

## Support Kastideo {#soutenir}

<!--mac-->
Kastideo is **free**. If you enjoy the app, you can encourage its development by buying me a coffee on [Ko-fi](https://ko-fi.com/jihemezes): it is entirely optional.

The **Buy me a coffee** button appears discreetly on the home screen and in the What's New window, as well as in **Settings > About** and **Help > Support Kastideo (Ko-fi)**. To hide the buttons on the home screen and in What's New, tick **Hide the “Buy me a coffee” buttons** in **Settings > About**.
<!--/mac-->

<!--pc-->
Kastideo is **free**. If you enjoy the app, you can encourage its development by buying me a coffee on [Ko-fi](https://ko-fi.com/jihemezes): it is entirely optional.

The **Buy me a coffee** button appears discreetly on the home screen and in the What's New window, as well as in **Settings > About**. To hide the buttons on the home screen and in What's New, tick **Hide the “Buy me a coffee” buttons** in **Settings > About**.
<!--/pc-->

## Privacy {#confidentialite}

<!--mac-->
Kastideo runs in the macOS sandbox. It only accesses the network and the files that you choose. Your passwords stay in the keychain. No data is sent anywhere other than to your own sources.
<!--/mac-->

<!--pc-->
Kastideo collects no data. It only contacts your IPTV providers, the TV guides you chose, GitHub for updates and, if you entered a key, TMDB. Your settings, favorites and passwords stay on your computer.
<!--/pc-->

## Licenses {#licences}

<!--mac-->
Kastideo uses **VLCKit** (VLC's engine, © VideoLAN, LGPL 2.1 or later license, https://www.videolan.org/vlc/libvlc.html) and **Sparkle** (MIT license, https://sparkle-project.org). VLCKit is embedded as an unmodified dynamic library.
<!--/mac-->
