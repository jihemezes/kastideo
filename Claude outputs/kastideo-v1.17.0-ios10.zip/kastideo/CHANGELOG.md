# Journal des versions

Toutes les évolutions notables de Kastideo sont consignées ici.
Les notes de chaque version sont reprises automatiquement dans la GitHub Release correspondante.

## [1.16.2] - 2026-11-08

- Enregistrements : garde-fou contre les enregistrements « son seulement ». Si la conversion en MP4 perd l'image (vidéo MPEG-2 de certaines chaînes que le MP4 ne sait pas contenir), le fichier **.ts d'origine est conservé** au lieu d'un MP4 sans image, avec une ligne dans le Journal de lecture.

## [1.16.1] - 2026-11-08

- Durée des enregistrements : le bandeau de choix ne se ferme plus pendant le réglage de l'arrêt (souris dessus, sélecteur d'heure ouvert), reste affiché 45 s au lieu de 20 s, et le sélecteur d'**heure précise** est maintenant une horloge graphique plus rapide à régler. Bandeau sans animation d'apparition, pour ne pas perturber l'affichage de la vidéo.

## [1.16.0] - 2026-11-07

- **Durée des enregistrements** : l'enregistrement démarre immédiatement ; un bandeau permet ensuite de choisir l'arrêt automatique (15 min à 4 h, heure précise, sans limite). Sans choix, il s'arrête à la fin du programme (guide) ou après la **durée par défaut** (Réglages > Enregistrements, 2 h au départ, « Sans limite » possible). Le bouton **Durée** de l'enregistrement en cours change l'arrêt à tout moment, et le temps restant est affiché.

## [1.15.0] - 2026-11-07

- **Retirer un contenu de « Reprendre la lecture »** : clic droit sur une vignette > **Retirer de « Reprendre la lecture »** ou **Vider « Reprendre la lecture »** (accueil, Cinéma, Mes vidéos). La position reste mémorisée, le contenu réapparaît dès qu'on le regarde de nouveau, et un bandeau **Annuler** permet de revenir en arrière.

## [1.14.2] - 2026-11-07

- Correction : hors du mode **Sélectionner**, un clic sur un enregistrement relançait plus la lecture (le nouveau code de sélection interceptait les clics de la liste). Le clic n'est désormais capté qu'en mode sélection.

## [1.14.1] - 2026-11-07

- Enregistrements : les boutons **Sélectionner** et **Vider la liste…** sont maintenant dans l'en-tête de la section « Enregistrés » (ils étaient dans la barre d'outils, parfois masquée). La boîte de dialogue « Supprimer aussi le fichier du stockage » s'applique à toutes les formes de retrait.

## [1.14.0] - 2026-11-06

- **Nettoyer la liste des enregistrements** : retirez un enregistrement (bouton corbeille, clic droit), plusieurs (mode **Sélectionner**) ou toute la liste (**Vider la liste…**). Une boîte de dialogue propose de supprimer aussi le fichier du stockage (corbeille) ; par défaut, seule la liste est nettoyée et le fichier reste dans le dossier sans réapparaître. L'espace libéré est affiché, le choix peut être mémorisé et un bandeau **Annuler** permet de tout remettre pendant une dizaine de secondes. Un fichier déjà absent ou impossible à supprimer n'arrête rien : notification, ou fenêtre listant les avertissements s'il y en a plusieurs.

## [1.13.3] - 2026-11-03

- Correction de compilation de la 1.13.2 : le sélecteur de la miniature (image dans l'image) utilise de nouveau le même sélecteur de chaînes par catégories que la MultiVue.

## [1.13.2] - 2026-11-03

- **Sélecteur de chaînes de la MultiVue refondu** : comme dans l'interface Classique, Favoris, Récents et **catégories de la source de l'écran** (ordre, masquage et noms personnalisés respectés) à gauche, chaînes avec programme en cours à droite. Un clic lance la chaîne et garde le sélecteur ouvert pour zapper, un double-clic lance et ferme ; les chaînes déjà affichées sur un autre écran sont grisées.
- Changer de chaîne sur un écran attend la libération de la connexion par le fournisseur (évite les refus).

## [1.13.1] - 2026-11-03

- **MultiVue : le bouton « Choisir une chaîne » fonctionne** (une couche invisible interceptait le clic).
- **Vrai PIP** dans la disposition « Une grande + vignettes (PIP) » : une chaîne plein cadre, les autres en vignettes 16:9 flottantes, **déplaçables** (elles s'accrochent au coin le plus proche), **double-clic pour les échanger** avec la grande, taille réglable (petites, moyennes, grandes).
- **MultiVue plus facile à trouver** : entrée dans la barre latérale, bouton dans la barre d'outils, bouton sur l'accueil (à côté de Favoris et Enregistrements) et bouton dans la barre de lecture (ouvre la MultiVue avec la chaîne regardée).

## [1.13.0] - 2026-11-03

- **MultiVue repensée pour plusieurs abonnements** : réglages > Lecture = une ligne par abonnement (nom + identifiant du compte) avec son nombre de connexions ; dans la fenêtre MultiVue, vous choisissez le **nombre d'écrans**, la **disposition** (côte à côte, empilé, grille, une grande + petites) et la **source réservée à chaque écran**. Chaque écran ne propose que les chaînes de sa source ; une source ne dépasse pas son nombre de connexions.
- Le sélecteur de chaînes de la MultiVue et du PIP cherche dans toutes les sources, même si une source active est choisie dans la barre latérale.

## [1.12.1] - 2026-11-03

- **MultiVue** : dans Réglages > Général > Lecture, chaque source a maintenant sa propre ligne indépendante (nom et type : abonnement ou liste publique) ; changer l'une ne modifie plus l'autre.

## [1.12.0] - 2026-11-03

- **Mes vidéos : barre de filtres** : nouveau filtre **Source** (dossier local, Emby, Jellyfin, Plex…) à côté de Genre et Année, avec une pastille de la source sur chaque affiche quand la vue les mélange. Nouveaux filtres **Pays**, **Langue**, **Qualité** (4K, HD d'après le nom du fichier) et **État** (Non vus, En cours, Vus, Favoris).
- **Tri** par **note TMDB** et par **durée**. Filtres et tri sont **mémorisés** d'un lancement à l'autre ; bouton « Réinitialiser ».
- **MultiVue avec plusieurs sources** : chaque source de direct a son propre nombre de connexions (1 pour un abonnement limité, 4 pour une liste publique, réglable dans Réglages > Général > Lecture). Mélangez un abonnement et une liste publique, ou deux abonnements ; 4 flux au plus en tout, le nom de la source est affiché sur chaque vignette.
- **Image dans l'image** : pendant un direct, le bouton PIP ouvre une seconde chaîne en miniature dans le lecteur (sans le son) ; un clic l'échange avec la chaîne principale.
- **Aide** : nouvelles pages « Trier et filtrer Mes vidéos » et « Plusieurs sources de direct : MultiVue et image dans l'image ».

## [1.11.0] - 2026-11-03

- **Corriger la fiche, par code TMDB** : dans « Corriger la fiche… », saisissez le numéro TMDB (ou collez l'adresse de la page themoviedb.org) pour lier un film ou une série à la bonne fiche, avec aperçu avant validation. Utile quand deux films portent le même titre.
- **Films et séries de l'abonnement IPTV** : « Corriger la fiche… » est maintenant proposé aussi pour eux (jusqu'ici, seulement pour Mes vidéos).
- **Fiche personnalisée** : titre, année, adresse d'affiche et résumé saisis à la main, qui l'emportent sur le fournisseur et TMDB.
- **Retirer la correction** pour revenir à la recherche automatique ; liste de toutes les fiches corrigées dans Réglages > Général, et corrections incluses dans la sauvegarde de la configuration.
- **Aide** : nouvelle page « Corriger la fiche d'un film ou d'une série ».

## [1.10.1] - 2026-11-02

- Correction de la version 1.10.0 (non publiée sur Mac) : un fichier de traduction anglaise était invalide, ce qui empêchait la compilation. Les nouveautés de 1.10.0 sont inchangées.

## [1.10.0] - 2026-11-02

- **Menu Source** : avec plusieurs comptes IPTV, un menu dans la barre latérale choisit le compte affiché (Direct, Films, Séries, recherche, guide) sans désactiver les autres, avec le nombre de chaînes · films · séries de chaque compte. Le choix est retenu.
- **Fusion des doublons** : avec « Toutes les sources », un film ou une série fourni par plusieurs comptes n'est listé qu'une fois (case « Fusionner les doublons »).
- **Diagnostic de la source** : nouveau bouton (stéthoscope) dans Réglages > Sources : état du compte, nombre de chaînes, films et séries renvoyés par le fournisseur, affichés, masqués ou fusionnés. Il permet de savoir si une différence entre deux comptes vient du fournisseur.
- **Vidéos personnelles et TMDB** : les films de vos dossiers (par exemple les films ouverts de la fondation Blender) reçoivent affiche et résumé quand leur titre est exactement celui de TMDB, y compris les noms collés comme « TearsOfSteel ». Réglage « Chercher aussi les vidéos personnelles » (activé par défaut).
- **Aide** : nouvelles pages « Plusieurs comptes : source active, doublons et diagnostic » et « Affiches et résumés de vos vidéos personnelles ».

## [1.9.1] - 2026-11-01

**Aide : l'écran d'accueil est décrit tel qu'il est.** La page « L'écran d'accueil » est réécrite (champ de recherche, pavés dont Mes vidéos, accès rapides, « À la télé maintenant », « Reprendre la lecture », bandeau de lecture, version et bouton Offrir un café) avec un schéma mis à jour. L'application elle-même ne change pas.

## [1.9.0] - 2026-10-31

**Kastideo arrive sur Android et Android TV.** Cette version Mac ne change pas l'application : elle ajoute la page d'aide « Kastideo sur Android et Android TV » (choix du fichier, installation sans désactiver la sécurité d'Android, télécommande, différences avec l'ordinateur). Les APK se téléchargent sur la page des versions GitHub (tags `-android`).

## [1.8.1] - 2026-10-31

**Repli en décodage logiciel pour les chaînes qui se figent.** Quand une chaîne affiche une image puis reste figée (décodeur matériel du Mac défaillant), Kastideo la rouvre seul en décodage logiciel au bout de 6 s et s'en souvient. Réglages > Général > Lecture : repli automatique (activé par défaut) et « Toujours décoder en logiciel ». Clic droit sur une chaîne : « Décodage logiciel (image figée) ». Le Journal de lecture explique chaque bascule. Nouvelle page d'aide « Image figée : décodage logiciel ».

## [1.8.0] - 2026-10-31

**Page de départ de Direct, Films et Séries.** Réglages > Général > Page de départ : pour chaque section, choisissez ce qui s'affiche en l'ouvrant depuis une autre section (et au lancement) : la liste complète, les Favoris, les Récents, la dernière catégorie consultée ou une catégorie précise. Un clic droit sur une catégorie de la barre latérale propose aussi « Définir comme catégorie de départ ». Nouvelle page d'aide « Page de départ ».

## [1.7.10] - 2026-10-31

**Texte sur la gratuité.** Kastideo est gratuit, mais la promesse qu'il « le restera » est retirée partout (Réglages > À propos, info-bulle du bouton Ko-fi, aide, README).

## [1.7.9] - 2026-10-31

**Avertissement légal.** Au premier lancement et après chaque mise à jour, Kastideo affiche un avertissement en français ou en anglais : aucun contenu fourni, aucune affiliation, vos propres sources et contenus, droit d'auteur, responsabilité. Il faut l'accepter (« J'ai compris et j'accepte ») ou quitter. Il se relit dans Réglages > À propos > Avertissement légal, dans la nouvelle page d'aide « Avertissement légal » et dans le README.

## [1.7.8] - 2026-10-31

**Bouton Arrêt dans la barre de lecture.** Un bouton ■ à côté de lecture / pause (et **⌘.**) arrête le flux sans repasser par l'accueil. La zone vidéo affiche « Aucune lecture » avec un bouton **Relancer**. La position d'un film ou d'un épisode est mémorisée pour la reprise ; pendant une diffusion, l'arrêt ferme la diffusion et le téléviseur reprend son programme ; si la chaîne est en cours d'enregistrement, Kastideo demande confirmation.

**Cast sur Mac : ça fonctionne.** Les corrections 1.7.5 à 1.7.7 ont été confirmées sur une TV Android.

## [1.7.7] - 2026-10-31

**Cast sur Mac : l'adresse du téléviseur est maintenant écrite dans la chaîne de diffusion de VLC.** Dans la 1.7.6, l'adresse IPv4 était bien trouvée mais VLC répondait « missing Chromecast IP address » et ne démarrait pas la diffusion.

## [1.7.6] - 2026-10-31

**Cast sur Mac : adresse IPv4 du téléviseur.** Le forçage IPv4 de la 1.7.5 n'avait pas suffi : VLC retrouvait le téléviseur par son nom et macOS lui répondait en IPv6. Kastideo cherche maintenant lui-même l'adresse IPv4 du Chromecast / de la TV Android (Bonjour) et la donne directement à VLC. Si elle est introuvable, l'ancien mode est utilisé.

## [1.7.5] - 2026-10-31

**Cast sur Mac : cause trouvée.** VLC donnait au téléviseur une adresse IPv6 sans crochets (`http://2a02:…:8010/…`) qu'il ne sait pas lire, d'où « Media load failed ». VLC est maintenant forcé en IPv4 (la diffusion utilise l'adresse IPv4 du Mac).

## [1.7.4] - 2026-10-31

**Cast sur Mac : diagnostic et essai de correction.** Pendant une diffusion, le différé de VLC est désactivé (il gênait l'envoi vers le téléviseur) et le Journal de lecture détaille les échanges avec le téléviseur.

## [1.7.3] - 2026-10-31

**Cast sur Mac : l'image arrive sur le téléviseur.** Pendant une diffusion, Kastideo changeait de piste son en croyant le son muet (VLC ne décode pas le son localement quand il l'envoie au téléviseur), ce qui coupait le flux. Cette « réparation » est désormais suspendue pendant la diffusion.

## [1.7.2] - 2026-10-31

**Cast sur Mac.** Le bouton « Reprendre sur le Mac » de l'écran de diffusion réagit enfin (un calque transparent interceptait le clic). Le Journal de lecture indique si VLC a bien accepté le téléviseur.

## [1.7.1] - 2026-10-30

**Cast sur Mac : recherche des téléviseurs plus fiable.** La recherche est relancée à chaque ouverture du menu, le Journal de lecture détaille ce que VLC trouve, et un bouton « Autoriser Kastideo sur le réseau local… » ouvre le bon réglage macOS (sans cette autorisation, aucun Chromecast / TV Android n'apparaît).

## [1.7.0] - 2026-10-30

**Diffuser sur un téléviseur (Cast).**

- **Bouton téléviseur dans la barre de lecture** : envoie la chaîne, le film, la série ou la vidéo en cours vers un **Chromecast, Google TV ou TV Android** du réseau. La lecture reprend à la position atteinte, et la barre reste la télécommande (pause, avance / recul, position, volume). « Arrêter la diffusion » ramène la lecture sur le Mac.
- **YouTube sur le téléviseur** : clic droit sur une vidéo > « Lire sur un téléviseur » (et bouton dans le lecteur YouTube). Réglages > Général > Cast : application YouTube du téléviseur, ou navigateur (bouton Diffuser de Chrome).
- **Apple TV** : raccourci vers la recopie d'écran AirPlay de macOS (VLC n'envoie pas la vidéo en AirPlay).
- Au premier usage, macOS demande l'autorisation de trouver des appareils sur le réseau local.
- Nouvelle page d'aide « Diffuser sur un téléviseur ». Fonction non testée avec un vrai téléviseur : vos retours sont bienvenus.

## [1.6.1] - 2026-10-30

**Correctif de compilation de la 1.6.0** (aide). Aucune autre nouveauté.

## [1.6.0] - 2026-10-30

**Une aide refaite de A à Z.**

- **Nouvelle fenêtre d'aide** : sommaire par rubriques à gauche, page à droite, **recherche** dans toutes les pages (extraits et mots surlignés), liens entre pages, pages précédente / suivante et petits schémas. Fini le fichier unique interminable.
- **Bouton « ? » discret** dans la barre d'outils et sur l'accueil : l'aide s'ouvre **à la page de l'écran où vous êtes** (aussi avec ⌘? ; le menu Aide ajoute « Questions fréquentes »).
- **Pas à pas** : importer ses abonnements YouTube via Google Takeout (avec un lien « Comment obtenir mon fichier ? » dans l'écran d'import), obtenir une clé API Google, publicités et confidentialité. Nouvelles pages « Bienvenue » et « Questions fréquentes ».
- **Une seule source pour l'aide Mac et Windows / Linux** : mêmes rubriques et mêmes pages, avec les différences propres à chaque système (raccourcis, installation…). Le texte de l'aide est entièrement relu et réorganisé en 57 pages.

## [1.5.1] - 2026-10-30

**YouTube : plus pratique.**

- **À regarder plus tard** : clic droit sur une vidéo (ou bouton dans le lecteur) ; une vidéo entamée **reprend là où vous l'avez laissée**, avec une barre d'avancement sur la vignette, et quitte la liste une fois vue jusqu'au bout.
- **Importer mes abonnements** : lit le fichier d'abonnements de votre export Google Takeout (CSV ou JSON) ou une liste de liens de chaînes. Les flux sont chargés par lots.

## [1.5.0] - 2026-10-30

**YouTube dans Kastideo.** Une nouvelle section **YouTube** (barre latérale, accueil, ⌘9) : on commence par un navigateur, puis la vidéo choisie bascule sur le lecteur.

- **Navigateur** : chaînes suivies (collez un lien ou un @pseudo ; leurs dernières vidéos par flux RSS, sans clé), **recherche** en vignettes avec votre propre clé API Google gratuite (Réglages > Général > YouTube), liens de vidéos, playlists et chaînes collés, favoris et historique.
- **Lecteur** : le lecteur officiel de YouTube en « mode confidentialité avancée » (youtube-nocookie.com), sans cookie de suivi, donc le plus souvent sans publicité personnalisée. Précédente / Suivante, enchaînement, boucle, muet. **Ce n'est pas un bloqueur de publicités** : YouTube reste libre d'y diffuser des annonces.
- La lecture IPTV s'arrête pendant que YouTube joue (sauf enregistrement en cours).

## [1.4.2] - 2026-10-29

**Soutenir Kastideo (facultatif).** L'application est gratuite ; un bouton discret **Offrir un café** (Ko-fi) apparaît sur l'accueil et dans la fenêtre Nouveautés, avec un onglet **Réglages > À propos** et l'entrée **Aide > Soutenir Kastideo (Ko-fi)**. Une option permet de masquer les boutons de l'accueil et des Nouveautés.

## [1.4.1] - 2026-10-29

**Correctif de compilation de la 1.4.0** (Mac uniquement) : « Retour au direct » du lecteur référençait un élément non défini. Aucun changement de fonctionnement.

## [1.4.0] - 2026-10-29

**Replay : revoir un programme déjà diffusé.** Les abonnements IPTV qui conservent les chaînes jusqu'à 14 jours (fonction « tv_archive » de Xtream Codes) sont maintenant exploités.

- **Détection automatique** des chaînes à replay (icône ↺ dans les listes et le Guide TV).
- **Guide TV** : les programmes passés des chaînes à replay sont conservés (nombre de jours réglable), le menu de la date propose les jours précédents ; la fiche d'un programme passé propose **Revoir** et **Enregistrer ce replay** ; sur le programme en cours, **Revoir depuis le début**.
- **Clic droit sur une chaîne** > **Revoir (replay)** ; rangée **À revoir** dans l'interface Cinéma.
- **Lecture** : timeline et pause comme pour un film, sans toucher aux « reprises » ; **retour automatique au direct** à la fin du programme ; passage par le relais de flux (une seule connexion).
- **Heure du serveur** lue automatiquement (fuseau et heure d'été du fournisseur) ; **décalage manuel** dans Réglages > Général > Replay.
- Adresses d'archive et décalage visibles dans le Journal (sujet « Lecture et relais », niveau détaillé).

## [1.3.4] - 2026-10-28

**Guide TV : des chiffres plus justes et une liste plus propre.**

- **Séparateurs de catégories ignorés** : les lignes du fournisseur comme « ♣♦♣----|FR| FRANCE FHD |FR|---♣♦♣ » ne sont pas de vraies chaînes. Elles ne sont plus comptées « sans programme » ni proposées dans les listes par thème.
- **Versions d'une même chaîne** : une version 4K, FHD ou UHD sans programme propre reprend désormais celui de la version (HD, SD) qui en a un.
- **« Programme non disponible »** affiché sous les chaînes qui n'ont aucun programme (au lieu du nom de la catégorie).
- **Journal « Guide TV »** : couverture détaillée, avec les chaînes françaises à part (les chaînes étrangères n'ont souvent pas de guide) et les exemples de chaînes françaises sans programme.
- Plus d'alerte « aucune adresse de guide connue » pour les sources Emby, Jellyfin, Plex et dossiers.

## [1.3.3] - 2026-10-28

**Diagnostic : comprendre ce que fait Kastideo, en particulier avec le guide TV.**

- **Journal par sujets** (⌥⌘L) : *Guide TV*, *Lecture et relais*, *Sources et catalogues*, *Enregistrements*, *Fiches TMDB*, *Mises à jour*, *Affichage et divers*. Filtre par sujet (avec le nombre de lignes), **recherche**, erreurs et alertes seulement, **Copier l'affichage** (uniquement ce qui est filtré).
- **Niveau de détail par sujet** : Normal, Détaillé (par défaut pour le Guide TV) ou Débogage.
- **Journal conservé sur disque** : choix entre la **session en cours** et la **session précédente** (utile pour les problèmes au démarrage).
- **Guide TV détaillé** : chaque tentative est journalisée — adresse demandée, réponse du fournisseur (code HTTP, taille, durée, compression), chaînes et programmes reçus, période couverte, nombre de vos chaînes reliées au guide du fournisseur, au guide de secours ou à aucun, début de la réponse quand elle est inutilisable. Les refus du fournisseur (HTTP 4xx/5xx) et les pannes réseau sont désormais notés dans le journal. Au démarrage, le journal indique aussi si le guide a été conservé ou rechargé.
- **Bouton « Recharger le guide TV »** par source (Réglages > Sources) et nombre de programmes reçus affiché sous la source.
- Sources : chargement journalisé (chaînes, films, séries, chaînes ayant un identifiant de guide, adresse du guide connue ou non).
- Contient le correctif de compilation de la 1.3.2.

## [1.3.2] - 2026-10-27

**Correctif de compilation de la 1.3.1 (Mac).** Aucun changement de fonctionnement : la 1.3.2 contient tout ce que la 1.3.1 apportait (tuile « Mes vidéos », sélecteur Tout / IPTV / Mes vidéos, mot de passe facultatif, connexion Emby corrigée).

## [1.3.1] - 2026-10-27

**Corrections des premiers essais avec un NAS et Emby.**

- **Tuile « Mes vidéos »** sur l'accueil (et dans la barre latérale, ⌘8), visible dès qu'une source Dossiers, Jellyfin, Emby ou Plex existe : vos vidéos sont réunies à part de l'IPTV. **À la une** (reprendre la lecture, ajouts récents, films à voir, films, séries, vidéos), grilles **Films / Séries / Vidéos** avec filtres **genre, année, non vus** et **tri**, **navigation par dossiers** (sous-dossiers du NAS, fil d'Ariane) et choix de la **source**.
- **Films et Séries** : sélecteur **Tout / IPTV / Mes vidéos** au-dessus des catégories (IPTV seul par défaut). Les catégories de vos vidéos ne sont plus masquées par le réglage des pays (cause probable des fichiers du NAS invisibles).
- **Mot de passe facultatif** pour Jellyfin et Emby (compte sans mot de passe), **jeton facultatif** pour Plex (serveur ouvert au réseau local).
- **Emby** : connexion corrigée (erreur HTTP 400). Identification de l'appareil au format attendu par Emby (en-tête « Emby », paramètres d'adresse, nom de l'ordinateur sans accents ni apostrophe typographique), corps réduit à identifiant / mot de passe, second essai sous « /emby ». Une adresse copiée depuis le navigateur (« …/web/index.html#!/home ») est ramenée à celle du serveur.
- **Diagnostic des erreurs** : en cas d'échec, la requête et la **réponse exacte du serveur** s'affichent (ajout de la source, **Détails de l'erreur…** dans Mes vidéos, journal de lecture).
- Fiches TMDB des fichiers : année et genres retenus pour les filtres ; affiches et résumés gardés d'un examen des dossiers à l'autre.

## [1.3.0] - 2026-10-26

**Nouvelles sources : vos vidéos et les serveurs de la maison.**

- **Dossiers (disque, clé USB, NAS)** : Réglages > Sources > **Ajouter** > **Dossiers**, puis **Ajouter un dossier…** (un ou plusieurs). Pour un NAS, montez d'abord le partage dans le Finder (Aller > Se connecter au serveur…). Kastideo reconnaît les films (« Titre (2020).mkv », « Titre.2020.1080p… », dossier « Titre (2020) »), les séries (« Série S01E02 », « 1x02 », dossiers « Saison 1 »), regroupées avec leurs saisons, et range les autres vidéos dans une rubrique **Vidéos · nom du dossier**. Les dossiers sont examinés à chaque lancement puis toutes les 20 minutes.
- **Fiches TMDB automatiques** des films et séries trouvés dans les dossiers (avec une clé TMDB) : affiche et résumé, et clic droit > **Corriger la fiche…** pour choisir le bon titre quand le nom du fichier trompe la recherche.
- **Sous-titres placés à côté** des vidéos (« Film.srt », « Film.fr.srt ») chargés à la lecture.
- **Jellyfin et Emby** : adresse, identifiant et mot de passe (ou clé d'API). Les bibliothèques de films, séries et vidéos apparaissent dans Films et Séries (rubriques « Films · nom du serveur »), avec affiches, fiches, saisons et épisodes du serveur. Lecture directe, sans conversion.
- **Plex** : **Se connecter avec Plex** (autorisation dans plex.tv, choix du serveur du compte) ou jeton saisi à la main.
- **Recherche sur le réseau** : bouton **Rechercher sur le réseau** pour trouver les serveurs Jellyfin, Emby et Plex de la maison et remplir l'adresse (macOS demande l'autorisation d'accès au réseau local).
- **Reprise et « vu » partagés dans les deux sens** avec Jellyfin, Emby et Plex : la position de lecture est transmise au serveur pendant la lecture, et celle des autres appareils est reprise dans Kastideo. Clic droit > **Marquer comme vu / non vu** ; pastille **Vu** sur les affiches et coche dans la liste des épisodes.
- Sauvegarde de la configuration : les serveurs (et leur mot de passe ou jeton, si demandé) sont exportés et importés, comme dans Kastideo pour Windows et Linux.

## [1.2.2] - 2026-10-25

- **Gérer les catégories** : une case **Tout sélectionner / désélectionner** au-dessus de la liste coche ou décoche d'un coup toutes les catégories listées (Direct, Films ou Séries). Avec une recherche, elle ne concerne que les catégories trouvées : masquer tout un pays se fait en deux clics. Le nombre de catégories affichées est indiqué à côté.

## [1.2.1] - 2026-10-25

- **Pays et langues des rangées Cinéma** (Réglages > Apparence) : Kastideo repère les pays dans les noms de vos catégories (« FR| », « |PT| », « FRANCE », « VOSTFR »…) et vous laisse choisir ceux à montrer. Les derniers ajouts du bandeau « à la une », les tendances TMDB, la sélection au hasard et les rangées par catégorie de l'interface Cinéma ne montrent plus que ces pays (option pour garder les catégories sans pays, comme « Action »). Les listes et la recherche restent complètes. Le choix est repris par la sauvegarde de la configuration, comme dans Kastideo pour Windows et Linux.

## [1.2.0] - 2026-10-25

- **Sauvegarde et transfert de la configuration** (Réglages > Général) : **Exporter la configuration…** crée un fichier avec vos sources (mots de passe compris si vous le souhaitez), favoris, récents, catégories personnalisées et interfaces choisies ; **Importer une configuration…** les ajoute sur un autre Mac — ou dans Kastideo pour Windows et Linux, qui lit et écrit le même fichier. Rien n'est supprimé à l'importation : les sources déjà présentes sont reconnues.

## [1.1.7] - 2026-10-24

- **Image seule (sans le son)** : quand le son d'une chaîne est inutilisable et fige l'image (horloge incohérente même après réouverture), Kastideo passe automatiquement en **image seule** : l'image ne se fige plus. Le choix est mémorisé pour la chaîne. Il est aussi disponible à la main : clic droit sur une chaîne du direct > **Image seule (sans le son)** (coché = actif ; décocher pour réessayer avec le son).
- Réglages > Général > Lecture > **Réinitialiser** annule aussi les chaînes passées en image seule.

## [1.1.6] - 2026-10-24

- **Chaînes refusées par le fournisseur** : quand le fournisseur répond nettement « refusé » ou « introuvable » pour une chaîne (HTTP 403/404, vu grâce au relais), Kastideo ne s'acharne plus (plus de nouvel essai ni de variante .m3u8) et l'explique : chaîne hors service chez lui ou absente de l'abonnement, essayer une autre version.
- **Image figée / son absent sur les flux à l'horloge incohérente** : la détection couvre maintenant aussi les sauts d'horloge (« clock gap ») et les images en retard, pas seulement le son jeté. La chaîne est rouverte sans l'horloge du fournisseur ; si le flux reste incohérent, Kastideo n'essaie plus de relancer la piste son (ce qui figeait l'image) et indique que le flux est défectueux chez le fournisseur.
- Réglages > Général > Lecture : **Réinitialiser** les chaînes à l'horloge réparée.
- Journal : les alertes d'horloge sont regroupées (une ligne toutes les 5 s).

## [1.1.5] - 2026-10-24

- **Son absent sur certaines chaînes — cause trouvée** : sur ces chaînes, l'horloge envoyée par le fournisseur (PCR) est décalée de plusieurs heures par rapport au son ; le moteur VLC jette alors tout le son (« buffer too late »). Kastideo le détecte en 2 secondes, rouvre la chaîne en se calant sur le son et l'image plutôt que sur cette horloge, et s'en souvient pour les fois suivantes.
- **Journal de lecture** : les milliers de lignes « buffer too late » sont regroupées (une ligne toutes les 5 s avec le nombre de blocs jetés), pour que le journal reste lisible.
- La lecture réparée n'est pas comptée dans la qualité automatique des chaînes.

## [1.1.4] - 2026-10-24

- **Relais de flux** : il ne démarrait pas (« Operation not permitted ») car l'autorisation réseau locale n'était pas incluse dans l'application signée. C'est corrigé : le direct passe désormais par la connexion d'Apple (comme Piboard passe par la sienne) et non plus par celle du moteur VLC, que le pare-feu Cloudflare du fournisseur refuse (HTTP 403).
- **Moins de requêtes en cas de refus** : un seul nouvel essai au lieu de deux, pour ne pas multiplier les connexions chez le fournisseur.

## [1.1.3] - 2026-10-24

- **Relais de flux pour le direct** (comme Piboard) : Kastideo ouvre lui-même **une seule** connexion chez le fournisseur (en-têtes de lecteur VLC, redirections suivies) et la transmet au moteur VLC en local. Les requêtes multiples du moteur VLC à l'ouverture d'une chaîne, qui faisaient refuser les flux avec un abonnement à une connexion (HTTP 401/403/404/520), disparaissent ; la chaîne précédente est fermée net avant d'ouvrir la suivante. Réglage : Réglages > Général > Lecture > **Relais de flux pour le direct** (activé par défaut).
- **Journal de lecture** : réponse réelle du fournisseur (code HTTP, délai, redirections) et durée/volume de chaque connexion.

## [1.1.2] - 2026-10-24

- Correctif de compilation de la 1.1.1 (type des statistiques VLC renommé `VLCMedia.Stats`). Contient toutes les nouveautés de la 1.1.1.

## [1.1.1] - 2026-10-24

- **Chaînes sans son** : Kastideo surveille désormais le son pendant la lecture. Si l'image avance mais qu'aucun son n'est joué, il répare automatiquement : relance de la piste son quand la sortie audio n'a pas pu être créée au démarrage (erreur VLC « too low audio sample frequency (0) »), ou essai de la piste son suivante quand la piste choisie est vide. Si le flux n'a vraiment pas de son, une icône 🔇 orange apparaît dans la pastille de santé avec l'explication.
- **Journal de lecture** : format des pistes son de chaque chaîne (codec, fréquence, canaux, langue) et détail des tentatives de réparation.

## [1.1.0] - 2026-10-23

- **Direct en différé** : nouvelle **timeline** (de la pause jusqu'au direct) — glissez le curseur vers la droite pour avancer, Kastideo accélère la lecture jusqu'au point choisi ; **vitesse de lecture** ×1 à ×2 qui revient seule à ×1 en rattrapant le direct ; bouton **Rattraper** (accélère jusqu'au direct) et bouton **Retour au direct** bien visible ; **+30 s** (et −10 s si le flux permet le déplacement) en différé.
- Réglages > Général > Lecture : **durée maximale du différé** (30 min à 3 h ou sans limite, la lecture reprend seule une fois atteinte), **vitesse de rattrapage**, emplacement du dossier du différé avec bouton **Afficher**.

## [1.0.3] - 2026-10-23

- **Direct — changement de chaîne** : le fournisseur refusait la nouvelle chaîne (HTTP 404/403) parce qu'il comptait encore l'ancienne connexion (abonnement à une connexion). Kastideo laisse désormais 1,5 s au serveur pour libérer la chaîne précédente avant d'ouvrir la suivante, et réessaie deux fois la même chaîne (après 2 puis 4 s) si le serveur la refuse encore, avant d'essayer la variante .m3u8.
- L'essai en http ajouté en 1.0.2 est retiré (le serveur le refuse : HTTP 403).

## [1.0.2] - 2026-10-23

- **Direct** : quand le serveur refuse un flux en https (erreur HTTP 520 de Cloudflare, alors que la chaîne fonctionne ailleurs), Kastideo réessaie automatiquement la même chaîne en http (.ts puis .m3u8).
- **Connexion libérée** : le flux est désormais fermé proprement quand on quitte Kastideo, pour que le fournisseur ne compte plus la session (abonnement à une connexion).
- **Journal de lecture** : durée de fermeture du flux précédent à chaque changement de chaîne.

## [1.0.1] - 2026-10-22

- **Thèmes — « En ce moment »** : les chaînes dont le nom est suffisamment explicite (beIN Sports, BFM, Gulli, Eurosport…) sont désormais proposées dans leur thème **même sans programme dans le guide TV**. Elles s'affichent avec le nom de la chaîne à la place du titre du programme. Les chaînes que Kastideo ne sait pas classer sans guide restent proposées dans le mode **Chaînes** (vous pouvez les classer vous-même : clic droit > Thème de la chaîne).

## [1.0.0] - 2026-10-22

**Première version stable de Kastideo.** Direct, films et séries IPTV (Xtream Codes et M3U) lus par le moteur VLC, interfaces Classique, Cinéma et TV, écran d'accueil, guide TV en grille avec guide de secours xmltvfr.fr, Direct par thème avec alertes de programme, fiches films et séries (TMDB), enregistrement et téléchargement, MultiVue, catégories personnalisables, français et anglais, mises à jour automatiques.

Nouveau dans cette version :

- **Modifier la chaîne…** (clic droit sur une chaîne du direct) : corriger le **nom**, le **numéro**, le **logo** (adresse ou fichier) et la **chaîne du guide TV** associée, pour cette version de la chaîne ; **Rétablir l'original** pour annuler. Les corrections survivent aux actualisations de la source
- Les logos choisis ne sont pas effacés par « Vider et recharger » le cache

## [0.15.0] - 2026-10-22

- **Nouveaux thèmes** : Auto-Moto (sports mécaniques), Cuisine & Maison, Nature / Chasse & Pêche, Régional (France 3 régions, télés locales), International (chaînes étrangères), Religion, Radio, et **Adulte**
- **Contenus adultes** (« |XX| » dans le nom ou catégorie adulte) **masqués partout** par défaut ; Réglages > Général > Lecture > Afficher les contenus adultes
- **Sport par discipline** : Football, Rugby, Tennis, Basket, Combat, Golf, Cyclisme, Handball, Sports mécaniques, Sports d'hiver, Hippisme, Athlétisme & natation

## [0.14.1] - 2026-10-22

- Correction de compilation (la 0.14.0 n'avait pas pu être construite) : le Guide TV gère maintenant le filtre par thème
- **Guide TV** : nouveau filtre **Thèmes** (Sport, Films, Info…)

## [0.14.0] - 2026-10-22

- **Direct par thème** (section Thèmes, sous Direct) : Sport, Films, Séries, Info, Documentaires, Jeunesse, Divertissement, Musique, Généralistes ; modes **En ce moment** (d'après le genre des programmes du guide TV), **Ce soir** (20 h – 23 h) et **Chaînes** (thème de la chaîne, automatique et modifiable par clic droit). Les catégories masquées n'y apparaissent pas
- **Une seule version par chaîne** dans les thèmes : Kastideo choisit entre 4K, FHD, HD et SD selon la **qualité de votre connexion** (mesurée pendant les lectures) ou selon votre choix (Réglages > Général > Lecture)
- Thèmes aussi dans l'interface **Cinéma** (rangées « Sport en ce moment »…), l'interface **TV** (filtre Thèmes) et l'**accueil** (« À la télé maintenant », « Ce soir »)
- **Alertes de programme** : mot du titre, thème sur vos favoris, ou programme précis ; notification et bandeau « Regarder » deux minutes avant le début
- Le guide TV mémorise maintenant le **genre** de chaque programme

## [0.13.2] - 2026-10-22

- **Mises à jour** : recherche discrète **au démarrage** (puis toutes les 24 h si Kastideo reste ouvert) ; une nouvelle version est annoncée par un **bandeau** en haut de la fenêtre, **jamais pendant un visionnage ou un enregistrement**. La mise à jour reste facultative : Mettre à jour…, Plus tard ou Ignorer cette version
- Les recherches automatiques de Sparkle, qui pouvaient ouvrir une fenêtre à n'importe quel moment, sont remplacées par cette recherche discrète

## [0.13.1] - 2026-10-21

- Numéro de version (et de build) affiché discrètement en bas à droite de l'**écran d'accueil** ; un clic ouvre les nouveautés

## [0.13.0] - 2026-10-21

- **MultiVue** : jusqu'à 4 chaînes en direct dans une même fenêtre (1, 2 côte à côte, grille 2×2), le son suit la vignette active (clic ou touches 1 à 4) ; ajout, changement et retrait de chaîne au survol, recherche parmi favoris, récents et tout le direct. Menu Lecture > MultiVue… (⌥⌘M) ou clic droit > Ajouter à la MultiVue
- Désactivée par défaut : chaque flux consomme une connexion. Réglages > Général > Lecture > **Connexions simultanées de l'abonnement** (1 à 4) pour l'activer

## [0.12.0] - 2026-10-21

- **Lecteur repensé** : barre de contrôle compacte et **rétractable** (disparaît avec le pointeur après 3 s, revient au moindre mouvement)
- **Mini-timeline** pour les films et épisodes : trait fin qui s'épaissit au survol, avec l'heure visée
- **Panneau « Informations »** (ⓘ ou ⌘I) glissant depuis la droite : chaîne et programmes en cours / à venir, ou résumé et distribution du film ; choix de la **piste audio** et des **sous-titres** ; qualité de réception
- **Santé du flux** : pastille verte / orange / rouge (Excellent, Correct, Instable) et définition (SD, HD, 4K) ; débit, images perdues et coupures au survol
- Prochaine étape prévue (0.13) : MultiVue en option, selon le nombre de connexions de l'abonnement

## [0.11.3] - 2026-10-21

- Correction probable de la **lenteur Direct (Classique) → Films (Cinéma)** (55 s mesurées) : la liste classique ne construit plus, même un instant, les ~100 000 films d'une section affichée dans une autre interface
- Journal de lecture : les étapes de construction de l'affichage sont notées quand elles tardent, pour confirmer ou affiner le diagnostic

## [0.11.2] - 2026-10-21

- **Écran d'accueil** : grand logo Kastideo en arrière-plan, en-tête plus présent ; la page occupe toute la hauteur de la fenêtre et les grands pavés s'agrandissent avec elle
- **Bandeau « à la une »** : l'image de fond est cadrée sur le haut (2e quart) plutôt qu'au centre, là où se trouvent le plus souvent visages et titres
- Bandeau préparé hors du fil principal (derniers ajouts, tirage au hasard) pour ne plus ralentir l'ouverture de Films et Séries
- **Journal de lecture** : le temps d'affichage d'une section est noté quand il dépasse une demi-seconde (pour diagnostiquer la lenteur Direct → Films)

## [0.11.1] - 2026-10-21

- **Bandeau « à la une »** : la largeur du bandeau est maintenant imposée par la fenêtre ; une image de fond très large ne peut plus repousser l'affiche, le titre, le résumé et les boutons hors du cadre

## [0.11.0] - 2026-10-21

- **Gérer les catégories** (Présentation > Gérer les catégories…, ⌥⌘C, ou bouton de la barre latérale) pour le Direct, les Films et les Séries : **réordonner** par glisser-déposer, **masquer** (partout : listes, recherche, Guide TV, Cinéma, TV, bandeau), **masquer par mot-clé** (ex. « PAKISTAN »), **renommer**, trier A → Z, tout afficher ou réinitialiser
- Clic droit sur une catégorie de la barre latérale > **Masquer cette catégorie**
- Correction du **bandeau « à la une »** : l'image de fond prenait toute la place et cachait l'affiche, le titre, le résumé et les boutons
- Titres des affiches en interface Cinéma affichés sans les étiquettes du fournisseur (« |FR| »…)

## [0.10.0] - 2026-10-21

- Nouveau **bandeau « à la une »** de l'interface Cinéma : carrousel plein cadre avec grande image de fond, affiche, titre, année, durée, genres, note, résumé et boutons **Lire / Reprendre**, **Plus d'infos** et **Bande-annonce** ; défilement automatique (pause au survol), flèches et points de navigation
- Le carrousel mélange les **tendances de la semaine TMDB** présentes dans votre catalogue, les **derniers ajouts** du fournisseur et une **catégorie au choix** (ou tout le catalogue au hasard)
- En **Direct**, le bandeau montre le **programme en cours** de vos chaînes favorites et récentes (progression, programme suivant, Regarder)
- Réglages > Apparence > **Bandeau « à la une »** : afficher/masquer, hauteur, vitesse, sources et catégories
- Les films et séries Xtream mémorisent leur **date d'ajout** (actualisez la source pour l'obtenir)

## [0.9.8] - 2026-10-21

- Passage **instantané** du Direct à Films (ou à toute autre section) : l'arrêt du flux par le moteur VLC, qui pouvait prendre jusqu'à 30 s, se fait maintenant en arrière-plan sans bloquer l'interface. La durée de l'arrêt est notée dans le Journal de lecture quand elle dépasse 1 s

## [0.9.7] - 2026-10-21

- Correction d'un **blocage de l'application** (roue multicolore) en passant du Direct à Films pendant la lecture d'une chaîne : la vidéo reste hébergée dans une fenêtre invisible le temps que le moteur VLC s'arrête
- **Enregistrements sans son** : à la conversion en MP4, le son est maintenant converti en AAC (lisible partout, y compris QuickTime, iPhone et iPad) ; l'image reste copiée sans perte

## [0.9.6] - 2026-10-21

- **Enregistrement du direct** : si le moteur VLC ne crée pas le fichier dans le dossier « En cours » sous 10 s, Kastideo réessaie automatiquement dans un dossier temporaire avant d'afficher « Enregistrement impossible » ; dossier de travail nommé sans accents ni caractères spéciaux ; chaque essai est noté dans le Journal de lecture

## [0.9.5] - 2026-10-21

- **Guide TV de secours** : le guide gratuit de **xmltvfr.fr** (Complet, ~785 chaînes) complète automatiquement les chaînes sans programme chez le fournisseur, reliées par leur nom (« |FR| TF1 FHD » → TF1). Réglages > Général > Guide TV de secours (autre guide xmltvfr.fr ou adresse XMLTV au choix)
- Correction : un guide **vide ou illisible** envoyé par le fournisseur n'efface plus les programmes déjà connus ; un message l'indique sous la source
- Le guide est rechargé automatiquement quand il arrive à moins de 12 h de sa fin, même si Kastideo reste ouvert plusieurs jours

## [0.9.4] - 2026-10-20

- **Aide** : nouvelle rubrique « Obtenir une clé TMDB (gratuite) », pas à pas, dans Réglages généraux

## [0.9.3] - 2026-10-20

- **Fiche film / série** : la page commence sous la barre d'outils (l'affiche est entière), bouton **Retour à Films / Séries** bien visible en haut (ou Échap), titre affiché sans les étiquettes du fournisseur (« |FR| », « 4K »…)

## [0.9.2] - 2026-10-20

- Correction de l'**écran noir en plein écran** (le son continuait) : pendant le passage en plein écran, l'ancien et le nouvel écran coexistent un instant ; la vidéo va maintenant toujours à l'écran affiché

## [0.9.1] - 2026-10-20

- Correction de l'**écran noir** au retour sur une chaîne (bouton « Retourner à la lecture » de l'accueil, sortie du plein écran…) : la vidéo réapparaît sans relancer le flux

## [0.9.0] - 2026-10-20

- **Fiche film / série** en interface Cinéma : un clic sur une affiche ouvre une page de présentation (fond, affiche, année, durée, genres, note, résumé, réalisateur, distribution avec photos, bande-annonce) avec **Lire / Reprendre**, **Voir les épisodes**, **Télécharger** et favori. Bouton **Plus d'infos** dans le bandeau « à la une ». Informations du fournisseur IPTV (get_vod_info / get_series_info), complétées par **TMDB** si vous saisissez une clé gratuite dans Réglages > Général
- **Enregistrement du direct visible pendant l'écriture** : le fichier grossit dans le sous-dossier « En cours » du dossier des enregistrements, puis est rangé à l'arrêt
- **Conversion MP4 fiabilisée** : sous-titres DVB et télétexte écartés, second essai avec les pistes principales, fin de conversion détectée même sans signal du moteur ; le .ts n'est conservé qu'en dernier recours
- Correction : passer de **Direct** à **Films** (ou Séries) ouvre maintenant la grille de la section au lieu du lecteur de la chaîne précédente

## [0.8.3] - 2026-10-20

- Corrections de compilation (les versions 0.8.1 et 0.8.2 n'avaient pas pu être construites) : style de couleur des cases à cocher des Récents, accès au dossier personnel depuis la recherche des fichiers d'enregistrement

## [0.8.2] - 2026-10-20

- Correction de compilation (la version 0.8.1 n'avait pas pu être construite) : dossier « Documents » mal désigné dans la recherche des fichiers d'enregistrement
- Le journal de la construction automatique affiche désormais toutes les lignes d'erreur du compilateur

## [0.8.1] - 2026-10-20

- **Plein écran** : en interface Classique, le mode plein écran (bouton de la barre de contrôle, double-clic, ⌘↩ ou bouton vert de la fenêtre) affiche maintenant **la vidéo seule**, sans colonnes ni barre d'outils, au lieu de mettre toute l'application en plein écran. Échap ou ⌘↩ pour revenir
- **Enregistrement du direct** fiabilisé : Kastideo ne se fie plus au retour du moteur VLC (qui annonce parfois un échec alors que l'enregistrement fonctionne) et retrouve lui-même le fichier écrit ; le fichier est toujours déplacé dans le **dossier d'enregistrements choisi** (si ce dossier n'est plus accessible, ~/Movies/Kastideo est utilisé et un message l'indique)
- Un **bandeau** dans la fenêtre indique maintenant le résultat de chaque enregistrement et téléchargement (avec le dossier et un bouton « Afficher »), même si les notifications macOS sont désactivées ; les étapes sont aussi inscrites dans le Journal de lecture

## [0.8.0] - 2026-10-20

- Nouvel **écran d'accueil** au lancement : trois grands pavés **Direct**, **Films** et **Séries**, boutons d'accès rapide aux **Favoris**, **Récents**, **Guide TV** et **Enregistrements**, recherche globale (chaînes, films, séries), rangée « Reprendre la lecture » et retour à la lecture en cours. On y revient avec le bouton **Accueil**, **⌘0** (ou **H** en interface TV)
- **Récents** : suppression d'un ou de plusieurs éléments (clic droit > Retirer des récents, touche ⌫, ou **Modifier** puis cases à cocher), **Tout effacer**, et bandeau **Annuler** après chaque suppression
- Kastideo est maintenant disponible en **français et en anglais** : choix de la langue au premier lancement, modifiable dans Réglages > Général > Langue (relance proposée). L'aide intégrée est traduite

## [0.7.0] - 2026-10-19

- Nouveau **Guide TV en grille** : les chaînes en lignes, les heures en colonnes, trait rouge « maintenant », navigation par demi-journée et par jour, durée affichée 2 / 3 / 6 h, filtre (favoris, récents, catégorie) et recherche ; un clic sur un programme ouvre sa fiche (description, **Regarder**, **Enregistrer**, **Programmer**). Section Guide TV dans la barre latérale (⌘7), l'onglet Cinéma et la touche G de l'interface TV
- **Reprise de la lecture** : Kastideo mémorise où vous en êtes dans chaque film et épisode et vous propose de reprendre ; barres de progression dans les listes, les affiches et les épisodes ; rangée « Reprendre la lecture » en interface Cinéma
- **Indicateur de téléchargement** toujours visible dans la barre d'outils : anneau d'avancement et, au clic, le détail : avancement du film ou de l'épisode en cours, « épisode X sur N », avancement de la série ou du lot, vitesse et **temps restant estimé**. Les lignes de la section Enregistrements affichent aussi vitesse et temps restant

## [0.6.1] - 2026-10-19

- Nouvelle **icône** de l'application : monogramme K avec bouton lecture, sur fond violet, qui remplit toute la surface (plus de marge blanche autour dans le Dock et le Finder)

## [0.6.0] - 2026-10-19

- Nouvelle interface **TV** pour le direct : la chaîne en plein cadre, **panneau de chaînes** (touche ←, Entrée ou bord gauche) avec filtre Toutes / Favoris / Récents / catégorie et recherche, **bandeau d'information** à chaque changement de chaîne (programme en cours, horaires, programme suivant, heure)
- **Zapping au clavier** : ↑ / ↓ chaîne précédente / suivante, **numéro de chaîne** tapé au clavier, **B** retour à la chaîne précédente, I bandeau, F favori, M muet, Espace pause
- Reprise automatique de la dernière chaîne regardée à l'ouverture de l'interface TV
- Choix de l'interface TV dans Réglages > Apparence, par le bouton Interface de la barre d'outils ou avec ⌥⌘3

## [0.5.0] - 2026-10-19

- Nouvelle interface **Cinéma** : bandeau « à la une », rangées horizontales (reprise, favoris, une par catégorie), affiches pour les films et séries, vignettes avec programme en cours pour les chaînes, lecteur en plein cadre
- Interface **au choix par type de contenu** : Classique ou Cinéma séparément pour le direct, les films, les séries et les favoris / récents (bouton Interface de la barre d'outils, ⌥⌘1 / ⌥⌘2, ou Réglages > Apparence)
- Nouvel onglet **Réglages > Apparence** : thème, couleur d'accent, densité des listes, taille des vignettes
- Les listes par catégorie s'affichent plus vite
- Publication : l'agrafage du ticket de notarisation est retenté en cas d'indisponibilité du service Apple (le DMG reste notarisé sans agrafe)

## [0.4.0] - 2026-10-18

- **Enregistrement du direct** pendant la lecture (●, ⇧⌘R), sur la même connexion, arrêt automatique à la fin du programme
- **Enregistrements programmés** depuis le guide TV (double-clic ou clic droit) ou à horaires libres, avec marges avant / après
- **Téléchargement des films et épisodes** sans les regarder, saison ou série entière, en file d'attente, **cette nuit** à l'heure choisie
- Connexion unique respectée : Kastideo demande avant d'arrêter un enregistrement ; les téléchargements se mettent en pause pendant la lecture
- Conversion automatique des enregistrements en **MP4** sans perte de qualité
- **Direct en différé** : pause sur une chaîne en direct, reprise en différé, bouton « Direct »
- Section **Enregistrements** (⌘6) : en cours, conversions, téléchargements, programmations, fichiers
- Réglages > Enregistrements : dossier (~/Movies/Kastideo par défaut), marges, heure de nuit, MP4, nettoyage automatique, notifications
- Notifications macOS, blocage de la mise en veille pendant l'activité, alerte d'espace disque faible

## [0.3.1] - 2026-10-18

- Correction : une chaîne qui ne répond pas ne laisse plus le chargement tourner indéfiniment ; après 20 s sans image, Kastideo essaie la variante .ts / .m3u8 puis affiche une erreur explicite
- Le démarrage est désormais détecté dès que VLC passe en lecture
- Nouveau **Journal de lecture** (menu Lecture, ⌥⌘L, ou bouton dans le message d'erreur) : messages du moteur VLC, identifiants et mots de passe masqués, copiable pour le diagnostic
- Le détail de l'erreur VLC (par exemple un refus du serveur) est affiché sous le message d'erreur

## [0.3.0] - 2026-10-18

- Nouveau moteur de lecture **VLC** (VLCKit) pour tous les contenus : direct **MPEG-TS (.ts)**, HLS, MP4, **MKV**, AVI…
- Direct Xtream lu en .ts comme le lecteur de référence (certains fournisseurs refusent le .m3u8), avec bascule automatique .ts ↔ .m3u8
- Une seule connexion au fournisseur à la fois : le flux précédent est fermé avant d'ouvrir le suivant
- Nouveaux contrôles : lecture / pause, recul 10 s / avance 30 s, barre de progression, volume jusqu'à 200 %
- **Mode cinéma** (double-clic, ⌘↩, Échap pour sortir) et écran de chargement avec logo de la chaîne
- Badge **« Prête en x s »** : temps de démarrage mesuré à chaque chaîne
- Réglage de la **mémoire tampon** : Rapide (par défaut), Équilibré, Stable
- Publication : cache des paquets Swift dans GitHub Actions pour des compilations plus rapides

## [0.2.2] - 2026-10-18

- Correction : certains fournisseurs laissaient la requête expirer ; Kastideo s'identifie désormais comme **VLC**, comme la tuile IPTV de Piboard
- Les adresses de playlist **get.php?username=…&password=…** sont reconnues et converties automatiquement en source **Xtream Codes** : chargement beaucoup plus rapide, guide TV inclus, mot de passe dans le trousseau
- Les sources de ce type déjà configurées sont converties au lancement
- Messages d'erreur réseau en français et plus explicites (délai dépassé, serveur introuvable, connexion refusée…)
- Téléchargements : jusqu'à 10 minutes pour les très grosses playlists

## [0.2.1] - 2026-10-18

- Correction : les playlists et flux en **http://** étaient refusés (« App Transport Security ») ; ils se chargent désormais normalement
- Publication : un seul workflow GitHub par livraison (Build ne se lance plus qu'à la demande)

## [0.2.0] - 2026-10-18

- Mises à jour automatiques avec Sparkle : vérification quotidienne, installation en un clic et relance
- Menu **Kastideo > Rechercher les mises à jour…** et onglet **Mises à jour** dans les réglages
- Canal bêta facultatif pour recevoir les versions de test en avant-première
- Fenêtre **Nouveautés** au premier lancement après une mise à jour (aussi dans le menu Aide)
- Publication : signature des mises à jour et flux Sparkle générés automatiquement par GitHub Actions

## [0.1.0] - 2026-10-18

- Première version de Kastideo pour macOS : lecteur IPTV avec sources Xtream Codes et playlists M3U
- Sources Xtream Codes (serveur, identifiant, mot de passe) avec test de connexion, état et expiration du compte
- Playlists M3U / M3U8 par URL ou par fichier local (catégories, logos, numéros de chaînes)
- Guide TV XMLTV (y compris .xml.gz) : programme en cours, progression et programmes suivants
- Navigation Direct / Films / Séries / Favoris / Récents, catégories et recherche sans accents
- Séries Xtream : saisons et épisodes avec lecteur intégré
- Lecteur natif (HLS, MP4) avec plein écran et image dans l'image ; bascule automatique .ts → .m3u8
- Favoris (⌘D), historique des 60 derniers contenus, zapping ⌘↑ / ⌘↓
- Cache local pour un démarrage instantané, mots de passe dans le trousseau macOS
- Aide intégrée (menu Aide, ⌘?)
- Publication automatisée : DMG signé Developer ID et notarisé via GitHub Actions, script kastideo-release
