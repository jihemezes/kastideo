import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:media_kit/media_kit.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/desk.dart';
import 'core/window_placement.dart';
import 'core/device.dart';

import 'app_state.dart';
import 'core/alerts.dart';
import 'core/downloads.dart';
import 'core/guide.dart';
import 'core/multiview.dart';
import 'core/media_sync.dart';
import 'core/log.dart';
import 'core/notify.dart';
import 'core/system_integration.dart';
import 'core/cast_controller.dart';
import 'core/updater.dart';
import 'core/recording.dart';
import 'core/library.dart';
import 'core/media_info.dart';
import 'core/settings.dart';
import 'l10n.dart';
import 'core/playback.dart';
import 'theme.dart';
import 'ui/help_dialog.dart';
import 'ui/home_screen.dart';
import 'ui/library_view.dart';
import 'ui/catalog_screen.dart';
import 'ui/guide_view.dart';
import 'ui/multiview_view.dart';
import 'ui/recordings_view.dart';
import 'ui/log_dialog.dart';
import 'ui/settings_dialog.dart';
import 'ui/tv_view.dart';
import 'ui/widgets.dart';
import 'ui/notices.dart';
import 'ui/legal_notice.dart';
import 'ui/update_view.dart';
import 'ui/youtube_view.dart';
import 'core/models.dart';

/// Port local qui sert de verrou : une seule instance de Kastideo à la fois.
const _instancePort = 47819;
const _instanceHello = 'kastideo-instance';

/// Fichier .m3u / .m3u8 à ouvrir (double-clic dans l'explorateur), transmis aussi par une seconde instance.
final pendingOpen = ValueNotifier<String?>(null);

/// Fichier de playlist passé en argument (ou null).
String? _playlistArgument(List<String> args) {
  for (final a in args) {
    final lower = a.toLowerCase();
    if (!a.startsWith('--') && (lower.endsWith('.m3u') || lower.endsWith('.m3u8'))) return a;
  }
  return null;
}

/// Vrai si cette instance est la seule ; sinon l'instance déjà ouverte est mise au premier plan
/// (et reçoit le fichier à ouvrir, s'il y en a un).
Future<bool> _claimSingleInstance(String? openPath) async {
  try {
    final server = await ServerSocket.bind(InternetAddress.loopbackIPv4, _instancePort);
    server.listen((socket) async {
      socket.write(_instanceHello);
      await socket.flush();
      // Message éventuel de la seconde instance : « open:<chemin> ».
      final buffer = StringBuffer();
      try {
        await for (final data in socket.cast<List<int>>().transform(const Utf8Decoder(allowMalformed: true)).timeout(const Duration(seconds: 2))) {
          buffer.write(data);
          if (buffer.toString().contains('\n')) break;
        }
      } catch (_) {}
      socket.destroy();
      final line = buffer.toString().split('\n').first;
      if (line.startsWith('open:')) pendingOpen.value = line.substring(5);
      await windowManager.show();
      await windowManager.restore();
      await windowManager.focus();
    });
    return true;
  } catch (_) {
    // Port occupé : est-ce une autre instance de Kastideo ?
    try {
      final socket = await Socket.connect(InternetAddress.loopbackIPv4, _instancePort, timeout: const Duration(seconds: 2));
      if (openPath != null) socket.write('open:${File(openPath).absolute.path}\n');
      socket.write('hello\n');
      await socket.flush();
      final answer = await socket.cast<List<int>>().transform(const SystemEncoding().decoder).join().timeout(const Duration(seconds: 3));
      socket.destroy();
      return !answer.contains(_instanceHello);
    } catch (_) {
      return true;
    }
  }
}

/// Arrêt propre (fermeture de la fenêtre ou mise à jour) : lecture coupée, enregistrement terminé, mpv libéré.
class AppShutdown {
  AppShutdown(this.playback, this.watch, this.recordings, this.multiview);
  final MultiViewController multiview;
  final PlaybackController playback;
  final WatchProgressStore watch;
  final RecordingCenter recordings;

  Future<void> run() async {
    try {
      await windowManager.hide();
    } catch (_) {}
    try {
      await watch.flush().timeout(const Duration(seconds: 1));
    } catch (_) {}
    try {
      await multiview.stopAll().timeout(const Duration(seconds: 2));
    } catch (_) {}
    try {
      await recordings.shutdown().timeout(const Duration(seconds: 3));
    } catch (_) {}
    await playback.shutdown();
  }
}

late AppShutdown appShutdown;

/// Synchronisation de lecture avec les serveurs (menu « Marquer comme vu »).
late MediaSync mediaSync;

/// Fermeture de la fenêtre : la lecture est coupée et mpv libéré avant de quitter, puis le processus s'arrête.
class _CloseHandler with WindowListener {
  bool _closing = false;

  @override
  Future<void> onWindowClose() async {
    if (_closing) return;
    _closing = true;
    await appShutdown.run();
    exit(0);
  }
}

Future<void> main(List<String> args) async {
  WidgetsFlutterBinding.ensureInitialized();
  await Device.init();
  await windowManager.ensureInitialized();
  final openPath = _playlistArgument(args);
  final minimized = args.contains('--minimized');
  // Une seule instance sur ordinateur ; Android gère déjà cela lui-même.
  if (Device.isDesktop && !await _claimSingleInstance(openPath)) exit(0);
  if (openPath != null) pendingOpen.value = File(openPath).absolute.path;
  MediaKit.ensureInitialized();
  // KASTIDEO_WINDOW=420x860 : fenêtre de la taille d'un téléphone (essais de la mise en page compacte).
  final testSize = RegExp(r'^(\d+)x(\d+)$').firstMatch(Platform.environment['KASTIDEO_WINDOW'] ?? '');
  await windowManager.waitUntilReadyToShow(
    WindowOptions(
      title: 'Kastideo',
      size: testSize == null ? const Size(1280, 820) : Size(double.parse(testSize.group(1)!), double.parse(testSize.group(2)!)),
      minimumSize: testSize == null ? const Size(960, 620) : const Size(300, 300),
      center: !Device.isDesktop || testSize != null,
      backgroundColor: Color(0xFF1E1E1E),
    ),
    () async {
      if (Device.isDesktop && testSize == null) {
        // Position mémorisée si elle est encore visible, sinon centrée sur l'écran principal.
        final placement = await WindowPlacement.start(await SharedPreferences.getInstance());
        await placement.restore(const Size(1280, 820), const Size(960, 620));
        await windowManager.show();
        await placement.verify(const Size(1280, 820));
      } else {
        await windowManager.show();
      }
      // Lancement à l'ouverture de session : fenêtre réduite dans la barre des tâches.
      if (minimized) {
        await windowManager.minimize();
      } else {
        await windowManager.focus();
      }
    },
  );
  final settings = AppSettings();
  await settings.load();
  try {
    await PlaybackLog.shared.attach(await getApplicationSupportDirectory(), await SharedPreferences.getInstance());
  } catch (_) {}
  await SystemNotifier.setup();
  SystemNotifier.enabled = settings.systemNotifications;
  settings.addListener(() => SystemNotifier.enabled = settings.systemNotifications);
  L10n.apply(settings.language);
  final watch = WatchProgressStore();
  await watch.load();
  final library = LibraryStore()..settings = settings;
  final playback = PlaybackController()
    ..settings = settings
    ..watchProgress = watch;
  final navigation = NavigationModel()
    ..settings = settings
    ..categoryNames = library.categories;
  // Fin d'un replay : retour au direct de la chaîne.
  playback.onReplayEnded = (item) {
    final channel = library.replayChannels[item.id];
    if (channel != null && settings.replayReturnToLive) playback.play(channel);
  };
  final info = MediaInfoStore(library, settings);
  final guide = GuideStore(library);
  final recordings = RecordingCenter(settings, playback, library);
  final downloads = DownloadManager(settings, playback);
  final alerts = AlertCenter(settings, library, guide);
  final multiview = MultiViewController(settings, playback)..library = library;
  final updates = UpdateService();
  final cast = CastController(playback, settings);
  // Serveurs Jellyfin, Emby, Plex : positions de lecture partagées, fiches TMDB des fichiers locaux.
  final sync = MediaSync(library, watch);
  library.onUserData = sync.receive;
  library.onContentLoaded = info.enrichLocal;
  playback.onProgress = sync.report;
  mediaSync = sync;
  appShutdown = AppShutdown(playback, watch, recordings, multiview);
  await windowManager.setPreventClose(true);
  windowManager.addListener(_CloseHandler());
  if (Device.isAndroid) {
    // Plein écran sous les barres système ; les téléphones restent en portrait ou paysage selon l'appareil.
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }
  runApp(
    KastideoApp(
      library: library,
      playback: playback,
      navigation: navigation,
      settings: settings,
      watch: watch,
      info: info,
      guide: guide,
      recordings: recordings,
      downloads: downloads,
      alerts: alerts,
      multiview: multiview,
      updates: updates,
      cast: cast,
    ),
  );
  await library.start(autoRefresh: settings.autoRefresh);
  library.onSourceRemoved = guide.forgetSource;
  await recordings.start();
  await downloads.start();
  await alerts.start();
  await updates.start();
  unawaited(SystemIntegration.refreshAutostartPath());
  await guide.start();
}

class KastideoApp extends StatefulWidget {
  const KastideoApp({
    super.key,
    required this.library,
    required this.playback,
    required this.navigation,
    required this.settings,
    required this.watch,
    required this.info,
    required this.guide,
    required this.recordings,
    required this.downloads,
    required this.alerts,
    required this.multiview,
    required this.updates,
    required this.cast,
  });

  final UpdateService updates;
  final CastController cast;
  final LibraryStore library;
  final PlaybackController playback;
  final NavigationModel navigation;
  final AppSettings settings;
  final WatchProgressStore watch;
  final MediaInfoStore info;
  final GuideStore guide;
  final RecordingCenter recordings;
  final DownloadManager downloads;
  final AlertCenter alerts;
  final MultiViewController multiview;

  @override
  State<KastideoApp> createState() => _KastideoAppState();
}

/// Applique le thème (sombre, clair ou celui du système) et la couleur d'accent, et redessine toute la fenêtre.
class _KastideoAppState extends State<KastideoApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    widget.settings.addListener(_apply);
    _apply(initial: true);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    widget.settings.removeListener(_apply);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() => _apply();

  void _apply({bool initial = false}) {
    final mode = widget.settings.appearance;
    final light = switch (mode) {
      AppearanceMode.light => true,
      AppearanceMode.dark => false,
      AppearanceMode.system => WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.light,
    };
    final accent = widget.settings.accent;
    final density = widget.settings.listDensity.factor;
    final cards = widget.settings.cardSize.factor;
    if (!initial && light == KPalette.light && accent == KPalette.accentChoice && density == KPalette.density && cards == KPalette.cardScale) return;
    KPalette.light = light;
    KPalette.accentChoice = accent;
    KPalette.density = density;
    KPalette.cardScale = cards;
    if (initial) return;
    setState(() {});
    // Les couleurs sont lues au moment de construire chaque élément : on les reconstruit tous (l'état est gardé).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      void rebuild(Element e) {
        e.markNeedsBuild();
        e.visitChildren(rebuild);
      }

      WidgetsBinding.instance.rootElement?.visitChildren(rebuild);
      windowManager.setBackgroundColor(KPalette.window).catchError((_) {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      library: widget.library,
      playback: widget.playback,
      navigation: widget.navigation,
      settings: widget.settings,
      watch: widget.watch,
      info: widget.info,
      guide: widget.guide,
      recordings: widget.recordings,
      downloads: widget.downloads,
      alerts: widget.alerts,
      multiview: widget.multiview,
      updates: widget.updates,
      cast: widget.cast,
      child: MaterialApp(
        title: 'Kastideo',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        // Textes des éléments standard (calendrier, heure, boutons) dans la langue de l'interface.
        locale: Locale(L10n.localeParts.$1, L10n.localeParts.$2),
        supportedLocales: const [
          Locale('fr'), Locale('en'), Locale('es'), Locale('de'), Locale('it'),
          Locale('pt', 'BR'), Locale('pt', 'PT'),
        ],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        scrollBehavior: const KastideoScrollBehavior(),
        home: const RootView(),
      ),
    );
  }
}

/// Fenêtre principale : écran choisi + raccourcis clavier (Ctrl à la place de ⌘).
class RootView extends StatefulWidget {
  const RootView({super.key});

  @override
  State<RootView> createState() => _RootViewState();
}

class _RootViewState extends State<RootView> {
  @override
  void initState() {
    super.initState();
    pendingOpen.addListener(_openPending);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      await LegalNotice.showIfNeeded(context);
      if (!mounted) return;
      await showWhatsNewIfUpdated(context);
      _openPending();
    });
  }

  @override
  void dispose() {
    pendingOpen.removeListener(_openPending);
    super.dispose();
  }

  /// Fichier .m3u ouvert depuis l'explorateur : proposé comme nouvelle source (ou déjà présent : on va au direct).
  Future<void> _openPending() async {
    final path = pendingOpen.value;
    if (path == null || !mounted) return;
    pendingOpen.value = null;
    final library = context.library;
    await library.whenReady;
    if (!mounted) return;
    if (library.sources.any((s) => s.address == path)) {
      context.navigation.go(Screen.live);
      return;
    }
    final name = path.split(RegExp(r'[\\/]')).last.replaceAll(RegExp(r'\.m3u8?$', caseSensitive: false), '');
    final controller = TextEditingController(text: name);
    final ok = await showKDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr('Ajouter cette playlist ?')),
        content: SizedBox(
          width: 460,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            SelectableText(path, style: kText(12, color: KPalette.secondaryText)),
            const SizedBox(height: 12),
            TextField(controller: controller, autofocus: true, decoration: InputDecoration(labelText: tr('Nom'))),
            const SizedBox(height: 8),
            Text(tr('La playlist devient une source de Kastideo (Réglages > Sources) : ses chaînes rejoignent le direct.'),
                style: kText(12, color: KPalette.secondaryText)),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr('Annuler'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(tr('Ajouter'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final navigation = context.navigation;
    await library.addM3U(name: controller.text.trim().isEmpty ? name : controller.text.trim(), address: path);
    navigation.go(Screen.live);
  }

  /// Échap (ordinateur) ou touche Retour (Android) : quitte le mode cinéma, sinon referme le lecteur
  /// (le direct s'arrête, comme sur Mac). Renvoie vrai si quelque chose a été refermé.
  bool goBack(BuildContext context) {
    final navigation = context.navigation;
    final playback = context.playback;
    if (navigation.theater) {
      navigation.exitTheater();
      return true;
    }
    if (navigation.screen == Screen.library && navigation.showPlayer) {
      navigation.closePlayer();
      return true;
    }
    final kind = navigation.screen.kind;
    if (kind == MediaKind.live && context.settings.interfaceFor(MediaKind.live) == InterfaceStyle.tv) {
      // Interface TV : Retour referme d'abord le panneau ou le bandeau ; ensuite la chaîne s'arrête (Android) et on revient à l'accueil.
      if (TVView.onBack?.call() ?? false) return true;
      if (Device.isAndroid && playback.isLive) playback.stop();
      return false;
    }
    if (kind == null || !navigation.showPlayer) {
      // Téléphone : la chaîne lancée dans la colonne se referme avec Retour.
      if (Device.isAndroid && kind == MediaKind.live && playback.current != null && context.settings.interfaceFor(MediaKind.live) == InterfaceStyle.classic) {
        playback.stop();
        return true;
      }
      return false;
    }
    if (kind == MediaKind.live && context.settings.interfaceFor(kind) != InterfaceStyle.cinema && !Device.isAndroid) return false;
    if (playback.isLive) playback.stop();
    navigation.closePlayer();
    return true;
  }

  /// Touche Retour d'Android : referme ce qui est ouvert, puis revient à l'accueil, puis quitte l'application.
  void _systemBack(bool didPop, Object? result) {
    if (didPop) return;
    if (goBack(context)) return;
    final navigation = context.navigation;
    if (navigation.screen != Screen.home) {
      navigation.go(Screen.home);
      return;
    }
    SystemNavigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final navigation = context.navigation;
    final playback = context.playback;
    return PopScope(
      canPop: !Device.isAndroid,
      onPopInvokedWithResult: _systemBack,
      child: _shortcuts(context, navigation, playback),
    );
  }

  Widget _shortcuts(BuildContext context, NavigationModel navigation, PlaybackController playback) {
    return CallbackShortcuts(
      bindings: {
        SingleActivator(LogicalKeyboardKey.digit0, control: !Device.isMac, meta: Device.isMac): () => navigation.go(Screen.home),
        SingleActivator(LogicalKeyboardKey.digit1, control: !Device.isMac, meta: Device.isMac): () => navigation.go(Screen.live),
        SingleActivator(LogicalKeyboardKey.digit2, control: !Device.isMac, meta: Device.isMac): () => navigation.go(Screen.movies),
        SingleActivator(LogicalKeyboardKey.digit3, control: !Device.isMac, meta: Device.isMac): () => navigation.go(Screen.series),
        SingleActivator(LogicalKeyboardKey.digit8, control: !Device.isMac, meta: Device.isMac): () => navigation.go(Screen.library),
        SingleActivator(LogicalKeyboardKey.digit9, control: !Device.isMac, meta: Device.isMac): () => navigation.go(Screen.youtube),
        SingleActivator(LogicalKeyboardKey.digit7, control: !Device.isMac, meta: Device.isMac): () => navigation.go(Screen.guide),
        SingleActivator(LogicalKeyboardKey.keyM, control: !Device.isMac, meta: Device.isMac, alt: true): () => openMultiView(context),
        SingleActivator(LogicalKeyboardKey.comma, control: !Device.isMac, meta: Device.isMac): () => showSettingsDialog(context),
        const SingleActivator(LogicalKeyboardKey.f1): () => showHelpDialog(context, page: helpPageFor(navigation.screen)),
        SingleActivator(LogicalKeyboardKey.keyL, control: !Device.isMac, meta: Device.isMac, alt: true): () => showLogDialog(context),
        SingleActivator(LogicalKeyboardKey.enter, control: !Device.isMac, meta: Device.isMac): navigation.toggleTheater,
        const SingleActivator(LogicalKeyboardKey.escape): () => goBack(context),
        SingleActivator(LogicalKeyboardKey.keyK, control: !Device.isMac, meta: Device.isMac): playback.togglePause,
        SingleActivator(LogicalKeyboardKey.period, control: !Device.isMac, meta: Device.isMac): () => stopPlayback(context),
      },
      child: Focus(
        autofocus: true,
        child: Stack(
          children: [
            Positioned.fill(
              child: ListenableBuilder(
                listenable: navigation,
                builder: (context, _) => switch (navigation.screen) {
                  Screen.home => const HomeScreen(),
                  Screen.live => const CatalogScreen(kind: MediaKind.live),
                  Screen.movies => const CatalogScreen(kind: MediaKind.movie),
                  Screen.series => const CatalogScreen(kind: MediaKind.series),
                  Screen.guide => const GuideScreen(),
                  Screen.recordings => const RecordingsScreen(),
                  Screen.multiview => const MultiViewScreen(),
                  Screen.library => const LibraryScreen(),
                  Screen.youtube => const YouTubeScreen(),
                },
              ),
            ),
            const Positioned(top: 14, right: 14, child: NoticeOverlay()),
            const Positioned(top: 60, left: 0, right: 0, child: Center(child: Material(type: MaterialType.transparency, child: RecordingDurationBanner()))),
            // Mise à jour disponible : en bas à droite, pour ne pas cacher les boutons du haut.
            const Positioned(bottom: 14, right: 14, child: Material(type: MaterialType.transparency, child: UpdateBanner())),
          ],
        ),
      ),
    );
  }
}
