import SwiftUI
import AppKit
import UniformTypeIdentifiers
import KastideoCore

/// Section « Enregistrements » : en cours, conversions, téléchargements, programmés et fichiers enregistrés.
struct RecordingsListView: View {
    @Environment(RecordingCenter.self) private var recordings
    @Environment(NavigationModel.self) private var navigation
    @State private var selecting = false
    @State private var selected: Set<String> = []
    @State private var request: RemovalRequest?

    var body: some View {
        @Bindable var navigation = navigation
        @Bindable var recordings = recordings
        List(selection: $navigation.selectedItemID) {
            if let live = recordings.activeLive {
                Section("Enregistrement en cours") {
                    LiveRecordingRow(live: live)
                        .selectionDisabled()
                }
            }
            if !recordings.converting.isEmpty {
                Section("Conversion en MP4") {
                    ForEach(recordings.converting, id: \.self) { name in
                        HStack(spacing: 8) {
                            ProgressView().controlSize(.small)
                            Text(name).lineLimit(1)
                        }
                        .selectionDisabled()
                    }
                }
            }
            if !recordings.downloads.isEmpty {
                Section("Téléchargements") {
                    ForEach(recordings.downloads) { entry in
                        DownloadRow(entry: entry)
                            .selectionDisabled()
                    }
                }
            }
            if !recordings.schedules.isEmpty {
                Section("Programmés") {
                    ForEach(recordings.schedules) { recording in
                        ScheduleRow(recording: recording)
                            .selectionDisabled()
                    }
                }
            }
            Section {
                if recordings.files.isEmpty {
                    Text("Aucun enregistrement pour le moment. Utilisez ● pendant la lecture, le guide TV, ou le clic droit sur une chaîne, un film ou un épisode.")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .selectionDisabled()
                } else {
                    ForEach(recordings.files) { file in
                        HStack(spacing: 8) {
                            if selecting {
                                Image(systemName: selected.contains(file.id) ? "checkmark.circle.fill" : "circle")
                                    .foregroundStyle(selected.contains(file.id) ? Color.accentColor : Color.secondary)
                                    .imageScale(.large)
                            }
                            FileRow(file: file)
                            Spacer(minLength: 0)
                            if !selecting {
                                Button {
                                    request = RemovalRequest(files: [file], isClear: false)
                                } label: { Image(systemName: "trash") }
                                    .buttonStyle(.borderless)
                                    .help("Retirer de la liste…")
                            }
                        }
                        .overlay {
                            // Le clic n'est capté qu'en mode sélection : sinon la liste garde son comportement (clic = lecture).
                            if selecting {
                                Color.clear
                                    .contentShape(Rectangle())
                                    .onTapGesture {
                                        if selected.contains(file.id) { selected.remove(file.id) } else { selected.insert(file.id) }
                                    }
                            }
                        }
                        .contextMenu {
                            Button("Afficher dans le Finder") { recordings.reveal(file) }
                            Divider()
                            Button("Retirer de la liste…") { request = RemovalRequest(files: [file], isClear: false) }
                            Button("Placer dans la corbeille", role: .destructive) { recordings.deleteFile(file) }
                        }
                    }
                }
            } header: {
                HStack(spacing: 12) {
                    Text("Enregistrés (\(recordings.files.count))")
                    Spacer()
                    if !recordings.files.isEmpty {
                        Button(selecting ? "Terminer la sélection" : "Sélectionner") {
                            selecting.toggle()
                            if !selecting { selected = [] }
                        }
                        .buttonStyle(.link)
                        Button("Vider la liste…") {
                            request = RemovalRequest(files: recordings.files, isClear: true)
                        }
                        .buttonStyle(.link)
                    }
                }
            }
        }
        .listStyle(.inset)
        .navigationTitle("Enregistrements")
        .safeAreaInset(edge: .bottom) {
            VStack(spacing: 0) {
                if selecting {
                    HStack {
                        Button("Tout sélectionner") { selected = Set(recordings.files.map(\.id)) }
                        Button("Aucun") { selected = [] }
                        Spacer()
                        Button("Retirer la sélection (\(selected.count))…", role: .destructive) {
                            let list = recordings.files.filter { selected.contains($0.id) }
                            if !list.isEmpty { request = RemovalRequest(files: list, isClear: false) }
                        }
                        .disabled(selected.isEmpty)
                        Button("Terminer") { selecting = false; selected = [] }
                            .keyboardShortcut(.defaultAction)
                    }
                    .padding(10)
                    .background(.bar)
                }
                if recordings.removalUndo != nil {
                    HStack {
                        Image(systemName: "arrow.uturn.backward.circle")
                        Text("Retiré de la liste.")
                        Spacer()
                        Button("Annuler") { recordings.undoRemoval() }
                    }
                    .padding(10)
                    .background(.bar)
                }
            }
        }
        .toolbar {
            ToolbarItem {
                Button {
                    selecting.toggle()
                    if !selecting { selected = [] }
                } label: {
                    Label("Sélectionner", systemImage: selecting ? "checkmark.circle.fill" : "checkmark.circle")
                }
                .disabled(recordings.files.isEmpty)
                .help("Sélectionner plusieurs enregistrements pour les retirer de la liste")
            }
            ToolbarItem {
                Button {
                    request = RemovalRequest(files: recordings.files, isClear: true)
                } label: {
                    Label("Vider la liste…", systemImage: "trash.slash")
                }
                .disabled(recordings.files.isEmpty)
                .help("Retirer tous les enregistrements terminés de la liste")
            }
            ToolbarItem {
                Button {
                    recordings.reveal()
                } label: {
                    Label("Ouvrir le dossier", systemImage: "folder")
                }
                .help("Ouvrir le dossier des enregistrements dans le Finder")
            }
        }
        .onAppear { recordings.refreshFiles() }
        .onChange(of: recordings.files) { _, files in
            let ids = Set(files.map(\.id))
            selected = selected.intersection(ids)
            if files.isEmpty { selecting = false }
        }
        .sheet(item: $request) { req in
            RemovalConfirmSheet(request: req) { selected = []; selecting = false }
        }
        .sheet(item: $recordings.removalWarnings) { warnings in
            RemovalWarningsSheet(warnings: warnings)
        }
    }
}

/// Demande de retrait de la liste (une ou plusieurs entrées, ou la liste entière).
struct RemovalRequest: Identifiable {
    let id = UUID()
    let files: [RecordingFile]
    let isClear: Bool
}

/// Boîte de dialogue : retirer de la liste seulement (par défaut) ou supprimer aussi les fichiers du stockage.
struct RemovalConfirmSheet: View {
    @Environment(RecordingCenter.self) private var recordings
    @Environment(\.dismiss) private var dismiss
    let request: RemovalRequest
    var onDone: () -> Void = {}

    @State private var deleteFiles = UserDefaults.standard.bool(forKey: RecordingKeys.removeDeletesFiles)
    @State private var remember = false

    private var total: Int64 { request.files.reduce(0) { $0 + $1.size } }
    private var sizeText: String { ByteCountFormatter.string(fromByteCount: total, countStyle: .file) }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(request.isClear ? String(localized: "Vider la liste (\(request.files.count))") : request.files.count == 1 ? String(localized: "Retirer l'enregistrement de la liste") : String(localized: "Retirer \(request.files.count) enregistrements de la liste"))
                .font(.headline)
            if request.files.count <= 8 {
                VStack(alignment: .leading, spacing: 3) {
                    ForEach(request.files) { Text("• " + $0.name).lineLimit(1).font(.callout) }
                }
            } else {
                Text("\(request.files.count) enregistrements terminés (programmations, téléchargements et enregistrement en cours ne sont pas concernés).")
                    .font(.callout).foregroundStyle(.secondary)
            }
            Divider()
            Toggle(isOn: $deleteFiles) {
                Text("Supprimer aussi le(s) fichier(s) du stockage (corbeille)")
            }
            if deleteFiles {
                Label("Espace libéré : \(sizeText)", systemImage: "internaldrive")
                    .font(.callout).foregroundStyle(.secondary)
            } else {
                Text("Les fichiers restent dans le dossier des enregistrements ; ils ne réapparaîtront pas dans la liste. Vous pourrez annuler juste après.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Toggle("Mémoriser ce choix", isOn: $remember).font(.callout)
            HStack {
                Spacer()
                Button("Annuler", role: .cancel) { dismiss() }
                    .keyboardShortcut(.cancelAction)
                Button(deleteFiles ? "Retirer et supprimer" : "Retirer de la liste", role: deleteFiles ? .destructive : nil) {
                    if remember { UserDefaults.standard.set(deleteFiles, forKey: RecordingKeys.removeDeletesFiles) }
                    recordings.remove(request.files, deleteFiles: deleteFiles)
                    onDone()
                    dismiss()
                }
                .keyboardShortcut(.defaultAction)
            }
        }
        .padding(20)
        .frame(width: 440)
    }
}

/// Liste des avertissements d'un retrait (fichier introuvable, suppression impossible…).
struct RemovalWarningsSheet: View {
    @Environment(\.dismiss) private var dismiss
    let warnings: RemovalWarnings

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("\(warnings.messages.count) avertissements", systemImage: "exclamationmark.triangle.fill")
                .font(.headline).foregroundStyle(.orange)
            Text("Le retrait a été effectué malgré ces avertissements.").font(.callout).foregroundStyle(.secondary)
            List(warnings.messages, id: \.self) { Text($0).font(.callout) }
                .frame(minHeight: 120, maxHeight: 260)
            HStack { Spacer(); Button("OK") { dismiss() }.keyboardShortcut(.defaultAction) }
        }
        .padding(20)
        .frame(width: 480)
    }
}

struct LiveRecordingRow: View {
    @Environment(RecordingCenter.self) private var recordings
    let live: RecordingCenter.ActiveLive

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "record.circle.fill").foregroundStyle(.red)
            VStack(alignment: .leading, spacing: 2) {
                Text(live.title).lineLimit(1)
                TimelineView(.periodic(from: .now, by: 1)) { context in
                    Text(detail(at: context.date))
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            StopDurationMenu()
            Button("Arrêter") { recordings.stopLive() }
        }
    }

    private func detail(at date: Date) -> String {
        var text = "\(live.item.name) — \(date.timeIntervalSince(live.startedAt).clockString)"
        if let end = live.endsAt {
            text += String(localized: " · fin à \(end.formatted(date: .omitted, time: .shortened))")
            text += String(localized: " (reste \(max(0, end.timeIntervalSince(date)).clockString))")
        } else {
            text += String(localized: " · sans limite de durée")
        }
        text += live.mode == .player ? String(localized: " · pendant la lecture") : String(localized: " · en arrière-plan")
        return text
    }
}

/// Menu « Arrêt » : changer à tout moment l'arrêt programmé de l'enregistrement en cours (durée, heure précise ou sans limite).
struct StopDurationMenu: View {
    @Environment(RecordingCenter.self) private var recordings
    @State private var showTime = false
    @State private var customDate = Date().addingTimeInterval(3600)

    var body: some View {
        Menu {
            Section("Arrêter l'enregistrement dans…") {
                ForEach([15, 30, 60, 90, 120, 180, 240], id: \.self) { minutes in
                    Button(minutes < 60 ? "\(minutes) min" : (minutes % 60 == 0 ? "\(minutes / 60) h" : "\(minutes / 60) h \(minutes % 60)")) {
                        recordings.setStop(after: minutes)
                    }
                }
            }
            Divider()
            Button("À une heure précise…") {
                customDate = recordings.activeLive?.endsAt ?? Date().addingTimeInterval(3600)
                showTime = true
            }
            Button("Sans limite de durée") { recordings.setStop(after: nil) }
        } label: {
            Label("Durée", systemImage: "timer")
        }
        .menuStyle(.button)
        .fixedSize()
        .onChange(of: showTime) { _, open in
            if open { recordings.holdDurationPrompt() } else { recordings.releaseDurationPrompt() }
        }
        .popover(isPresented: $showTime) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Arrêter l'enregistrement à").font(.headline)
                DatePicker("", selection: $customDate, displayedComponents: .hourAndMinute)
                    .datePickerStyle(.graphical)
                    .labelsHidden()
                HStack {
                    Spacer()
                    Button("Annuler") { showTime = false }
                    Button("OK") {
                        recordings.setStop(at: customDate)
                        showTime = false
                    }
                    .keyboardShortcut(.defaultAction)
                }
            }
            .padding(14)
        }
    }
}

struct DownloadRow: View {
    @Environment(RecordingCenter.self) private var recordings
    let entry: DownloadItem

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon).foregroundStyle(entry.state == .failed ? .orange : .secondary)
            VStack(alignment: .leading, spacing: 3) {
                Text(entry.fileName).lineLimit(1)
                if entry.state == .downloading || entry.received > 0 {
                    ProgressView(value: entry.progress)
                        .progressViewStyle(.linear)
                        .controlSize(.small)
                }
                Text(status)
                    .font(.caption)
                    .foregroundStyle(entry.state == .failed ? .orange : .secondary)
                    .lineLimit(2)
            }
            Spacer()
            switch entry.state {
            case .downloading:
                Button { recordings.pauseDownload(entry.id) } label: { Image(systemName: "pause.fill") }
                    .buttonStyle(.borderless).help("Mettre en pause")
            case .queued, .paused, .failed:
                Button { recordings.resumeDownload(entry.id, now: true) } label: { Image(systemName: "play.fill") }
                    .buttonStyle(.borderless).help("Télécharger maintenant")
            }
            Button { recordings.cancelDownload(entry.id) } label: { Image(systemName: "xmark") }
                .buttonStyle(.borderless).help("Annuler")
        }
    }

    private var icon: String {
        switch entry.state {
        case .downloading: return "arrow.down.circle"
        case .queued: return entry.startAfter.map { $0 > Date() } == true ? "moon.zzz" : "clock"
        case .paused: return "pause.circle"
        case .failed: return "exclamationmark.triangle"
        }
    }

    private var status: String {
        let size: String = {
            guard entry.expected > 0 else { return ByteCountFormatter.string(fromByteCount: entry.received, countStyle: .file) }
            return String(localized: "\(ByteCountFormatter.string(fromByteCount: entry.received, countStyle: .file)) sur \(ByteCountFormatter.string(fromByteCount: entry.expected, countStyle: .file))")
        }()
        switch entry.state {
        case .downloading:
            var text = "\(size) — \(Int(entry.progress * 100)) %"
            if let status = recordings.downloadStatus, status.current.id == entry.id {
                text += " · \(DownloadFormat.speed(status.speed))"
                if let eta = status.eta { text += String(localized: " · reste \(DownloadFormat.remaining(eta))") }
                if let batch = status.batch { text += String(localized: " · épisode \(batch.position)/\(batch.total)") }
            }
            return text
        case .queued:
            if let start = entry.startAfter, start > Date() {
                return String(localized: "Programmé : \(start.formatted(date: .abbreviated, time: .shortened))")
            }
            return String(localized: "En attente (connexion libre requise : aucune lecture ni enregistrement en cours)")
        case .paused:
            return entry.pausedByUser ? String(localized: "En pause — \(size)") : String(localized: "Suspendu pendant la lecture — reprendra automatiquement")
        case .failed:
            return entry.error ?? String(localized: "Échec")
        }
    }
}

struct ScheduleRow: View {
    @Environment(RecordingCenter.self) private var recordings
    let recording: ScheduledRecording

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "calendar.badge.clock").foregroundStyle(Color.accentColor)
            VStack(alignment: .leading, spacing: 2) {
                Text(recording.title).lineLimit(1)
                Text("\(recording.item.name) — \(recording.start.formatted(date: .abbreviated, time: .shortened)) → \(recording.end.formatted(date: .omitted, time: .shortened))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button { recordings.removeSchedule(recording.id) } label: { Image(systemName: "trash") }
                .buttonStyle(.borderless).help("Supprimer la programmation")
        }
    }
}

struct FileRow: View {
    let file: RecordingFile

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: file.url.pathExtension.lowercased() == "ts" ? "film" : "play.rectangle")
                .foregroundStyle(Color.accentColor)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 2) {
                Text(file.name).lineLimit(2)
                Text("\(file.date.formatted(date: .abbreviated, time: .shortened)) — \(ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file)) — .\(file.url.pathExtension)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 2)
    }
}

/// Programmation manuelle d'un enregistrement (choix d'un programme du guide ou d'horaires libres).
struct ScheduleRecordingSheet: View {
    @Environment(LibraryStore.self) private var store
    @Environment(RecordingCenter.self) private var recordings
    @Environment(\.dismiss) private var dismiss
    let item: MediaItem

    @State private var title = ""
    @State private var start = Date().addingTimeInterval(300)
    @State private var end = Date().addingTimeInterval(300 + 3600)

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 12) {
                LogoView(url: item.logoURL, name: item.name, size: 44)
                VStack(alignment: .leading) {
                    Text("Programmer un enregistrement").font(.headline)
                    Text(item.name).foregroundStyle(.secondary)
                }
            }
            .padding(16)

            Form {
                let upcoming = store.epg.upcoming(for: item.epgID, after: Date(), limit: 8)
                if !upcoming.isEmpty {
                    Section("Choisir un programme du guide") {
                        ForEach(upcoming) { programme in
                            Button {
                                recordings.schedule(item, programme: programme)
                                dismiss()
                            } label: {
                                HStack {
                                    Text(programme.start.formatted(date: .omitted, time: .shortened))
                                        .monospacedDigit()
                                        .foregroundStyle(.secondary)
                                    Text(programme.title).lineLimit(1)
                                    Spacer()
                                    if recordings.isScheduled(item, programme) {
                                        Image(systemName: "record.circle").foregroundStyle(.red)
                                    }
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                Section("Ou des horaires libres") {
                    TextField("Titre", text: $title, prompt: Text(item.name))
                    DatePicker("Début", selection: $start, displayedComponents: [.date, .hourAndMinute])
                    DatePicker("Fin", selection: $end, in: start..., displayedComponents: [.date, .hourAndMinute])
                }
            }
            .formStyle(.grouped)

            Divider()
            HStack {
                Text("Kastideo doit rester ouvert et le Mac allumé à l'heure de l'enregistrement.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button("Annuler", role: .cancel) { dismiss() }
                    .keyboardShortcut(.cancelAction)
                Button("Programmer") {
                    let name = title.trimmingCharacters(in: .whitespaces)
                    recordings.schedule(item, title: name.isEmpty ? item.name : name, start: start, end: end)
                    dismiss()
                }
                .keyboardShortcut(.defaultAction)
                .disabled(end <= start || end <= Date())
            }
            .padding(16)
        }
        .frame(width: 520, height: 560)
    }
}

/// Réglages > Enregistrements.
struct RecordingSettingsView: View {
    @Environment(RecordingCenter.self) private var recordings
    @AppStorage(RecordingKeys.marginBefore) private var marginBefore = 2
    @AppStorage(RecordingKeys.marginAfter) private var marginAfter = 5
    @AppStorage(RecordingKeys.defaultMinutes) private var defaultMinutes = 120
    @AppStorage(RecordingKeys.nightHour) private var nightHour = 2
    @AppStorage(RecordingKeys.convertMP4) private var convertMP4 = true
    @AppStorage(RecordingKeys.autoClean) private var autoClean = false
    @AppStorage(RecordingKeys.autoCleanDays) private var autoCleanDays = 30
    @AppStorage(RecordingKeys.notifications) private var notifications = true
    @State private var showPicker = false
    @State private var folderPath = ""

    var body: some View {
        Form {
            Section("Dossier") {
                LabeledContent("Emplacement") {
                    Text(folderPath)
                        .lineLimit(1)
                        .truncationMode(.middle)
                        .foregroundStyle(.secondary)
                }
                HStack {
                    Button("Choisir…") { showPicker = true }
                    Button("Afficher dans le Finder") { recordings.reveal() }
                    if RecordingFolder.isCustom {
                        Button("Revenir à ~/Movies/Kastideo") {
                            recordings.resetFolder()
                            folderPath = RecordingFolder.current.path
                        }
                    }
                }
            }
            Section("Enregistrement du direct") {
                Stepper("Marge avant le programme : \(marginBefore) min", value: $marginBefore, in: 0...30)
                Stepper("Marge après le programme : \(marginAfter) min", value: $marginAfter, in: 0...60)
                Picker("Durée par défaut (sans fin connue dans le guide)", selection: $defaultMinutes) {
                    Text("Sans limite").tag(0)
                    ForEach([30, 60, 90, 120, 180, 240, 360, 480, 720], id: \.self) { minutes in
                        Text(minutes % 60 == 0 ? "\(minutes / 60) h" : "\(minutes / 60) h \(minutes % 60) min").tag(minutes)
                    }
                }
                Text("L'enregistrement démarre tout de suite ; un bandeau permet de choisir un autre arrêt. Sans choix, il s'arrête à la fin du programme (guide TV) ou, à défaut, après cette durée.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Toggle("Convertir en MP4 (sans perte de qualité, lisible par QuickTime et l'iPhone)", isOn: $convertMP4)
            }
            Section("Téléchargements") {
                Picker("« Cette nuit » commence à", selection: $nightHour) {
                    ForEach(0..<7, id: \.self) { hour in Text("\(hour) h").tag(hour) }
                }
            }
            Section("Nettoyage automatique") {
                Toggle("Placer les anciens enregistrements dans la corbeille", isOn: $autoClean)
                Stepper("Après \(autoCleanDays) jours", value: $autoCleanDays, in: 1...365)
                    .disabled(!autoClean)
            }
            Section("Notifications") {
                Toggle("Notifier les débuts et fins d'enregistrement et de téléchargement", isOn: $notifications)
            }
            Section {
                Text("Votre abonnement n'autorisant qu'une connexion, Kastideo enregistre ou télécharge une seule chose à la fois et vous demande avant d'interrompre une lecture. Pour les enregistrements programmés et les téléchargements de nuit, Kastideo doit rester ouvert et le Mac allumé (la mise en veille automatique est bloquée pendant l'activité).")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .formStyle(.grouped)
        .onAppear { folderPath = RecordingFolder.current.path }
        .fileImporter(isPresented: $showPicker, allowedContentTypes: [.folder]) { result in
            if case .success(let url) = result {
                recordings.chooseFolder(url)
                folderPath = RecordingFolder.current.path
            }
        }
    }
}

/// Pastille « ● REC 00:12:34 » affichée sur la vidéo pendant un enregistrement.
struct RecordingBadge: View {
    let live: RecordingCenter.ActiveLive

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            HStack(spacing: 6) {
                Circle().fill(.red).frame(width: 8, height: 8)
                Text("REC \(context.date.timeIntervalSince(live.startedAt).clockString)")
                    .font(.caption.weight(.bold).monospacedDigit())
                Text(live.title)
                    .font(.caption)
                    .lineLimit(1)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 10).padding(.vertical, 5)
            .background(.black.opacity(0.6), in: Capsule())
            .frame(maxWidth: 320, alignment: .leading)
        }
    }
}
